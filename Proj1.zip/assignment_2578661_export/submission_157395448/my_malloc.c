#include "my_malloc.h"


void print_freeList(){
  printf("==========\nsbrk(%lu) free(%lu)\n",get_data_segment_size(), get_data_segment_free_space_size());
  printf("FreeList: ");
  metadata_t * curr = freeList;
  if(curr == NULL){
    printf("empty\n");
    return;
  }
  while(curr != NULL){
    //    int pos = curr - freeList;
    printf("[start: %p, size: %lu] ", curr, curr->size);
    curr = curr->next;
  }
  printf("\n");
}




//First Fit malloc/free
void * ff_malloc(size_t size){
  metadata_t * curr = freeList;
  while(curr != NULL){
    if((curr->size == size) || (curr->size > size + m_size)){
      return use_free_block(curr, size);
    }
    curr = curr->next;
  }
  return add_allocated_block(size);//no free space is usable
}

void ff_free(void * ptr){
  if(ptr == NULL){
    return;
  }
  metadata_t * occupied_block = (metadata_t *)(ptr - m_size);
  assert(occupied_block->next == NULL);
  assert(occupied_block->prev == NULL);
  total_occupied -= (occupied_block->size + m_size);
  add_free_block(occupied_block);
  mergeFreeList(occupied_block);
}


void * add_allocated_block(size_t size){
  metadata_t * newallocate = sbrk(size + m_size);
  total_sbrk += size + m_size;
  total_occupied += size + m_size;
  newallocate->size = size;
  newallocate->prev = NULL;
  newallocate->next = NULL;
  return (void *)newallocate + m_size;
}

void * use_free_block(metadata_t * m, size_t size){
  if(m->size == size){//use the whole block
    total_occupied += m->size + m_size;
    remove_from_freeList(m);
  }
  //part of the block used, remaining kept
  else if(m->size > size + m_size){
      metadata_t *m_remaining = (metadata_t *)((void *)m + m_size + size);
      m_remaining->size = m->size - size - m_size;
      m_remaining->size = m->size - size - m_size;
      m_remaining->next = m->next;
      m_remaining->prev = m->prev;
        
      if(m_remaining->prev!=NULL){
            m_remaining->prev->next = m_remaining;
      }else{
            freeList = m_remaining;
      }
      if(m_remaining->next!=NULL){
            m_remaining->next->prev = m_remaining;
      }else{
            freeEnd = m_remaining;
      }
      m->size = size;
      m->prev = NULL;
      m->next = NULL;
      total_occupied += m->size + m_size;
  }
  assert(m->next == NULL);
  assert(m->prev == NULL);
  return (void *)m + m_size;
}

void remove_from_freeList(metadata_t * m){
  if(m->prev == NULL){//m is the head for freeList
    if(m->next != NULL){//m is first free block
      m->next->prev = NULL;
      freeList = m->next;
      m->next = NULL;
    }else{//m is the only free block
      freeList = NULL;
      freeEnd = NULL;
    }
  }else{//m->prev != NULL
    if(m->next != NULL){// m is in the middle of freeList
      m->prev->next = m->next;
      m->next->prev = m->prev;
      m->prev = NULL;
      m->next = NULL;   
    }else{//m is the last block
      m->prev->next = NULL;
      freeEnd = m->prev;
      m->prev = NULL;
    }
  }
  assert(m->next == NULL);
  assert(m->prev == NULL);
}



void add_free_block(metadata_t * m){
  if(m == NULL){
    return;
  }
  assert(m->prev == NULL && m->next ==NULL);
  metadata_t * curr = freeList;

  if(curr == NULL){
    freeList = m;
    return;
  }
  
  if(curr != NULL && curr > m){//add to beginning
     m->next = curr;
     curr->prev = m;
     freeList = m;
     return;
   }
   while(curr != NULL){
     if(curr < m){
       if(curr->next >= m || curr->next == NULL){
         break;
         break;//find the place to add
       }
     }
     curr = curr->next;
   }
   m->next = curr->next;
   m->prev = curr;
   //  m->next = curr->next;
   if(curr->next != NULL){
     curr->next->prev = m;
     m->next = curr->next;
   }else{
     m->next = NULL;
   }
   curr->next = m;
   mergeFreeList(m);
}


void mergeFreeList(metadata_t * m){
  metadata_t * prev = m->prev;
  metadata_t * next = m->next;

  //here is trick:
  //address is hexdecimal
  //m->size and size are size_t, it is decimal
  if(next != NULL && ((void *)m + m_size + m->size) == (void *)next){
    m->size += next->size + m_size;
    m->next = next->next;
    if(m->next != NULL){
      m->next->prev = m;
      m->next = next->next;
    }else{
      m->next = NULL;
      freeEnd = m;
    }
    next->next = NULL;
    next->prev = NULL;
  }
  if(prev != NULL && ((void *)prev + m_size + prev->size) == (void *)m){
    prev->size += m->size + m_size;
    prev->next = m->next;
    if(m->next != NULL){
    m->next->prev = prev;
    }else{
      freeEnd = prev;
    }
    m->next = NULL;
    m->prev = NULL;
  } 
}

void * bf_malloc(size_t size){
  assert(size != 0);
  if(freeList == NULL){
    return add_allocated_block(size);
  }//empty list
  metadata_t * curr = freeList;
  size_t min_extra;
  metadata_t * best_free_block = NULL;
  while(curr != NULL){//find the first valid free block
    if(curr->size == size){
      return use_free_block(curr, size);
    }else if(curr->size > size + m_size){
      if(best_free_block == NULL){
        min_extra = curr->size;
        best_free_block = curr;
      }else{
        if(curr->size < min_extra){
           min_extra = curr->size;
           best_free_block = curr;
        }
      }
    }
    curr = curr->next;
  }
  if(best_free_block == NULL){//no block is valid
    return add_allocated_block(size);
  }
  return use_free_block(best_free_block, size);
}


void bf_free(void * ptr){
  ff_free(ptr);
}


//performance study
unsigned long get_data_segment_size(){
  return total_sbrk;
}

unsigned long get_data_segment_free_space_size(){
  return total_sbrk - total_occupied;
}


