//#ifndef MY_MALLOC_H
//#define MY_MALLOC_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

//metadata
//Used to store free block and only
//A sinple linkedList
struct Metadata{
  size_t size;
  struct Metadata * prev;
  struct Metadata * next;
};
typedef struct Metadata metadata_t;

size_t m_size = sizeof(metadata_t);

//starting point of data
metadata_t * freeList = NULL;
metadata_t * freeEnd = NULL;

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

//helper function
void * add_allocated_block(size_t size);
void * use_free_block(metadata_t * metadata, size_t size);
void remove_from_freeList(metadata_t * m);
void add_free_block(metadata_t * m);
void mergeFreeList(metadata_t * m);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

//performance study
unsigned long get_data_segment_size();//in byte
unsigned long get_data_segment_free_space_size();//in byte
unsigned long total_sbrk = 0;
unsigned long total_occupied = 0;

//print
void print_freeList();

//#endiff
