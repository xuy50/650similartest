//
// Created by px16 on 2023/1/23.
//

#include <unistd.h>
#include "my_malloc.h"

Block * ff_find(size_t size){
    if(init == 0){
        return NULL;
    }
    if(head_free == NULL){
        return NULL;
    }
    Block * cur = head_free;
    while(cur != NULL){
        if(cur->size >= size){
            return cur;
        }
        cur = cur->next;
    }
    return NULL;
}

Block * bf_find(size_t size){
    Block * res = ff_find(size);
    if(res == NULL){
        return NULL;
    }
    Block * cur = res->next;
    while(cur != NULL){
        //exactly match
        if(cur->isFree == 1 && cur->size == size){
            return cur;
        }
        //need to split
        if(cur->isFree == 1 && cur->size >= size + sizeof(Block) && cur->size < res->size){
            res = cur;
        }
        cur = cur->next;
    }
    return res;
}

void addFreeList(Block * blk){
    if(head_free == NULL){
        head_free = blk;
        tail_free = blk;
        return;
    }
    if((char *)head_free > (char *)blk){
        blk->next = head_free;
        head_free->prev = blk;
        head_free = blk;
    }
    else if((char *)tail_free < (char *)blk){
        blk->prev = tail_free;
        tail_free->next = blk;
        tail_free = blk;
    }
    else{
        Block * cur = head_free;
        while(cur != NULL){
            if((char *)cur > (char *)blk){
                break;
            }
            cur = cur->next;
        }
        //insert between cur->prev and cur
        blk->prev = cur->prev;
        blk->next = cur;
        cur->prev->next = blk;
        cur->prev = blk;
    }
}

void deleteFreeList(Block * blk){
    if(head_free == blk && tail_free == blk){
        head_free = NULL;
        tail_free = NULL;
        return;
    }
    if(head_free == blk && tail_free != blk){
        if(head_free->next == NULL){
            return;
        }
        head_free = head_free->next;
        head_free->prev = NULL;
        blk->prev = NULL;
        blk->next = NULL;
    }
    else if(tail_free == blk){
        tail_free = tail_free->prev;
        tail_free->next = NULL;
        blk->prev = NULL;
        blk->next = NULL;
    }
    else{
        blk->prev->next = blk->next;
        blk->next->prev = blk->prev;
        blk->prev = NULL;
        blk->next = NULL;
    }
}

//flag: 0: ff ; 1: bf
void * my_malloc(size_t size, int flag){

    //Find a block that fits in existing list
    Block * blk = NULL;
    if(flag == 0){
        blk = ff_find(size);
    }else if(flag == 1){
        blk = bf_find(size);
    }
    
    //If not find, sbrk a new one
    if(blk == NULL){
        Block * block = sbrk(size + sizeof(Block));
        //ToDo: sbrk failed
        if(block == (void*)-1){
            return NULL;
        }
        //renew total_size
        total_size += size + sizeof(Block);

        block->size = size;
        block->isFree = 0;
        block->prev = NULL;
        block->next = NULL;

        return (void *)((char *)block + sizeof(Block));
    }
    //If find, give its required space
    else{
        //If do not need to split
        if(blk->size >= size){
            deleteFreeList(blk);
            return (void *)((char *)blk + sizeof(Block));
        }
        
        //split the block
        size_t freesize = blk->size - size - sizeof(Block);

        blk->size = size;
        blk->isFree = 0;
        Block * freeblock = (Block *)((char *)blk + sizeof(Block) + blk->size);
        if(freeblock == NULL){
            return NULL;
        }
        freeblock->size = freesize;
        freeblock->isFree = 1;
        freeblock->prev = NULL;
        freeblock->next = NULL;

        deleteFreeList(blk);
        addFreeList(freeblock);

        return (void *)((char *)blk + sizeof(Block));
    }
}

void merge(Block * blk){
    if(blk->prev == NULL && blk->next == NULL){
        return;
    }
    //Merge with prev
    if(blk->prev != NULL && (char *)blk->prev + blk->prev->size == (char *)blk){
        //Merge with both prev and next
        if(blk->next != NULL && (char *)blk + blk->size == (char *)blk->next){
            blk->prev->size += sizeof(Block) + blk->size + sizeof(Block) + blk->next->size;
            deleteFreeList(blk->next);
            deleteFreeList(blk);
        }
        //Merge only with prev
        else{
            blk->prev->size += sizeof(Block) + blk->size;
            deleteFreeList(blk);
        }
    }
    //Merge only with next
    else if(blk->next != NULL && (char *)blk + blk->size == (char *)blk->next){
        blk->size += sizeof(Block) + blk->next->size;
        deleteFreeList(blk->next);
    }
}

void my_free(void *ptr){
    if(ptr == NULL){
        return;
    }
    init = 1;

    //find the metadata block
    Block * blk = (Block *)((char *)ptr - sizeof(Block));
    if(blk == NULL){
        return;
    }
    blk->isFree = 1;

    addFreeList(blk);
    merge(blk);
}

//First Fit malloc/free
void *ff_malloc(size_t size){
    return my_malloc(size, 0);
}

void ff_free(void *ptr){
    my_free(ptr);
}

//Best Fit malloc/free
void *bf_malloc(size_t size){
    return my_malloc(size, 1);
}

void bf_free(void *ptr){
    my_free(ptr);
}

unsigned long get_data_segment_size(){
    return total_size;
}

unsigned long get_data_segment_free_space_size(){
    //free_size = 0;
    Block * cur = head_free;
    while(cur != NULL){
        free_size += cur->size + sizeof(Block);
        cur = cur->next;
    }
    return free_size;
}