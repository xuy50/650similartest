//
// Created by px16 on 2023/1/23.
//

#ifndef _MY_MALLOC_H
#define _MY_MALLOC_H

#include <stdio.h>
//#include <unistd.h>

struct _Block{
    size_t size;
    int isFree; //0: this block is occupied ; 1: this block is free
    struct _Block * prev;
    struct _Block * next;
};
typedef struct _Block Block;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

Block * ff_find(size_t size);
Block * bf_find(size_t size);
void * my_malloc(size_t size, int flag);
void my_free(void *ptr);

void addFreeList(Block * blk);
void deleteFreeList(Block * blk);
void merge(Block * blk);

//Block * head = NULL;
//Block * tail = NULL;

Block * head_free = NULL;
Block * tail_free = NULL;
int init = 0;

unsigned long total_size = 0;
unsigned long free_size = 0;

#endif //_MY_MALLOC_H
