#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <stdint.h>
#include "my_malloc.h"

// head node and tail node of the free block double linked list
meta_node * headNode = NULL;
meta_node * tailNode = NULL;

size_t has_first_sbrk = 0;
void * base = NULL;

meta_node * findFirstFreeBlock(size_t size){
    if(headNode == NULL)
        return NULL;
    meta_node * it = headNode;
    while(it != NULL){
        if(it->size >= size && it->free == 1)
            return it;
        it = it->next;
    }
    return NULL;
}
meta_node * findBestFreeBlock(size_t size){
    if(headNode == NULL)
        return NULL;
    meta_node * it = headNode;
    meta_node * best = NULL;
    size_t best_diff = (size_t)-1;

    while(it != NULL){
        if(it->size >= size && it->free == 1){
            if(it->size == size)
                return it;
            if(it->size-size < best_diff){
                best = it;
                best_diff = it->size-size;
            }
        }
        it = it->next;
    }
    return best;
}

// split the block into the required size. field variable of the returned meta_node is unmodified
void RemoveBlockFromLL(meta_node * toRemove){
    assert(toRemove != NULL);
    assert(toRemove->free);

    // printf("remove\n");

    if(toRemove == headNode){
        // printf("remove_1\n");
        if(headNode ==  tailNode){
            headNode = NULL;
            tailNode = NULL;
        }
        else{
            toRemove->next->prev = NULL;
            headNode = toRemove->next;
        }
        
        // printf("remove_2\n");
    }
    else if(toRemove == tailNode){
    // else if(toRemove->next == NULL){
        // printf("remove_3\n");
        if(headNode == tailNode){
            headNode = NULL;
            tailNode = NULL;
        }else{
            toRemove->prev->next = NULL;
            tailNode = toRemove->prev;
        }
        // printf("remove_4\n");
    }
    else{
        // if(toRemove->next == NULL)
        //     printf("NULLLLL\n");
        // if(toRemove->prev == NULL)
        //     printf("NULLLLL\n");        
        // printf("remove_5\n");
        toRemove->prev->next = toRemove->next;
        toRemove->next->prev = toRemove->prev;
        // printf("remove_6\n");
    }
    toRemove->prev = NULL;
    toRemove->next = NULL;
}
// the size included META_NODE_SIZE
meta_node * splitFreeBlock(size_t size, meta_node * free_block_to_split){
    // printf("split\n");
    assert(free_block_to_split != NULL);
    assert(free_block_to_split->free);
    assert(free_block_to_split->size >= size);

    meta_node * res;

    if(free_block_to_split->size > size+META_NODE_SIZE){   // free_block_to_split->size > size-META_NODE_SIZE        
       
        res = (meta_node *)((char *)free_block_to_split + free_block_to_split->size + META_NODE_SIZE - size - META_NODE_SIZE);
        res->next = NULL;
        res->prev = NULL;
        res->size = size;
        res->free = 0;

        free_block_to_split->size = free_block_to_split->size - size - META_NODE_SIZE;
    }
    else{
        // printf("split_1\n");

        res = free_block_to_split;
        RemoveBlockFromLL(free_block_to_split);

        // printf("split_2\n");
    }
    return res;
}

void MergeBackBlock(meta_node * toMerge){
    assert(toMerge != NULL);
    assert(toMerge->free);
    if(toMerge->next == NULL)
        return;

    // merge back
    if((void *)toMerge+toMerge->size+META_NODE_SIZE == (void *)toMerge->next){
        meta_node * merged = toMerge->next;

        toMerge->size = toMerge->size + toMerge->next->size + META_NODE_SIZE;
        // printf("merge_back_1\n");
        // if(toMerge->next == tailNode){
        if(toMerge->next->next == NULL){
            // printf("merge_back_2\n");
            tailNode = toMerge;
            // printf("merge_back_3\n");
        }
        else{
            // printf("merge_back_4\n");
            toMerge->next->next->prev = toMerge;
            // printf("merge_back_5\n");
        }
        toMerge->next = toMerge->next->next;

        merged->prev = NULL;
        merged->next = NULL;
    }
}
void MergeFrontBlock(meta_node * toMerge){
    assert(toMerge != NULL);
    assert(toMerge->free);
    if(toMerge->prev == NULL)
        return;

    // merge front
    if((void *)toMerge->prev+toMerge->prev->size+META_NODE_SIZE == (void *)toMerge){        
        toMerge->prev->size = toMerge->size + toMerge->prev->size + META_NODE_SIZE;
        // if(toMerge == tailNode)
        if(toMerge->next == NULL)
            tailNode = toMerge->prev;
        else
            toMerge->next->prev = toMerge->prev;
        toMerge->prev->next = toMerge->next;
         
        toMerge->next = NULL;
        toMerge->prev = NULL;
    }
}

// add free block to linked list and merge adjacent block
void AddFreeBlockToLL(meta_node * toAdd){
    assert(toAdd != NULL);
    assert(toAdd->free);
    // assert(toAdd->prev == NULL);
    // assert(toAdd->next == NULL);

    // the only element in the linked list
    if(headNode == NULL){
        headNode = toAdd;
        tailNode = headNode;
        headNode->prev = NULL;
        headNode->next = NULL;
        tailNode->prev = NULL;
        tailNode->next = NULL;
        toAdd->prev = NULL;
        toAdd->next = NULL;
    }
    else{
        meta_node * it = headNode;

        //insert it as head node
        if(((void *)toAdd+META_NODE_SIZE+toAdd->size) <= (void *)headNode){
            headNode->prev = toAdd;
            toAdd->next = headNode;
            headNode = toAdd;
            MergeBackBlock(toAdd);
        }
        else{
            while(it->next != NULL){
                if(((void *)it+META_NODE_SIZE+it->size)<=(void *)toAdd && ((void *)toAdd+META_NODE_SIZE+toAdd->size)<=(void *)it->next)
                    break;
                it = it->next;
            }
            // insert it as tail node
            // if(it == tailNode){
            if(it->next == NULL){
                // printf("tailNode\n");
                tailNode->next = toAdd;
                toAdd->prev = tailNode;
                tailNode = toAdd;
                MergeFrontBlock(toAdd);
            }
            else{
                // if(it->next == NULL)
                //     printf("NULLLLLLLL\n");
                // printf("middleNode\n");
                it->next->prev = toAdd;
                // printf("middleNode_1\n");
                toAdd->prev = it;
                // printf("middleNode_2\n");
                toAdd->next = it->next;
                // printf("middleNode_3\n");
                it->next = toAdd;
                // printf("end_middleNode\n");
                
                MergeBackBlock(toAdd);
                // printf("Mergback\n");
                MergeFrontBlock(toAdd);
                // printf("Mergfront\n");
            }
        }
    }
}


//ff_malloc and bf_malloc are similar, but different in type
void * my_malloc(size_t size, int is_ff){

    // printf("my_malloc\n");

    meta_node * find_block;
    if(is_ff==1)
        find_block = findFirstFreeBlock(size);
    else
        find_block = findBestFreeBlock(size);

    // printf("my_malloc_1\n");

    meta_node * res;
    if(find_block == NULL){
        // printf("my_malloc_2_1\n");
        res = (meta_node *)sbrk(size + META_NODE_SIZE);
        if ((void *)res == (void*) -1){   // nothing is allocated
            return NULL;
        }
        res->size = size;

        // record the base of the heap
        if(has_first_sbrk == 0){
            has_first_sbrk = 1;
            base = res;
        }
        // printf("my_malloc_2_2\n");
    }
    else{
        // printf("my_malloc_3_1\n");
        // printLL();

        res = splitFreeBlock(size, find_block);

        // printLL();
        // RemoveBlockFromLL(find_block);
        // res = find_block;
        // printf("my_malloc_3_2\n");
    }
    res->prev = NULL;
    res->next = NULL;
    res->free = 0;  
    assert(res->prev == NULL);
    assert(res->next == NULL);
    // printf("my_malloc_4\n");
    return (void *)res + META_NODE_SIZE;
}
// ff_free and bf_free are actually the same, both directly call my_free
void my_free(void *ptr){
    meta_node * toFree = (meta_node *)(ptr - META_NODE_SIZE);
    toFree->free = 1;

    // printLL();

    AddFreeBlockToLL(toFree);

    // printLL();
}

//First Fit malloc/free
void * ff_malloc(size_t size){return my_malloc(size, 1);}
void ff_free(void *ptr){my_free(ptr);}

//Best Fit malloc/free
void * bf_malloc(size_t size){return my_malloc(size, 0);}
void bf_free(void *ptr){my_free(ptr);}

// performance analysis
unsigned long get_data_segment_size(){ //in byte
    assert(base != NULL);    
    return (sbrk(0)-base);
}
unsigned long get_data_segment_free_space_size(){ //in byte
    meta_node * it = headNode;
    unsigned long res = 0;
    while(it!=NULL){
        res += it->size + META_NODE_SIZE;
        it = it->next;
    }
    return res;
}

//debugging
void printNode(meta_node * toPrint){
    printf("[%zu, %zu, %d， %lu, %lu, %lu]", META_NODE_SIZE, toPrint->size, toPrint->free, ((void *)toPrint-base), ((void*)toPrint->prev-base), ((void*)toPrint->next-base));
}

void printLL(){
    if(headNode == NULL)
        return;
    meta_node * it = headNode;
    while(it->next != NULL){
        printNode(it);
        printf("->");
        it = it->next;
    }
    printf("\n");
}