#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>

struct _meta_node{
    size_t size;    // size of this block
    struct _meta_node * prev;  // the prev block of this block
    struct _meta_node * next;   // next block of this block
    int free;      // whether this block is free: 1 is free, 0 is not free
};
typedef struct _meta_node meta_node;

#define META_NODE_SIZE sizeof(meta_node)

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void *ptr);

//ff_malloc and bf_malloc are similar, but different in type
void * my_malloc(size_t size, int is_ff);
// ff_free and bf_free are actually the same, both directly call my_free
void my_free(void *ptr);

meta_node * findFirstFreeBlock(size_t size);
meta_node * findBestFreeBlock(size_t size);

// split the block into the required size. field variable of the returned meta_node is unmodified
void RemoveBlockFromLL(meta_node * toRemove);
meta_node * splitFreeBlock(size_t size, meta_node * free_block_to_split);

// add free block to linked list and merge adjacent block
void AddFreeBlockToLL(meta_node * toAdd);
void MergeBackBlock(meta_node * toMerge);
void MergeFrontBlock(meta_node * toMerge);

// performance analysis
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

// debugging
void printNode(meta_node * toPrint);
void printLL();