#include <stdio.h>
#include <unistd.h>

struct block_info
{
    size_t size;
    struct block_info *prev;
    struct block_info *next;
};
typedef struct block_info block;

void *allocate(size_t size);
void split(block *block_ptr, size_t size);
void add_block(block *block_ptr);
void remove_block(block *block_ptr);
void merge(block *block_ptr);

// first fit
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// best fit
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

void print_block();