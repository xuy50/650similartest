#include "my_malloc.h"

block *head = NULL;
block *tail = NULL;
unsigned long data_size = 0;
unsigned long data_free_size = 0;

void *allocate(size_t size)
{
    size_t true_size = size + sizeof(block);
    data_size += true_size;
    block *ptr = sbrk(true_size);
    if (ptr == (void *)-1)
    {
        return NULL;
    }
    ptr->size = size;
    ptr->prev = NULL;
    ptr->next = NULL;
    // print_block();
    return (void *)ptr + sizeof(block);
}

void split(block *block_ptr, size_t size)
{
    // no need to split block
    if (block_ptr->size <= size + sizeof(block))
    {
        remove_block(block_ptr);
        data_free_size = data_free_size - block_ptr->size - sizeof(block);
    }
    else
    {
        // split block
        block *rest = (void *)block_ptr + sizeof(block) + size;
        rest->size = block_ptr->size - size - sizeof(block);
        rest->prev = NULL;
        rest->next = NULL;

        block_ptr->size = size;

        remove_block(block_ptr);
        add_block(rest);

        data_free_size = data_free_size - size - sizeof(block);
    }
}

void add_block(block *block_ptr)
{
    if (head == NULL && tail == NULL)
    {
        head = block_ptr;
        tail = block_ptr;
    }
    else if (block_ptr < head)
    {
        block_ptr->next = head;
        block_ptr->prev = NULL;
        head->prev = block_ptr;
        head = block_ptr;
    }
    else if (block_ptr > tail)
    {
        block_ptr->prev = tail;
        block_ptr->next = NULL;
        tail->next = block_ptr;
        tail = block_ptr;
    }
    else
    {
        block *ptr = head;
        while (block_ptr > ptr)
        {
            ptr = ptr->next;
        }
        block_ptr->prev = ptr->prev;
        block_ptr->next = ptr;
        ptr->prev->next = block_ptr;
        ptr->prev = block_ptr;
    }
}

void remove_block(block *block_ptr)
{
    if (block_ptr == NULL)
    {
        return;
    }
    if (head == tail && head == block_ptr)
    {
        head = NULL;
        tail = NULL;
    }
    else if (head == block_ptr)
    {
        head = block_ptr->next;
        block_ptr->next->prev = NULL;
    }
    else if (tail == block_ptr)
    {
        block_ptr->prev->next = NULL;
        tail = block_ptr->prev;
    }
    else
    {
        block_ptr->prev->next = block_ptr->next;
        block_ptr->next->prev = block_ptr->prev;
    }
    block_ptr->prev = NULL;
    block_ptr->next = NULL;
}

void merge(block *block_ptr)
{
    if (block_ptr == NULL)
    {
        return;
    }
    // merge next block
    if (block_ptr->next != NULL && (void *)block_ptr->next - sizeof(block) - block_ptr->size == (void *)block_ptr)
    {
        block_ptr->size += sizeof(block) + block_ptr->next->size;
        remove_block(block_ptr->next);
    }
    // merge previous block
    if (block_ptr->prev != NULL && (void *)block_ptr->prev + sizeof(block) + block_ptr->prev->size == (void *)block_ptr)
    {
        block_ptr->prev->size += sizeof(block) + block_ptr->size;
        remove_block(block_ptr);
    }
}

void *ff_malloc(size_t size)
{
    if (head == NULL)
    {
        return allocate(size);
    }
    else
    {
        block *ptr = head;
        while (ptr != NULL)
        {
            if (ptr->size >= size)
            {
                split(ptr, size);
                // print_block();
                return (void *)ptr + sizeof(block);
            }
            ptr = ptr->next;
        }
        return allocate(size);
    }
}

void ff_free(void *ptr)
{
    block *block_ptr = (block *)(ptr - sizeof(block));
    data_free_size += sizeof(block) + block_ptr->size;

    add_block(block_ptr);
    merge(block_ptr);
    // print_block();
}

void *bf_malloc(size_t size)
{
    if (head == NULL)
    {
        return allocate(size);
    }
    else
    {
        block *ptr = head;
        block *best = NULL;
        // find best fit block
        while (ptr != NULL)
        {
            if (ptr->size == size)
            {
                best = ptr;
                break;
            }
            if (ptr->size > size && (best == NULL || best->size > ptr->size))
            {
                best = ptr;
            }
            ptr = ptr->next;
        }
        if (best == NULL)
        {
            return allocate(size);
        }
        else
        {
            split(best, size);
            return (void *)best + sizeof(block);
        }
    }
}

void bf_free(void *ptr)
{
    ff_free(ptr);
}

unsigned long get_data_segment_size()
{
    return data_size;
}

unsigned long get_data_segment_free_space_size()
{
    return data_free_size;
}

void print_block()
{
    block *ptr = head;
    int count = 0;
    while (ptr != NULL)
    {
        printf("Num: %d address: %p size: %lu \tend address: %p\n", count, ptr, ptr->size, (void *)ptr + sizeof(block) + ptr->size);
        count++;
        ptr = ptr->next;
    }
    printf("free size: %ld data size: %ld\n\n", data_free_size, data_size);
}