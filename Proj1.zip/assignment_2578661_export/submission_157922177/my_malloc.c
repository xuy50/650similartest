#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "my_malloc.h"

meta_list *requestNew(size_t size) {
  meta_list *newNode;
  newNode = sbrk(0);
  // printf("newNode before:%p\n", newNode);
  sbrk(sizeof(meta_list) + size);
  // printf("Request:%p of size %zu\n", newNode, size);
  totalsize += size + sizeof(meta_list);
  return newNode;
}
void printList() {
  meta_list *curr = metaHead;

  while (curr != NULL) {
    printf("Addr:%p,Size:%zu \n", curr, curr->size);
    // printf("Add+size:%p\n", (curr + 1));
    curr = curr->next;
  }
  printf("list end %p\n", curr);
  printf("\n");
}

void *ff_malloc(size_t size) {
  meta_list *current;
  meta_list *previous = NULL;
  // printf("find for size%zu:\n", size);
  for (current = metaHead; current != NULL;
       previous = current, current = current->next) {
    if (current->size >= size) {
      // find usable node
      // printf("find usable at%p:\n", current);
      // check if can split
      if (current->size >= size + sizeof(meta_list)) {
        // printf("can split!\n");
        meta_list *newNode = (void *)current + sizeof(meta_list) + size;
        newNode->size = current->size - size - sizeof(meta_list);
        newNode->next = current->next;
        current->size = size;
        if (previous != NULL) {
          previous->next = newNode;
        } else {
          metaHead = newNode;
        }
      }
      // cannot split
      else {
        // printf("cannot split\n");
        if (previous != NULL) {
          previous->next = current->next;
        } else {
          metaHead = current->next;
        }
      }
      // printf("at split:\n");
      // printList();
      // return the part after the meta info
      return current + 1;
    }
  }

  // request new when not found
  current = requestNew(size);
  current->size = size;
  return current + 1;
}

void ff_free(void *ptr) {
  // get the head of the node
  meta_list *target = (meta_list *)ptr - 1;
  meta_list *current = metaHead;
  meta_list *previous = NULL;
  int sign = 0;
  // printf("free:%p\n", target);
  if ((void *)target == (void *)current) {
    sign = 1;
    current->next = NULL;
    // return;
  }
  // search for the position to insert
  for (current = metaHead; current != NULL;
       previous = current, current = current->next) {
    // printf("current:%p\n", (void *)current);
    if (current > target) {
      // printf("target:%p, current:%p, previous:%p\n", (void *)target,
      //(void *)current, (void *)previous);
      // printf("target+size:%p\n", (void *)(target + 1) + target->size);
      if (previous != NULL) {
        //  printf("prev+size:%p\n", (void *)(previous + 1) + previous->size);
      }
      break;
    }
  }

  // merge with nexts if possible
  if (current != NULL &&
      ((void *)(target + 1) + target->size == (void *)current)) {
    // printf("can merge with next\n");
    target->size += current->size + sizeof(meta_list);
    target->next = current->next;
  } else {
    // printf("not merged with next\n");
    // printf("current:%p\n", (void *)current);
    if (current != NULL) {
      target->next = current;
    }
  }

  // merge with previous if possible
  if (previous != NULL &&
      ((void *)(previous + 1) + previous->size == (void *)target)) {
    // printf("can merge with prev\n");
    previous->size += target->size + sizeof(meta_list);
    previous->next = target->next;
  } else if (previous == NULL) {
    metaHead = target;
  } else {
    // printf("not merged with prev\n");
    if ((void *)previous != (void *)target) {
      previous->next = target;
    } else {
      previous->next = NULL;
      metaHead = NULL;
    }
  }
  // printf("target1:%p, current:%p, previous:%p\n", (void *)target,
  //   (void *)current, (void *)previous);
  if (previous != NULL && (current != NULL)) {
    // printf("target2:%p, target next:%p, previous next:%p\n", (void *)target,
    //       (void *)target->next, (void *)previous->next);
  }
  // printf("end free\n");
  // printList();
}

void *bf_malloc(size_t size) {
  meta_list *current;
  meta_list *previous = NULL;
  meta_list *best = NULL;
  meta_list *best_prev = NULL;
  // printf("find for size%zu:\n", size);
  for (current = metaHead; current != NULL;
       previous = current, current = current->next) {
    // printf(("current:%p,best:%p,best_prev:%p,previous:%p\n"), current, best,
    // best_prev, previous);
    if (current->size >= size) {
      // find usable node
      if (best == NULL || best->size > current->size) {
        best = current;
        best_prev = previous;
      }
    }
  }

  if (best != NULL) {
    if (best_prev != NULL) {
      best_prev->next = best->next;
    } else {
      metaHead = best->next;
    }
    return best + 1;
  }
  /*
  if (best != NULL) {
    printf("find usable at%p:\n", best);
    // check if can split
    if (best->size > size + sizeof(meta_list)) {
      printf("can split\n");
      meta_list *newNode = (void *)best + sizeof(meta_list) + size;
      newNode->size = best->size - size -  * sizeof(meta_list);

      newNode->next = best->next;
      best->size = size;
      if (best_prev != NULL) {
        best_prev->next = newNode;
      } else {
        metaHead = newNode;
      }
    }
    // cannot split
    else {
      printf("cannot split\n");
      if (best_prev != NULL) {
        best_prev->next = best->next;
      } else {
        metaHead = best->next;
      }
    }
    // return the part after the meta info
    printf("at split:\n");
    // printList();
    return best + 1;

    // return the part after the meta info
    // printf("at split:\n");
    printList();
    }*/
  else {
    // request new when not found
    current = requestNew(size);
    current->size = size;
    return current + 1;
  }
}

void bf_free(void *ptr) {
  // get the head of the node
  meta_list *target = (meta_list *)ptr - 1;
  meta_list *current = metaHead;
  meta_list *previous = NULL;
  int sign = 0;
  // printf("free:%p(%zu+%zu)\n", target, target->size, sizeof(meta_list));
  if ((void *)target == (void *)current) {
    sign = 1;
    current->next = NULL;
    // return;
  }
  // search for the position to insert
  for (current = metaHead; current != NULL;
       previous = current, current = current->next) {
    // printf("current:%p\n", (void *)current);
    if (current > target) {
      // printf("target:%p, current:%p, previous:%p\n", (void *)target,
      //(void *)current, (void *)previous);
      // printf("target+size:%p\n", (void *)(target + 1) + target->size);
      if (previous != NULL) {
        // printf("prev+size:%p\n", (void *)(previous + 1) + previous->size);
      }
      break;
    }
  }

  // merge with nexts if possible
  if (current != NULL &&
      ((void *)(target + 1) + target->size == (void *)current)) {
    // printf("can merge with next\n");
    target->size += current->size + sizeof(meta_list);
    target->next = current->next;
  } else {
    // printf("not merged with next\n");
    // printf("current:%p\n", (void *)current);
    if (current != NULL) {
      target->next = current;
    }
  }

  // merge with previous if possible
  if (previous != NULL &&
      ((void *)(previous + 1) + previous->size == (void *)target)) {
    // printf("can merge with prev\n");
    previous->size += target->size + sizeof(meta_list);
    previous->next = target->next;
  } else if (previous == NULL) {
    metaHead = target;
  } else {
    // printf("not merged with prev\n");
    if ((void *)previous != (void *)target) {
      previous->next = target;
    } else {
      previous->next = NULL;
      metaHead = NULL;
    }
  }
  // printf("target1:%p, current:%p, previous:%p\n", (void *)target,
  //   (void *)current, (void *)previous);
  if (previous != NULL && (current != NULL)) {
    // printf("target2:%p, target next:%p, previous next:%p\n", (void *)target,
    //       (void *)target->next, (void *)previous->next);
  }
  // printf("end free\n");
  // printList();
}

unsigned long get_data_segment_size() { return totalsize; }

unsigned long get_data_segment_free_space_size() {
  meta_list *current;
  size_t size = 0;
  for (current = metaHead; current != NULL; current = current->next) {
    size += current->size + sizeof(meta_list);
  }
  return size;
}
