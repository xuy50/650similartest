#ifndef __MY_MALLOC_H__
#define __MY_MALLOC_H__

#include <stdlib.h>

// use the idea of single linked list
struct meta_list {
  size_t size;
  struct meta_list *next;
};
typedef struct meta_list meta_list;

// head of the list
void *metaHead = NULL;
size_t totalsize = 0;
size_t freesize = 0;
meta_list *requestNew(size_t size);
void *ff_malloc(size_t size);
void ff_free(void *ptr);
void bf_free(void *ptr);
void *bf_malloc(size_t size);
unsigned long get_data_segment_free_space_size();
unsigned long get_data_segment_size();
#endif
