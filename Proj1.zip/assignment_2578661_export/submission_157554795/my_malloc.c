#include "my_malloc.h"

#include <stdio.h>
#include <unistd.h>

size_t total = 0;
size_t free_size = 0;

block_meta * head =NULL;

block_meta * ff_find_block(size_t size){
    block_meta * cur = head;
    
    if(cur!= NULL){
        while(cur != NULL){
            if(cur->size >= size){
                return cur;
            }else{
                cur = cur->next;
            }
        }
        return NULL;
    }else{
        return NULL;
    }
}

void *create_block(size_t size){
    
    size_t block_size = sizeof(block_meta)+size;
    total= total + block_size;
    block_meta * new_block = sbrk(block_size);
    new_block->size = size;
    new_block->next = NULL;
    new_block->prev = NULL;
    new_block->is_free = 0;
    //if(head == NULL) head = new_block;
    return (void *) new_block + sizeof(block_meta);
}
void add_to_list(block_meta * block){
    if(head == NULL){
        head = block;
        return;
    }
    block_meta * cur = head;
    if(block<head){
        head = block;
        block->next = cur;
        cur->prev = block;
        block->prev = NULL;
        return;
    }
    while(cur != NULL){
        if(cur<block && cur->next == NULL){
            cur->next = block;
            block->prev = cur;
            block->next = NULL;
            return;
        }else if(cur<block && cur->next > block){
            block->next = cur->next;
            block->prev = cur;
            cur->next = block;
            block->next->prev = block;
            return;
        }else{
            cur = cur->next;
        }
    }
    return;
}

void remove_from_list(block_meta * block){
    if(head == block && block->next == NULL){
        head = NULL;
        head->next=NULL;
        head->prev = NULL;
        return;
    }else if(block->next == NULL){
        block->prev->next = NULL;
        block->prev = NULL;
    }else if(block == head){
        head = block->next;
        block->next->prev = NULL;
        block->next = NULL;
    }else{
        block->prev->next = block->next;
        block->next->prev = block->prev;
        block->next = NULL;
        block->prev = NULL;
    }
    
}
void * split(block_meta * cur, size_t size){
    block_meta * new_block;
    if(cur->size - size > sizeof(block_meta)){
        new_block = (void*)cur + size + sizeof(block_meta);
        add_to_list(new_block);
        new_block->size = cur->size - size - sizeof(block_meta);
        remove_from_list(cur);
        cur->size = size;
        free_size = free_size - size - sizeof(block_meta);
        return (void *)cur;
    }else{
        remove_from_list(cur);
        free_size = free_size - size - sizeof(block_meta);
        return (void *)cur;
    }
}

void *ff_malloc(size_t size){
    
    block_meta * cur = NULL;
    if(head!=NULL){
        cur = ff_find_block(size);
    }
    if(cur != NULL){
        return split(cur, size) + sizeof(block_meta);
    }else{
        return create_block(size);
    }
    
    return NULL;
}

void merge_front_to_back(void * p){
    block_meta * cur = p;
    if(cur->next == NULL) return;
    if(cur->next == p + cur->size + sizeof(block_meta)){
        
        cur->size = cur->size + cur->next->size + sizeof(block_meta);
        cur->next = cur->next->next;
        if(cur->next != NULL){
            cur->next->prev = cur;
        }
    }
}

void merge_back_to_front(void * p){
    block_meta * cur = p;
    if(cur->prev == NULL) return;
    if(cur->prev == p - cur->prev->size - sizeof(block_meta)){
        
        cur->prev->size = cur->prev->size + cur->size + sizeof(block_meta);
        cur->prev->next = cur->next;
        if(cur->next != NULL){
            cur->next->prev = cur->prev;
        }
    }
}

void ff_free(void * block){
    block_meta * cur = block - sizeof(block_meta);
    add_to_list(cur);
    free_size = free_size + cur->size + sizeof(block_meta);
    merge_front_to_back(cur);
    merge_back_to_front(cur);
    
}


block_meta * bf_find_block(size_t size){
    block_meta * cur = head;
    block_meta * ans = NULL;
    if(head == NULL) return NULL;
    while(cur != NULL){
      if(cur->size == size) return cur;
      if(cur->size>size){
            if(ans == NULL){
                ans = cur;
            }else{
                if(cur->size<ans->size){
                    ans = cur;
                }
            }
            
        }
        cur = cur->next;
    }
    return ans;
}


void *bf_malloc(size_t size){
    
    block_meta * cur = NULL;
    if(head!=NULL){
        cur = bf_find_block(size);
    }
    if(cur != NULL){
        return split(cur, size) + sizeof(block_meta);
    }else{
        return create_block(size);
    }
    
    return NULL;
}


void bf_free(void * block){
    ff_free(block);
}

unsigned long get_data_segment_size(){
    return total;
}
unsigned long get_data_segment_free_space_size(){
    return free_size;
}
