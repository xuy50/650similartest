#ifndef my_malloc_h
#define my_malloc_h

#include <stdio.h>
#include <unistd.h>

typedef struct block_meta{
  size_t size;
  // 0 means is free
  int is_free;
  struct block_meta *prev;
  struct block_meta *next;

} block_meta;

block_meta * ff_find_block(size_t size);
void *create_block(size_t size);
void add_to_list(block_meta * block);
void remove_from_list(block_meta * block);
void * split(block_meta * cur, size_t size);
void *ff_malloc(size_t size);
void merge_front_to_back(void * p);
void merge_back_to_front(void * p);
void ff_free(void * block);
block_meta * bf_find_block(size_t size);
void *bf_malloc(size_t size);
void bf_free(void * block);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
#endif /* my_malloc_h */
