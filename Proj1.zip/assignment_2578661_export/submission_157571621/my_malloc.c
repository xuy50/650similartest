#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stddef.h>
#include "my_malloc.h"



blk* free_head =NULL; 
blk* free_tail = NULL; 
unsigned long total_size = 0;

void addblk(blk* add){
  if(free_head == NULL){
    free_head = add;
    free_tail = add;
    add->prev = NULL;
    add->next = NULL;
    return;
  }
  blk* cur = free_head;
  while(cur!=NULL){
    if(cur>add){ // ptr of cur is larger than add, we insert our free block before *cur
      add->next = cur;
      add->prev = cur->prev;
      //cur = add;
      if(cur->prev != NULL){
        add->prev->next = add;
      }
      else{
        free_head = add;
      }
      cur->prev = add;
      return;
    }
    cur = cur->next;
  }

  // if not find, meaing the add should be the tail
  add->next = NULL;
  add->prev = free_tail;
  free_tail->next = add;
  free_tail = add;
}

blk*  split (blk* cur, size_t size) {
  //the new free block
  blk* newblk = (blk*)( (char*)cur + METASIZE + size);
  newblk->size = cur->size - size - METASIZE;
  newblk->prev = cur->prev;
  newblk->next = cur->next;

  cur->size = size;
  
  if(cur->prev == NULL){ 
    free_head = newblk;
  }
  else{
    cur->prev->next = newblk;
  }
  if(newblk->next == NULL){
    free_tail = newblk;
  }
  else{
    cur->next->prev = newblk;
  }
  return newblk;
}

void rm_blk( blk* rm){
  if (rm->next != NULL){
    rm->next->prev = rm->prev;
  }
  else{
    free_tail = rm->prev;
  }
  if (rm->prev != NULL){
    rm->prev->next = rm->next;
  }
  else{
    free_head = rm->next;
  }
}


void merge (blk* cur, blk * rm){

  cur->size +=rm->size + METASIZE;
  rm_blk(rm);
}


blk* alloc_new (size_t size){
  blk* cur = sbrk(0); 
  void * ptr = sbrk(size + METASIZE);
  if(ptr == (void*) -1){
    perror("no more enough available space");
    return NULL;
  }
  
  cur->prev = free_tail;
  cur->next = NULL;
  cur->size = size;
  total_size += size + METASIZE;
  return cur;
}


void my_free(void *ptr){
  if(ptr == NULL){
    perror("Nothing to free!");
    return;
  }
  
  blk* free = (blk *)ptr - 1; //(blk* )ptr - 1;
  addblk(free);

   if (free->prev != NULL && (blk *)((char *)free->prev + free->prev->size + METASIZE) == free)
  {
    merge(free->prev, free);
  }
  else if (free->next != NULL && (blk *)((char *)free + free->size + METASIZE) == free->next)
  {
    merge(free, free->next);
  }
}

void *ff_malloc(size_t size){
  blk* cur = free_head;
  while(cur!=NULL){
    if(cur->size>= size){
      if(cur->size > size + METASIZE){
        split(cur, size);
      }
      else{
        rm_blk(cur);
      }
      return (void*)(cur+1);
    }
    cur = cur->next;
  }
  return alloc_new(size)+1;
}

void ff_free(void *ptr){
  my_free(ptr);
}

//Best Fit malloc/free
void *bf_malloc(size_t size){
  blk* cur = free_head;
  blk* free = NULL;
  while(cur!=NULL){
    if(cur->size> size){
      if(free == NULL || free->size > cur->size){
        free = cur;
      }
    }
    else if(cur->size == size){
      free = cur;
      break;
    }
    cur = cur->next;
  }


  if(free ==NULL){
    //printf("sbrk\n");
    free = alloc_new(size);
  }
  else if(free->size > size + METASIZE){ 
    split(free,size);
    //printf("split\n");
  }
  else{
    rm_blk(free);
    //printf("remove\n");
  }

  return (void*)(free+1);
}
  
  
void bf_free(void *ptr){
  my_free(ptr);
}

unsigned long get_data_segment_size(){
  return total_size;
}

unsigned long get_data_segment_free_space_size(){
  blk* cur = free_head;
  unsigned long free_size = 0;
  while(cur!=NULL){
    free_size += cur->size + METASIZE;
    cur= cur->next;
  }
  return free_size;
}

//1.26