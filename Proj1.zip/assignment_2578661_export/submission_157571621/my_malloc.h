#ifndef MY_MALLOC_H
#define MY_MALLOC_H

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stddef.h>


struct block{
  size_t size;
  struct block * next; 
  struct block * prev; 
};

typedef struct block blk;
#define METASIZE sizeof(blk)

// First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

// for performance study
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();




#endif