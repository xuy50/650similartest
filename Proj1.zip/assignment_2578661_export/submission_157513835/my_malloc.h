#ifndef MY_MALLOC_H
#define MY_MALLOC_H
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
struct block_t{
  size_t sz;
  struct block_t* next;
  struct block_t* prev;
};
typedef struct block_t block;
struct block_list_t{
  block* head;
  block* tail;
  size_t sz;
};
typedef struct block_list_t block_list;

block_list* blist=NULL;

void* create_block(size_t size);
int split_block(size_t size, block* b);
void merge_free_block(block*, block*);
void add_to_list(block*);
void ff_free(void* ptr);
void bf_free(void* ptr);
void* ff_malloc(size_t size);
void* bf_malloc(size_t size);
unsigned long get_data_segment_size(); 
long long get_data_segment_free_space_size();
unsigned long total_size=0;
long long free_size=0;
#endif
