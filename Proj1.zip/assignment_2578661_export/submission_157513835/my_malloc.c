#include "my_malloc.h"
#include <assert.h>
#include <limits.h>

unsigned long get_data_segment_size() {
	return total_size;	
}

long long get_data_segment_free_space_size() {
  return free_size;
}

void init_blist(){
//if the blist(free list) is empty, initialize it.
  if(blist==NULL){
    blist = sbrk(sizeof(block_list));
    blist->head = sbrk(sizeof(block));
    blist->tail = sbrk(sizeof(block));
    blist->head->prev = NULL;
    blist->tail->next =NULL;
    blist->sz = 0;
    blist->head->next = blist->tail;
    blist->head->sz = 0;
    blist->tail->prev = blist->head;
    blist->tail->sz = 0;
  }
  return;
}

void* create_block(size_t size){
   	//printf("creating block\n");
   	void* p = sbrk(size+sizeof(block)); // memory for meta and data
    if(p==(void *)-1){
        perror("create block failed\n");  
      exit(EXIT_FAILURE);
    }
    block* new_block = p;
    new_block->sz = size;
    new_block->prev=NULL;
    new_block->next = NULL;
    total_size += size+sizeof(block);
	return new_block+1;
}

int split_block(size_t size, block* b){
    if(size>b->sz){
        return 0; // if the left memory is not enough for second 
    }
    if(size+sizeof(block)>b->sz){
		
		blist->sz--;
		b->prev->next = b->next;
		b->next->prev = b->prev;
		b->next = NULL;
		b->prev = NULL;
		free_size-=sizeof(block)+b->sz;
		return 1; // if the left memory is not enough for second 
		
    }
	//printf("reuse and divide\n");
	free_size -= sizeof(block)+size;
    block* new_b = (block*)((char*)(b+1)+size);
    new_b->sz = b->sz - size - sizeof(block);
	b->prev->next = new_b;
	new_b->prev = b->prev;
	new_b->next = b->next;
	b->next->prev = new_b;
	b->prev = NULL;
	b->next = NULL;
	b->sz = size;
    return 1;
}
void merge_free_block(block* prev_block, block* cur_block){ 
  if((char*)(prev_block+1)+prev_block->sz==(char*)(cur_block)){
      prev_block->next = cur_block->next;
	  cur_block->next->prev = prev_block;
      prev_block->sz = prev_block->sz+sizeof(block)+cur_block->sz;
      blist->sz--;
    }
  return;
}
void add_to_list(block* b){
	//check the tail and its previous because the tail is not the last phy address.
	if((char*)(blist->tail->prev)<(char*)(b)){
		blist->tail->prev->next = b;
		b->prev = blist->tail->prev;
		b->next = blist->tail;
		blist->tail->prev = b;
	}else{
		block* left=blist->head, *right=blist->head->next;
		while(right!=blist->tail){
			if((char*)(left)<(char*)(b) && (char*)(b)<(char*)(right)){
				left->next = b;
				b->prev = left;
				b->next = right;
				right->prev = b;
				blist->sz++;
				return;
			}
			left = left->next;
			right = right->next;
		}
	}
	return ;
}

void ff_free(void* ptr){
  if(ptr==NULL){
    exit(EXIT_FAILURE);
  }
  block* b = (block*)((char*)(ptr)-sizeof(block));
  free_size+=sizeof(block)+b->sz;
  add_to_list(b);
  merge_free_block(b, b->next);
  merge_free_block(b->prev, b);
  return;
}

void bf_free(void* ptr){
  if(ptr==NULL){
    exit(EXIT_FAILURE);
  }
  block* b = (block*)((char*)(ptr)-sizeof(block));
  free_size+=sizeof(block)+b->sz;
  add_to_list(b);
  merge_free_block(b, b->next);
  merge_free_block(b->prev, b);
  return;
}

void* ff_malloc(size_t size){
  init_blist();
  block* cur = blist->head;
  int alloc_success = 0;
  while(cur!=blist->tail){
      alloc_success = split_block(size, cur);
      if(alloc_success==1){
		 return cur+1;
      }
    cur = cur->next;
  }
  //if there is no available block, we create a new block.size
  if(alloc_success==0){
   return create_block(size);
  }
  return NULL;
}

void* bf_malloc(size_t size){
  init_blist();
  block* closest_block = NULL;
  size_t closest_size = UINT_MAX; 
  block* cur = blist->head->next;
  int alloc_success = 0;
  while(cur!=blist->tail){
      if(cur->sz==size){
	  	split_block(size, cur);
		return cur+1;
	  }
	  if(cur->sz>size){
	  	if(closest_size>cur->sz-size){
			closest_size = cur->sz - size;
			closest_block = cur;		
		}
	  }
    cur = cur->next;
  }
  
  //if there is no available block, we create a new block.size
  if(closest_block==NULL){
   return create_block(size);
  }else{
	  if(split_block(size, closest_block)==1)
	  	return closest_block+1;
	  else{
	  	return create_block(size);
	  }
  }
  return NULL;
}
