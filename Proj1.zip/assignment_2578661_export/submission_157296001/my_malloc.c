#include "my_malloc.h"

#include <stdio.h>
#include <unistd.h>

metadata * head = NULL;
size_t data_size = 0;
size_t free_size = 0;

void * ff_malloc(size_t size) {
  if (head == NULL) {
    metadata * temp = sbrk(size + sizeof(metadata));

    if (temp == (void *)-1) {
      return NULL;
    }
    temp->prev = NULL;
    temp->next = NULL;
    temp->bytes = size;

    //
    data_size += size + sizeof(metadata);

    return ((char *)temp + sizeof(metadata));
  }
  else {
    metadata * current = head;
    while (current != NULL) {
      if (current->bytes >= size) {
        //split the region
        if (current->bytes > size + sizeof(metadata)) {
          metadata * temp1 = (metadata *)((char *)current + size + sizeof(metadata));
          temp1->bytes = current->bytes - size - sizeof(metadata);
          //
          free_size -= (size + sizeof(metadata));

          temp1->next = NULL;
          temp1->prev = NULL;

          if (current->prev == NULL && current->next == NULL) {
            temp1->prev = NULL;
            temp1->next = NULL;
            head = temp1;
          }
          else if (current->prev == NULL && current->next != NULL) {
            temp1->prev = NULL;
            head = temp1;
            temp1->next = current->next;
            temp1->next->prev = temp1;
          }
          else if (current->prev != NULL && current->next == NULL) {
            temp1->prev = current->prev;
            temp1->prev->next = temp1;
            temp1->next = NULL;
          }
          else {
            temp1->prev = current->prev;
            temp1->prev->next = temp1;
            temp1->next = current->next;
            temp1->next->prev = temp1;
          }

          //
          current->prev = NULL;
          current->next = NULL;
        }
        else {
          free_size -= (current->bytes + sizeof(metadata));
          if (current->prev == NULL && current->next == NULL) {
            head = NULL;
          }
          else if (current->prev != NULL && current->next == NULL) {
            current->prev->next = NULL;
          }
          else if (current->prev == NULL && current->next != NULL) {
            head = current->next;
            current->next->prev = NULL;
          }
          else {
            current->prev->next = current->next;
            current->next->prev = current->prev;
          }

          current->prev = NULL;
          current->next = NULL;
        }

        current->bytes = size;

        return (char *)current + sizeof(metadata);
      }

      current = current->next;
    }

    metadata * temp2 = sbrk(size + sizeof(metadata));
    if (temp2 == (void *)-1) {
      return NULL;
    }
    temp2->bytes = size;
    temp2->next = NULL;
    temp2->prev = NULL;

    //
    data_size += size + sizeof(metadata);

    return ((char *)temp2 + sizeof(metadata));
  }
}

void ff_free(void * ptr) {
  if (ptr == NULL) {
    return;
  }

  metadata * n = (metadata *)((char *)ptr - sizeof(metadata));

  if (head == NULL || n < head) {
    n->prev = NULL;
    n->next = head;
    if (n->next != NULL) {
      n->next->prev = n;
    }
    head = n;

    merge(n);

    free_size += n->bytes + sizeof(metadata);
  }
  else {
    metadata * curr = head;
    while (curr->next != NULL && n > curr->next) {
      curr = curr->next;
    }
    n->prev = curr;
    n->next = curr->next;
    curr->next = n;
    if (n->next != NULL) {
      n->next->prev = n;
    }

    free_size += n->bytes + sizeof(metadata);
    merge(n);
  }
}

void merge(metadata * h) {
  if (h->next != NULL) {
    if ((char *)h + h->bytes + sizeof(metadata) == (char *)h->next) {
      h->bytes += sizeof(metadata) + h->next->bytes;

      if (h->next->next != NULL) {
        h->next = h->next->next;
        h->next->prev = h;
      }
      else {
        h->next = NULL;
      }
    }
  }
  if (h->prev != NULL) {
    if ((char *)h->prev + sizeof(metadata) + h->prev->bytes == (char *)h) {
      h->prev->bytes += sizeof(metadata) + h->bytes;

      if (h->next != NULL) {
        h->prev->next = h->next;
        h->next->prev = h->prev;
      }
      else {
        h->prev->next = NULL;
      }
    }
  }
}

void * bf_malloc(size_t size) {
  if (size == 0) {
    return NULL;
  }

  if (head == NULL) {
    metadata * temp = sbrk(size + sizeof(metadata));

    if (temp == (void *)-1) {
      return NULL;
    }
    temp->prev = NULL;
    temp->next = NULL;
    temp->bytes = size;

    //
    data_size += size + sizeof(metadata);
    return ((char *)temp + sizeof(metadata));
  }
  else {
    metadata * current = head;
    metadata * position = NULL;

    while (current != NULL) {
      /*
      //the way below is too slow
      if (current->bytes >= size && best_bytes == 0) {
        best_bytes = current->bytes;

        exist = 1;
        position = current;
      }
      else if (current->bytes >= size && best_bytes != 0 && current->bytes < best_bytes) {
        best_bytes = current->bytes;

        position = current;
      }*/
      if (current->bytes > size) {
        if ((position == NULL) || (current->bytes < position->bytes)) {
          position = current;
        }
      }
      if (current->bytes == size) {
        position = current;

        break;
      }

      current = current->next;
    }

    //we can use free memory
    if (position != NULL) {
      //split the region
      if (position->bytes > size + sizeof(metadata)) {
        metadata * temp1 = (metadata *)((char *)position + size + sizeof(metadata));
        temp1->bytes = position->bytes - size - sizeof(metadata);
        //
        free_size -= (size + sizeof(metadata));

        temp1->next = NULL;
        temp1->prev = NULL;

        if (position->prev == NULL && position->next == NULL) {
          temp1->prev = NULL;
          temp1->next = NULL;
          head = temp1;
        }
        else if (position->prev == NULL && position->next != NULL) {
          temp1->prev = NULL;
          head = temp1;
          temp1->next = position->next;
          temp1->next->prev = temp1;
        }
        else if (position->prev != NULL && position->next == NULL) {
          temp1->prev = position->prev;
          temp1->prev->next = temp1;
          temp1->next = NULL;
        }
        else {
          temp1->prev = position->prev;
          temp1->prev->next = temp1;
          temp1->next = position->next;
          temp1->next->prev = temp1;
        }

        //
        position->prev = NULL;
        position->next = NULL;
      }
      else {
        free_size -= (position->bytes + sizeof(metadata));

        if (position->prev == NULL && position->next == NULL) {
          head = NULL;
        }
        else if (position->prev != NULL && position->next == NULL) {
          position->prev->next = NULL;
        }
        else if (position->prev == NULL && position->next != NULL) {
          head = position->next;
          position->next->prev = NULL;
        }
        else {
          position->prev->next = position->next;
          position->next->prev = position->prev;
        }

        position->prev = NULL;
        position->next = NULL;
      }

      position->bytes = size;

      return (char *)position + sizeof(metadata);
    }
    else {
      metadata * temp = sbrk(size + sizeof(metadata));
      if (temp == (void *)-1) {
        return NULL;
      }
      temp->bytes = size;
      temp->next = NULL;
      temp->prev = NULL;

      //
      data_size += size + sizeof(metadata);
      return ((char *)temp + sizeof(metadata));
    }
  }
}

void bf_free(void * ptr) {
  return ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return data_size;
}

unsigned long get_data_segment_free_space_size() {
  return free_size;
}
