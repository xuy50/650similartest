#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

struct _metadata {
  // void * address;
  size_t bytes;
  struct _metadata * next;
  struct _metadata * prev;
};
typedef struct _metadata metadata;

//metadata * head = NULL;

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

void merge(metadata * h);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

//in bytes
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
