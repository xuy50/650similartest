#ifndef MY_MALLOC_H
#define MY_MALLOC_H
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
typedef struct byteblock{
    size_t s;
    struct byteblock* prev;
    struct byteblock* next;
} bblock;

//pointer to the first free block
bblock * first_free_block = NULL;
size_t memory_size = 0;//total memory size
size_t free_list_size = 0;//memory size of free list
//Create new Block in memory
bblock *create_new_block(size_t size);
// Find the first fit block from free list
bblock *get_ff_block_loc(size_t size);
// Find the best fit block from free list
bblock * get_bf_block_loc(size_t size);
//Divide the block into two part according to the size
bblock * divide_block(bblock * block, size_t size);
//Add the block into the free list
void add_into_list(bblock * block);
//Remove the block from the list
void remove_from_list(bblock * block);
//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void merge_free_block(bblock * block);
#endif
