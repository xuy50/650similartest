#include "my_malloc.h"
bblock *create_new_block(size_t size){
if(size == 0){
        return NULL;
    }
    bblock * block = sbrk(size + sizeof(bblock)); 
    if (block == (void *)-1||!block) {
        return NULL;
    }   
    block->s = size;
    block->next = NULL;
    block->prev = NULL;
    memory_size += size + sizeof(bblock);
    return block;
}

bblock *get_ff_block_loc(size_t size){
if(first_free_block==NULL){
        return NULL;  
    }
    bblock * loc = first_free_block;
    for(loc = first_free_block;loc!=NULL;loc = loc->next){
        if (loc->s >= size){
            return loc;
        }
    }
    return loc;
}
bblock *get_bf_block_loc(size_t size){
if(first_free_block==NULL){
        return NULL;
    }
    bblock * best_fit = NULL;
    bblock * loc = first_free_block;
    for(loc = first_free_block;loc!=NULL;loc = loc->next){
        if(loc->s >= size){//find a free fit block
            if(loc->s == size){
                return loc;
            }
            if(best_fit == NULL||best_fit->s > loc->s){//check if it is the option
                best_fit = loc;
            }
        }
    }
    return best_fit;
}
bblock *divide_block(bblock * cur,size_t size){
bblock * free_block =(bblock *)((void*)cur + size + sizeof(bblock));
    free_block->s = cur->s - size - sizeof(bblock);
    add_into_list(free_block);
    remove_from_list(cur);   
    cur->s = size;
    return cur;
}
void remove_from_list(bblock * block){

    if(block == NULL){
        return;
    }
    if(first_free_block == block){//first
        if(block->next!=NULL){
            block->next->prev = NULL;
            first_free_block = first_free_block->next;
        }
        else{
            first_free_block =  NULL;
        }
    }
    else if(block ->next == NULL){//last
         block->prev->next = NULL;
    }
    else{
        if(block->prev!=NULL){
            block->prev->next = block->next;
        }
        if(block->next!=NULL){
            block->next->prev = block->prev;
        }
    }
    free_list_size = free_list_size-block->s - sizeof(bblock);
    block->prev = NULL;
    block->next = NULL;
}

void add_into_list(bblock * block){
   if(block==NULL){
        return;
    }
    if(first_free_block == NULL){
        free_list_size += block->s + sizeof(bblock);
        first_free_block = block;
        block->next = NULL;
        block->prev = NULL;
        return;
    }
    bblock * loc = first_free_block;
   
    do{
        if(block < loc && !loc->prev){////block is before the first
            block->prev = NULL;
            block->next = first_free_block;
            first_free_block->prev = block;
            first_free_block = block;
            free_list_size += block->s + sizeof(bblock);
            return;
        }
        else if(loc < block && loc->next == NULL){//block is end of the list
            block->next = NULL;
            block->prev = loc;
            loc->next = block;
            free_list_size += block->s + sizeof(bblock);
            return;
        }
        else if(loc < block && loc->next > block){//block in the middle of the list
            block->prev = loc;
            block->next = loc->next;
            loc->next->prev = block;
            loc->next = block;
            free_list_size += block->s + sizeof(bblock);
            break;
        }
        else{
            loc = loc->next;
        }
    }while(loc!=NULL);
}

void *ff_malloc(size_t size){

 if(size == 0){//can't malloc 0 byte
        return NULL;
    }
    else {
        bblock * ff_block = get_ff_block_loc(size);
    if (ff_block!=NULL){

        if (ff_block->s - sizeof(bblock) > size ){//need break block
             bblock * newblock = divide_block(ff_block, size);

            if(newblock==NULL){
                return NULL;
            }       
            return (void *)newblock + sizeof(bblock);
             }
        else{
            remove_from_list(ff_block);
            return (void *)ff_block + sizeof(bblock);
        }

    }
    else{
        bblock * newblock = create_new_block(size) ;
        if(newblock==NULL){
            return NULL;
        }
        return (void *)newblock + sizeof(bblock);}
    }
}

void merge_free_block(bblock *block){
    
    if(block==NULL){
        return;
    }
    if(block->next!=NULL){
        if((void*)block->next-block->s -sizeof(bblock) == (void*)block ) {          
            block->s += block->next->s +sizeof(bblock);
            bblock * temp = block->next->next;
            block->next = temp;
            if(temp) {
                temp->prev = block;
            }
        }
    }
    if(block->prev!=NULL){
    if((void*)block->prev == (void*)block - block->prev->s - sizeof(bblock)) {
        block->prev->s += block->s +sizeof(bblock);
        block->prev->next = block->next;
        if (block->next) {
            block->next->prev = block->prev;
        }
    }
    }
}


void ff_free(void *ptr){
    if(ptr==NULL){
        return;
    }   
    bblock * cur = (bblock *)((void *)ptr - sizeof(bblock));
    add_into_list(cur);
    merge_free_block(cur);
}

void *bf_malloc(size_t size){
    if(size==0){
        return NULL;
    }
    bblock * cur = get_bf_block_loc(size);
    if (cur!=NULL){
        if (cur->s - sizeof(bblock) > size ){
             bblock * newblock = divide_block(cur, size);
            if(newblock==NULL){
                return NULL;
            }    
            return (void *)newblock + sizeof(bblock);
             }
        else{
            remove_from_list(cur);
            return (void *)cur + sizeof(bblock);
        }

    }
    else{
        bblock * newblock = create_new_block(size) ;
        if(newblock==NULL){
            return NULL;
        }
        return (void *)newblock + sizeof(bblock);}
    }

void bf_free(void *ptr){
   if(ptr==NULL){
        return;
    }
    bblock * cur = (bblock *)(ptr - sizeof(bblock));
    add_into_list(cur);
    merge_free_block(cur);
}

unsigned long get_data_segment_size(){
    return memory_size;
}
unsigned long get_data_segment_free_space_size(){
    return free_list_size;
}
