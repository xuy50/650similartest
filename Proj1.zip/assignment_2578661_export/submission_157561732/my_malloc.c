#include "my_malloc.h"
#include "unistd.h"
#include "stdio.h"

// Linked list structure
struct mem_block {
    size_t size;
    struct mem_block *next;
    struct mem_block *next_free;
};
typedef struct mem_block mem_block_t;

mem_block_t *head = NULL;
mem_block_t *tail = NULL;
mem_block_t *freelist_head = NULL;

/**
 *
 * @param ptr
 * @return the free block previous to ptr
 */
mem_block_t *add_freelist(mem_block_t *ptr) {
    if (freelist_head == NULL) {
        freelist_head = ptr;
        ptr->next_free = NULL;
        return NULL;
    }

    if (ptr < freelist_head) {
        ptr->next_free = freelist_head;
        freelist_head = ptr;
        return NULL;
    }

    mem_block_t *curr_free = freelist_head;
    while (curr_free != NULL) {
        if (curr_free < ptr) {
            if (curr_free->next_free == NULL || curr_free->next_free > ptr) {
                ptr->next_free = curr_free->next_free;
                curr_free->next_free = ptr;
                return curr_free;
            }
        }
        curr_free = curr_free->next_free;
    }
    return NULL;
}

void merge_freelist(mem_block_t *ptr, mem_block_t *ptr_prevfree) {
    mem_block_t *curr_free;
    if (ptr_prevfree == NULL) {
        curr_free = freelist_head;
    } else {
        curr_free = ptr_prevfree;
    }
    while (curr_free != NULL) {
        if (curr_free->next == ptr) {
            curr_free->size += sizeof(mem_block_t) + ptr->size;
            curr_free->next = ptr->next;
            curr_free->next_free = ptr->next_free;
            if (ptr == tail) {
                tail = curr_free;
            }
            ptr = curr_free;
        }
        if (ptr->next == curr_free) {
            ptr->size += sizeof(mem_block_t) + curr_free->size;
            ptr->next = curr_free->next;
            ptr->next_free = curr_free->next_free;
            if (curr_free == tail) {
                tail = ptr;
            }
            return;
        }
        if (ptr->next != NULL && curr_free > ptr->next) {
            return;
        }
        curr_free = curr_free->next_free;
    }
}

void *ff_malloc(size_t size) {
    if (head == NULL) {
        head = sbrk(0);
        if (sbrk(sizeof(mem_block_t) + size) == (void *) -1) {
            return NULL;
        }
        head->size = size;
        head->next = NULL;
        head->next_free = NULL;
        tail = head;
        return head + 1; // return the address after the metadata
    }

    mem_block_t *curr_free = freelist_head;
    mem_block_t *prev_free = NULL;
    while (curr_free != NULL) {
        if (curr_free->size >= size) {
            if (curr_free->size > size + sizeof(mem_block_t)) {
                void *temp =
                        ((void *) curr_free) + sizeof(mem_block_t) + curr_free->size - (sizeof(mem_block_t) + size);
                mem_block_t *split = (mem_block_t *) temp;
                split->size = size;
                split->next_free = NULL;
                split->next = curr_free->next;

                curr_free->size = curr_free->size - (sizeof(mem_block_t) + size);
                curr_free->next = split;
                if (tail == curr_free) {
                    tail = split;
                }
                return split + 1;
            } else {
                if (prev_free == NULL) {
                    freelist_head = curr_free->next_free;
                } else {
                    prev_free->next_free = curr_free->next_free;
                }
                curr_free->next_free = NULL;
                return curr_free + 1;
            }
        }
        prev_free = curr_free;
        curr_free = curr_free->next_free;
    }

    mem_block_t *newmem;
    if ((newmem = sbrk(sizeof(mem_block_t) + size)) == (void *) -1) {
        return NULL;
    }
    newmem->size = size;
    newmem->next_free = NULL;
    newmem->next = NULL;
    tail->next = newmem;
    tail = newmem;
    return newmem + 1;
}

void ff_free(void *ptr) {
    if (ptr == NULL) {
        return;
    }

    ptr -= sizeof(mem_block_t);

    mem_block_t *curr_block = (mem_block_t *) ptr;

    merge_freelist(curr_block, add_freelist(curr_block));
}

void *bf_malloc(size_t size) {
    if (head == NULL) {
        head = sbrk(0);
        if (sbrk(sizeof(mem_block_t) + size) == (void *) -1) {
            return NULL;
        }
        head->size = size;
        head->next = NULL;
        head->next_free = NULL;
        tail = head;
        return head + 1; // return the address after the metadata
    }

    mem_block_t *curr_free = freelist_head;
    mem_block_t *prev_free = NULL;

    mem_block_t *best_curr_free = NULL;

    while (curr_free != NULL) {
        if (curr_free->size >= size) {
            if (curr_free->size > size + sizeof(mem_block_t)) {
                if (best_curr_free == NULL) {
                    best_curr_free = curr_free;
                } else {
                    if (curr_free->size < best_curr_free->size) {
                        best_curr_free = curr_free;
                    }
                }
            } else {
                if (prev_free == NULL) {
                    freelist_head = curr_free->next_free;
                } else {
                    prev_free->next_free = curr_free->next_free;
                }
                curr_free->next_free = NULL;
                return curr_free + 1;
            }
        }
        prev_free = curr_free;
        curr_free = curr_free->next_free;
    }
    if (best_curr_free == NULL) {
        mem_block_t *newmem;
        if ((newmem = sbrk(sizeof(mem_block_t) + size)) == (void *) -1) {
            return NULL;
        }
        newmem->size = size;
        newmem->next_free = NULL;
        newmem->next = NULL;
        tail->next = newmem;
        tail = newmem;
        return newmem + 1;
    }

    void *temp = ((void *) best_curr_free) + sizeof(mem_block_t) + best_curr_free->size - (sizeof(mem_block_t) + size);
    mem_block_t *split = (mem_block_t *) temp;
    split->size = size;
    split->next_free = NULL;
    split->next = best_curr_free->next;

    best_curr_free->size = best_curr_free->size - (sizeof(mem_block_t) + size);
    best_curr_free->next = split;
    if (tail == best_curr_free) {
        tail = split;
    }
    return split + 1;
}


void bf_free(void *ptr) {
    ff_free(ptr);
}

unsigned long get_data_segment_size() {
    if (head == NULL) {
        return 0;
    }
    return (void *) tail + sizeof(mem_block_t) + tail->size - (void *) head;
}

unsigned long get_data_segment_free_space_size() {
    unsigned long size = 0;
    mem_block_t *curr = freelist_head;
    while (curr != NULL) {
        size += sizeof(mem_block_t) + curr->size;
        curr = curr->next_free;
    }
    return size;
}

void printAllNodes() {
    mem_block_t *curr = head;
    int count = 0;
    while (curr != NULL) {
        printf("Node %d:\n", count);
        printf("Node address = %p\n", curr);
        printf("Node size = %zu\n", curr->size);
        count++;
        curr = curr->next;
    }
    printf("Tail Node address = %p\n", tail);
    printf("Tail Node size = %zu\n", tail->size);
}

void printFreeNodes() {
    mem_block_t *curr = freelist_head;
    int count = 0;
    while (curr != NULL) {
        printf("Free Node %d:\n", count);
        printf("Free Node address = %p\n", curr);
        printf("Free Node size = %zu\n", curr->size);
        count++;
        curr = curr->next_free;
    }
}

void printNodes() {
    printAllNodes();
    printFreeNodes();
}
