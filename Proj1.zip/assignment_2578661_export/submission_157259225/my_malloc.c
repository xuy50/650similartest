#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define block_size sizeof(mem_block)

/*To keep track of the block, I used a mem_block,
to indicate all the memory block allocated by sbrk,
however, I will have a freed field to indicate if it is freed,
and for the freed ones, they will be attached to a freed_block_head.
To find the adjacent block in O(1), a prior_size field is added.
 */

typedef struct _mem_block {
  size_t space_size;
  size_t prior_size;
  int freed;  //0 is not freed, 1 is freed
  struct _mem_block * next_freed;
  struct _mem_block * prev_freed;
} mem_block;

static mem_block freed_block_head = {0, 0, 0, NULL, NULL};
static void * heap_start = 0;
static mem_block * last_alloc = NULL;

//First fit polic malloc
void * ff_malloc(size_t size) {
  mem_block ** curr_block = &(freed_block_head.next_freed);
  //traverse the freed list to find a block
  while ((*curr_block) != NULL) {
    //find a block that can hold the new size
    if ((*curr_block)->space_size >= size) {
      if ((*curr_block)->space_size <= 2 * (size + block_size)) {
        //Indicate this is not big enough
        void * return_addr = (void *)((char *)(*curr_block) + block_size);
        mem_block * prev = (*curr_block)->prev_freed;
        mem_block * next = (*curr_block)->next_freed;
        //disconnect the current one from the linked list
        (*curr_block)->freed = 0;  //indicate it is used
        (*curr_block)->prev_freed = NULL;
        (*curr_block)->next_freed = NULL;
        prev->next_freed = next;
        //if the current one is the last one;
        if (next != NULL) {
          next->prev_freed = prev;
        }
        return return_addr;
      }
      else {
        //Find a larger block need to split
        size_t new_block_size = (*curr_block)->space_size - size - block_size;
        //construct a new block
        mem_block * new_block = (mem_block *)((char *)(*curr_block) + size + block_size);
        if (*curr_block == last_alloc) {
          last_alloc = new_block;
        }
        //store the return address
        void * return_addr = (void *)((char *)(*curr_block) + block_size);
        mem_block * prev = (*curr_block)->prev_freed;
        mem_block * next = (*curr_block)->next_freed;
        //Update the newly created block info
        new_block->freed = 0;
        new_block->prior_size = size;
        new_block->space_size = new_block_size;
        new_block->prev_freed = prev;
        new_block->next_freed = next;
        //disconnect the current one from the linked list
        (*curr_block)->space_size = size;
        (*curr_block)->freed = 0;  //indicate it is freed
        (*curr_block)->prev_freed = NULL;
        (*curr_block)->next_freed = NULL;
        prev->next_freed = new_block;
        //if the current one is the last one;
        if (next != NULL) {
          next->prev_freed = new_block;
        }
        //update the actually next on memory
        if (new_block != last_alloc) {
          //there is a actual next block
          mem_block * actual_next =
              (mem_block *)((char *)new_block + block_size + new_block_size);
          if ((void *)actual_next < sbrk(0)) {
            actual_next->prior_size = new_block_size;
          }
        }
        return return_addr;
      }
    }
    else {
      curr_block = &(*curr_block)->next_freed;
    }
  }
  //If there is no available block, malloc new with sbrk
  mem_block * new_addr = (mem_block *)sbrk(block_size + size);
  assert(new_addr != (void *)-1);
  if (heap_start == 0) {
    //For the first time record the start of the malloc heap_start
    heap_start = new_addr;
  }
  if (last_alloc != NULL) {
    new_addr->prior_size = last_alloc->space_size;
  }
  else {
    //If this the first time, set the prior_size=0
    new_addr->prior_size = 0;
  }
  last_alloc = new_addr;
  //Set the new block info
  new_addr->freed = 0;
  new_addr->space_size = size;
  new_addr->next_freed = NULL;
  new_addr->prev_freed = NULL;
  return (char *)new_addr + block_size;
}
//First fit free block
void ff_free(void * ptr) {
  //Find the real start
  mem_block * block_start = (mem_block *)((char *)ptr - block_size);
  assert(block_start->freed == 0);
  //Update it as freed block
  block_start->freed = 1;
  mem_block * front = NULL;
  mem_block * next = NULL;
  mem_block * occup_next = NULL;
  //Find if there is a freed front block
  if (block_start != heap_start) {
    front = (mem_block *)((char *)block_start - block_start->prior_size - block_size);
    if (front->freed == 0) {
      front = NULL;
    }
  }
  //Find if there is a freed back block
  if (block_start != last_alloc) {
    next = (mem_block *)((char *)(block_start) + block_size + block_start->space_size);
    if (next->freed == 0) {
      occup_next = next;
      next = NULL;
    }
  }
  if (front != NULL) {
    //there is a front freed list,disconnect
    assert(front->freed == 1);
    mem_block * front_front = front->prev_freed;
    mem_block * front_next = front->next_freed;
    if (front_front != NULL) {
      front_front->next_freed = front_next;
    }
    if (front_next != NULL) {
      front_next->prev_freed = front_front;
    }
    //Merge with the front block
    front->space_size += (block_start->space_size + block_size);
    if (occup_next != NULL) {
      assert(occup_next == (mem_block *)((char *)front + front->space_size + block_size));
      occup_next->prior_size = front->space_size;
    }
    if (block_start == last_alloc) {
      last_alloc = front;
    }
    //Update the block needed to be added as merged front
    block_start = front;
  }
  if (next != NULL) {
    //There is a back block needed to be merged
    assert(next->freed == 1);
    //Disconnect the block from the list
    mem_block * next_front = next->prev_freed;
    mem_block * next_next = next->next_freed;
    if (next_front != NULL) {
      next_front->next_freed = next_next;
    }
    if (next_next != NULL) {
      next_next->prev_freed = next_front;
    }
    //Merge the block with the back one
    block_start->space_size += (next->space_size + block_size);
    if (next == last_alloc) {
      //if the merged one is the last one, update the last one
      last_alloc = block_start;
    }
    else {
      //Update the actual next block's prior info
      mem_block * actual_next =
          (mem_block *)((char *)(block_start) + block_size + block_start->space_size);
      actual_next->prior_size = block_start->space_size;
    }
  }
  //connect the newly freed(merged or not)to the list
  //Add front
  mem_block * curr = freed_block_head.next_freed;
  if (curr != NULL) {
    curr->prev_freed = block_start;
  }
  block_start->freed = 1;
  block_start->next_freed = curr;
  block_start->prev_freed = &freed_block_head;
  freed_block_head.next_freed = block_start;
  return;
}
//Best fit policy malloc
void * bf_malloc(size_t size) {
  mem_block ** curr_block = &(freed_block_head.next_freed);
  //traverse the freed list to find a block
  mem_block ** best_match = NULL;
  while ((*curr_block) != NULL) {
    //find a block that can hold the new size
    if ((*curr_block)->space_size == size) {
      //If there is a block perfectly fit, return immediately
      best_match = curr_block;
      break;
    }
    else if ((*curr_block)->space_size > size) {
      //If founded a larger block
      if (best_match == NULL || (*curr_block)->space_size < (*best_match)->space_size) {
        //Update if necessary
        best_match = curr_block;
      }
      curr_block = &(*curr_block)->next_freed;
    }
    else {
      curr_block = &(*curr_block)->next_freed;
    }
  }
  //If there is a best_match block
  if (best_match != NULL) {
    if ((*best_match)->space_size <= 2 * (size + block_size)) {
      //If it is not large enough to split
      void * return_addr = (void *)((char *)(*best_match) + block_size);
      mem_block * prev = (*best_match)->prev_freed;
      mem_block * next = (*best_match)->next_freed;
      //disconnect the current one from the linked list
      (*best_match)->freed = 0;  //indicate it is used
      (*best_match)->prev_freed = NULL;
      (*best_match)->next_freed = NULL;
      //curr_block = &next;
      prev->next_freed = next;
      //if the current one is the last one;
      if (next != NULL) {
        next->prev_freed = prev;
      }
      return return_addr;
    }
    else {
      //if it large enough to split
      size_t new_block_size = (*best_match)->space_size - size - block_size;
      //construct a new block
      mem_block * new_block = (mem_block *)((char *)(*best_match) + size + block_size);
      if (*best_match == last_alloc) {
        last_alloc = new_block;
      }
      void * return_addr = (void *)((char *)(*best_match) + block_size);
      mem_block * prev = (*best_match)->prev_freed;
      mem_block * next = (*best_match)->next_freed;
      new_block->freed = 0;
      new_block->prior_size = size;
      new_block->space_size = new_block_size;
      new_block->prev_freed = prev;
      new_block->next_freed = next;
      //disconnect the current one from the linked list
      (*best_match)->space_size = size;
      (*best_match)->freed = 0;  //indicate it is freed
      (*best_match)->prev_freed = NULL;
      (*best_match)->next_freed = NULL;
      prev->next_freed = new_block;
      //if the current one is the last one;
      if (next != NULL) {
        next->prev_freed = new_block;
      }
      //update the actually next on memory
      if (new_block != last_alloc) {
        //there is a actual next block
        mem_block * actual_next =
            (mem_block *)((char *)new_block + block_size + new_block_size);
        if ((void *)actual_next < sbrk(0)) {
          actual_next->prior_size = new_block_size;
        }
      }
      return return_addr;
    }
  }
  //If there is no avaialbe block, alloc with sbrk
  mem_block * new_addr = (mem_block *)sbrk(block_size + size);
  assert(new_addr != (void *)-1);
  if (heap_start == 0) {
    //printf("only once\n");
    heap_start = new_addr;
  }
  if (last_alloc != NULL) {
    new_addr->prior_size = last_alloc->space_size;
  }
  else {
    new_addr->prior_size = 0;
  }
  last_alloc = new_addr;
  new_addr->freed = 0;
  new_addr->space_size = size;
  new_addr->next_freed = NULL;
  new_addr->prev_freed = NULL;
  return (char *)new_addr + block_size;
}
//Best fit free is the same as the first fit policy
void bf_free(void * ptr) {
  mem_block * block_start = (mem_block *)((char *)ptr - block_size);
  assert(block_start->freed == 0);
  block_start->freed = 1;
  mem_block * front = NULL;
  mem_block * next = NULL;
  mem_block * occup_next = NULL;
  if (block_start != heap_start) {
    front = (mem_block *)((char *)block_start - block_start->prior_size - block_size);
    if (front->freed == 0) {
      front = NULL;
    }
  }
  if (block_start != last_alloc) {
    next = (mem_block *)((char *)(block_start) + block_size + block_start->space_size);
    if (next->freed == 0) {
      occup_next = next;
      next = NULL;
    }
  }
  if (front != NULL) {
    //there is a front freed list,disconnect
    assert(front->freed == 1);
    mem_block * front_front = front->prev_freed;
    mem_block * front_next = front->next_freed;
    if (front_front != NULL) {
      front_front->next_freed = front_next;
    }
    if (front_next != NULL) {
      front_next->prev_freed = front_front;
    }
    front->space_size += (block_start->space_size + block_size);
    if (occup_next != NULL) {
      assert(occup_next == (mem_block *)((char *)front + front->space_size + block_size));
      occup_next->prior_size = front->space_size;
    }
    if (block_start == last_alloc) {
      last_alloc = front;
    }
    block_start = front;
  }
  if (next != NULL) {
    assert(next->freed == 1);
    mem_block * next_front = next->prev_freed;
    mem_block * next_next = next->next_freed;
    if (next_front != NULL) {
      next_front->next_freed = next_next;
    }
    if (next_next != NULL) {
      next_next->prev_freed = next_front;
    }
    block_start->space_size += (next->space_size + block_size);
    if (next == last_alloc) {
      //if the merged one is the last one, update the last one
      last_alloc = block_start;
    }
    else {
      mem_block * actual_next =
          (mem_block *)((char *)(block_start) + block_size + block_start->space_size);
      actual_next->prior_size = block_start->space_size;
    }
  }
  //connect the newly freed(merged or not)to the list
  mem_block * curr = freed_block_head.next_freed;
  if (curr != NULL) {
    curr->prev_freed = block_start;
  }
  block_start->freed = 1;
  block_start->next_freed = curr;
  block_start->prev_freed = &freed_block_head;
  freed_block_head.next_freed = block_start;
  return;
}
//Use the recorded heap_start to find the total allocate memory
unsigned long get_data_segment_size() {
  return sbrk(0) - heap_start;
}
//Traverse the freed list to find the freed_space
unsigned long get_data_segment_free_space_size() {
  unsigned long sum = 0;
  mem_block ** curr = &freed_block_head.next_freed;
  while (*curr) {
    sum += (*curr)->space_size;
    curr = &(*curr)->next_freed;
  }
  return sum;
}
