#include "my_malloc.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

size_t whole_size = 0;  //space of stored data + space of metadata
size_t free_size = 0;   //free usable space to store data + metadata
Block * head = NULL;
Block * tail = NULL;

//The remove_block function removes block from the free list after they are reused.
void remove_block(Block * cur) {
  if (cur->prev != NULL) {
    cur->prev->next = cur->next;
  }
  else {
    head = cur->next;
  }
  if (cur->next != NULL) {
    cur->next->prev = cur->prev;
  }
  else {
    tail = cur->prev;
  }
}

//The add_block funtion adds block into free list after splitting or freeing.
void add_block(Block * new_block) {
  if (head == NULL) {
    head = new_block;
    tail = new_block;
    new_block->prev = NULL;
    new_block->next = NULL;
    return;
  }
  Block * cur = head;
  while (cur != NULL && cur < new_block) {
    cur = cur->next;
  }
  if (cur == head) {
    new_block->next = head;
    head->prev = new_block;
    head = new_block;
    new_block->prev = NULL;
    return;
  }
  else if (cur == NULL) {
    new_block->prev = tail;
    tail->next = new_block;
    tail = new_block;
    new_block->next = NULL;
    return;
  }
  else {
    new_block->prev = cur->prev;
    cur->prev->next = new_block;
    new_block->next = cur;
    cur->prev = new_block;
  }
}

//The split_block funtion splits a block by removing the whole block and add back the second part of block that is not used.
void split_block(Block * cur, size_t size) {
  Block * splitted_free_block = (Block *)((char *)cur + sizeof(Block) + size);
  splitted_free_block->size = cur->size - size - sizeof(Block);
  cur->size = size;
  splitted_free_block->prev = NULL;
  splitted_free_block->next = NULL;
  remove_block(cur);
  add_block(splitted_free_block);
}

//The reuse_block function split the block if the remain part is big enough the hold data further,
//or use it directly and remove it from the list
void * reuse_block(Block * cur, size_t size) {
  if (cur->size > size + sizeof(Block)) {  //split the Block into two
    free_size -= (size + sizeof(Block));
    split_block(cur, size);
    return (char *)cur + sizeof(Block);
  }
  else {  //use the Block directly and remove from the list
    free_size -= (cur->size + sizeof(Block));
    remove_block(cur);
    return (char *)cur + sizeof(Block);
  }
}

//The create_space funtion allocate new space in heap using sbrk()
void * create_space(size_t size) {
  Block * new_block = sbrk(size + sizeof(Block));
  if (new_block == (void *)-1) {
    return NULL;
  }
  whole_size += size + sizeof(Block);

  new_block->size = size;
  new_block->prev = NULL;
  new_block->next = NULL;

  return (char *)new_block + sizeof(Block);
}

//First fit malloc
void * ff_malloc(size_t size) {
  Block * cur = head;
  while (cur != NULL) {
    //Find a free region
    if (cur->size >= size) {
      return reuse_block(cur, size);
    }
    cur = cur->next;
  }

  //Failed to find fit free region:allocate new region(increase whole_size)
  return create_space(size);
}

//Best fit malloc
void * bf_malloc(size_t size) {
  Block * cur = head;
  Block * best = NULL;
  while (cur != NULL) {
    if (cur->size == size) {  //==size, is the best, stop finding
      best = cur;
      break;
    }
    if (cur->size > size &&
        (best == NULL || cur->size < best->size)) {  //update best pointer
      best = cur;
    }
    cur = cur->next;
  }

  if (best == NULL) {
    return create_space(size);
  }
  else {
    return reuse_block(best, size);
  }
}

//The free_regions takes a pointer and free the block, add it back to free list,
//and merge blocks if its next/previous block is adjacent.
void free_regions(void * p) {
  if (p == NULL) {
    return;
  }
  //free the block itself
  Block * to_free = (Block *)((char *)p - sizeof(Block));
  free_size += to_free->size + sizeof(Block);
  add_block(to_free);

  //merge the next free block
  if (to_free->next != NULL &&
      ((char *)to_free + to_free->size + sizeof(Block) == (char *)to_free->next)) {
    to_free->size += to_free->next->size + sizeof(Block);
    remove_block(to_free->next);
  }
  //merge the pre free block
  Block * prev_free = to_free->prev;
  if (prev_free != NULL &&
      ((char *)prev_free + prev_free->size + sizeof(Block) == (char *)to_free)) {
    prev_free->size += to_free->size + sizeof(Block);
    remove_block(to_free);
  }
}

//First fit's free
void ff_free(void * ptr) {
  free_regions(ptr);
}

//Best fit's free
void bf_free(void * ptr) {
  free_regions(ptr);
}

//get whole_size
unsigned long get_data_segment_size() {
  return whole_size;
}

//get free_size
unsigned long get_data_segment_free_space_size() {
  return free_size;
}
