#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define SIZEOF_META sizeof(mnode_t)
#define BFMAX 1000000000
//#define DEBUG
typedef struct mnode {
  struct mnode *next;
  size_t size;
} mnode_t;

mnode_t *ff_mn_head = NULL;
mnode_t *bf_mn_head = NULL;
unsigned long data_segment_size = 0;

mnode_t *alloc_new(size_t size);
void *get_data_seg(mnode_t *meta);
void *next_continue_addr(mnode_t *meta);
mnode_t *cut_mem(mnode_t *meta, size_t size);
mnode_t *combine_mem(mnode_t *pre, mnode_t *bac);

// Find where to insert freed node
mnode_t *search_insert(mnode_t *head, mnode_t *freed);

//@return node before target; head; NULL
mnode_t *ff_search(size_t size);
mnode_t *bf_search(size_t size);

void _malloc_free(void *ptr, mnode_t **head);

void *ff_malloc(size_t size);
void ff_free(void *ptr);
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

// For check
void show_free_allocation();
