#include "my_malloc.h"

mnode_t *alloc_new(size_t size) {
  mnode_t *node = (mnode_t *)sbrk(SIZEOF_META + size);
  if (node == (void *)-1) {
    return NULL;
  }
  data_segment_size += size + SIZEOF_META;
  node->next = NULL;
  node->size = size;
#ifdef DEBUG
  printf("[new allocated:%p; size:%lu; next continue address:%p]\n", node, size,
         next_continue_addr(node));
#endif
  return node;
}

void *get_data_seg(mnode_t *meta) { return (void *)meta + SIZEOF_META; }

void *next_continue_addr(mnode_t *meta) {
  return get_data_seg(meta) + meta->size;
}

mnode_t *ff_search(size_t size) {
#ifdef DEBUG
  assert(ff_mn_head != NULL);
#endif
  if (ff_mn_head->size >= size) {
    return ff_mn_head;
  }
  mnode_t *curr = ff_mn_head;
  while (curr->next != NULL && curr->next->size < size) {
    curr = curr->next;
  }
  return curr;
}

mnode_t *cut_mem(mnode_t *meta, size_t size) {
#ifdef DEBUG
  printf("cut mem:%p, size:%lu\n", meta, size);
  assert(meta->size >= size);
#endif
  if (meta->size <= size + SIZEOF_META) {
    return meta;
  } else {
    size_t remain_size = meta->size - size - SIZEOF_META;
    mnode_t *submeta = (mnode_t *)(get_data_seg(meta) + remain_size);
    submeta->next = NULL;
    submeta->size = size;
    meta->size = remain_size;
    return submeta;
  }
}

void *ff_malloc(size_t size) {
#ifdef DEBUG
  printf("want allocated size:%lu\n", size);
#endif
  if (ff_mn_head == NULL) {
    mnode_t *allocated = alloc_new(size);
    if (allocated == NULL) {
      return NULL;
    }
    return get_data_seg(allocated);
  }
  mnode_t *pre = ff_search(size);
  if (pre->size >= size) {
#ifdef DEBUG
    assert(pre == ff_mn_head);
#endif
    mnode_t *allocated = cut_mem(pre, size);
    if (allocated == pre) {
      ff_mn_head = ff_mn_head->next;
    }
    allocated->next = NULL;
#ifdef DEBUG
    printf("get allocated:%p; size:%lu\n", allocated, allocated->size);
    show_free_allocation();
#endif
    return get_data_seg(allocated);
  } else if (pre->next != NULL) {
#ifdef DEBUG
    assert(pre->next->size >= size);
#endif
    mnode_t *allocated = cut_mem(pre->next, size);
    if (pre->next == allocated) {
      pre->next = pre->next->next;
    }
    allocated->next = NULL;
#ifdef DEBUG
    printf("get allocated:%p; size:%lu\n", allocated, allocated->size);
    show_free_allocation();
#endif
    return get_data_seg(allocated);
  } else {
    mnode_t *allocated = alloc_new(size);
    if (allocated == NULL) {
      return NULL;
    }
    return get_data_seg(allocated);
  }
}

mnode_t *combine_mem(mnode_t *pre, mnode_t *bac) {
#ifdef DEBUG
  printf("combine:%p %p\n", pre, bac);
  assert(next_continue_addr(pre) == bac);
#endif
  pre->size += SIZEOF_META + bac->size;
  return pre;
}

mnode_t *search_insert(mnode_t *head, mnode_t *freed) {
#ifdef DEBUG
  assert(head != NULL && head != freed);
#endif
  if (freed < head || next_continue_addr(head) == freed) {
    return NULL;
  }
  mnode_t *pre = head;
  mnode_t *bac = pre->next;
  while (bac != NULL) {
    if (freed < bac || next_continue_addr(bac) == freed) {
      return pre;
    }
    pre = bac;
    bac = bac->next;
  }
  return pre;
}

void ff_free(void *ptr) { _malloc_free(ptr, &ff_mn_head); }

unsigned long get_data_segment_size() { return data_segment_size; }

unsigned long get_data_segment_free_space_size() {
  unsigned long size = 0;
  mnode_t *curr = ff_mn_head;
  if (curr == NULL) {
    curr = bf_mn_head;
  }
  while (curr != NULL) {
    size += curr->size + SIZEOF_META;
    curr = curr->next;
  }
  return size;
}

// For check
void show_free_allocation() {
  mnode_t *curr = ff_mn_head;
  if (curr == NULL) {
    curr = bf_mn_head;
  }
  printf("...........meta data size:%lu...........\n", SIZEOF_META);
  while (curr != NULL) {
    printf("-------------------------------------------------------------------"
           "---\n");
    printf("[address:%p] [next continue addr:%p] [size:%lu]\n", curr,
           next_continue_addr(curr), curr->size);
    curr = curr->next;
  }
}

mnode_t *bf_search(size_t size) {
#ifdef DEBUG
  assert(bf_mn_head != NULL);
#endif
  mnode_t *pre = NULL;
  mnode_t *curr = bf_mn_head;

  size_t sm_diff = BFMAX;
  mnode_t *target_pre = NULL;
  while (curr != NULL) {
    if (curr->size >= size) {
      size_t diff = curr->size - size;
      if (diff == 0) {
        return pre;
      }
      if (diff < sm_diff) {
        sm_diff = diff;
        target_pre = pre;
      }
    }
    pre = curr;
    curr = curr->next;
  }
  return target_pre;
}

void *bf_malloc(size_t size) {
#ifdef DEBUG
  printf("bf: want allocated size:%lu\n", size);
#endif
  if (bf_mn_head == NULL) {
    mnode_t *allocated = alloc_new(size);
    if (allocated == NULL) {
      return NULL;
    }
    return get_data_seg(allocated);
  }
  mnode_t *pre = bf_search(size);
  if (pre == NULL) {
    // target is head
    if (bf_mn_head->size >= size) {
      mnode_t *allocated = cut_mem(bf_mn_head, size);
      if (allocated == bf_mn_head) {
        bf_mn_head = bf_mn_head->next;
      }
      allocated->next = NULL;
#ifdef DEBUG
      printf("bf: get allocated:%p; size:%lu\n", allocated, allocated->size);
      show_free_allocation();
#endif
      return get_data_seg(allocated);
    } else {
      // no match
      mnode_t *allocated = alloc_new(size);
      if (allocated == NULL) {
        return NULL;
      }
      return get_data_seg(allocated);
    }
  } else {
#ifdef DEBUG
    assert(pre->next != NULL && pre->next->size >= size);
#endif
    mnode_t *allocated = cut_mem(pre->next, size);
    if (pre->next == allocated) {
      pre->next = pre->next->next;
    }
    allocated->next = NULL;
#ifdef DEBUG
    printf("bf: get allocated:%p; size:%lu\n", allocated, allocated->size);
    show_free_allocation();
#endif
    return get_data_seg(allocated);
  }
}

void _malloc_free(void *ptr, mnode_t **head) {
  mnode_t *meta = (mnode_t *)(ptr - SIZEOF_META);
#ifdef DEBUG
  printf("free target:%p; next continue address:%p\n", meta,
         next_continue_addr(meta));
#endif
  meta->next = NULL;
  if (*head == NULL) {
    *head = meta;
    meta->next = NULL;
#ifdef DEBUG
    show_free_allocation();
#endif
    return;
  }
  mnode_t *pre = search_insert(*head, meta);
  if (pre == NULL) {
    // target is head
    if (meta < *head) {
      if (next_continue_addr(meta) == *head) {
        combine_mem(meta, *head);
        meta->next = (*head)->next;
        *head = meta;
      } else {
        meta->next = *head;
        *head = meta;
      }
    } else {
      // if (next_continue_addr(ff_mn_head) == meta) {
      combine_mem(*head, meta);
      // in case of 0 <-> (1) <-> 2 ...
      if (next_continue_addr(meta) == (*head)->next) {
        combine_mem(*head, (*head)->next);
        (*head)->next = (*head)->next->next;
      }
    }
  } else if (pre->next != NULL) {
    if (meta < pre->next) {
      if (next_continue_addr(meta) == pre->next) {
        combine_mem(meta, pre->next);
        meta->next = pre->next->next;
      } else {
        meta->next = pre->next;
      }
      pre->next = meta;
    } else {
      // if (next_continue_addr(pre->next) == meta) {
      combine_mem(pre->next, meta);
      // in case of 3 <-> (4) <-> 5 ...
      if (next_continue_addr(meta) == pre->next->next) {
        combine_mem(pre->next, pre->next->next);
        pre->next->next = pre->next->next->next;
      }
    }
  } else {
    pre->next = meta;
  }
#ifdef DEBUG
  show_free_allocation();
#endif
}

void bf_free(void *ptr) { _malloc_free(ptr, &bf_mn_head); }
