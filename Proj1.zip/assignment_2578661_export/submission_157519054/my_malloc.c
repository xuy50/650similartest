#include "my_malloc.h"
#include <unistd.h>
#include <stdint.h>
#define meta sizeof(Node)

// this function is to implement the first fit malloc
void * ff_malloc(size_t size){
    //find the node in linked list that mem is bigger than required size
    Node * cur = head;
    while(cur){
        if(cur->mem >= size){
            split(size, cur);
            remove_node(cur);
            return (void *) cur + meta;
        }
        cur = cur->next;
    }
    //if there is no node or no suitable node in linked list, allocate the new space use sbrk
    return allocate_new_space(size);
}


// this function is to use sbrk to allocate new space
void * allocate_new_space(size_t size){
    Node * new_node = (Node *)sbrk((int)(size + meta));
    heap_size  = heap_size + size + meta;
    new_node->next = NULL;
    new_node->mem = size;
    return (void *) new_node + meta;
}

// this function is to implement the first fit free
void ff_free(void *ptr){
    //add the node in the linked list and merge the adjacent regions
    void * addr = (void *)ptr - meta;
    Node * new_node = (Node *) addr;
    //if there is no node in linked list, add at head
    if(!head){
        new_node->next = NULL;
        head = new_node;
        return;
    }
    Node * temp = head;
    while(temp){
        //find the node's address that is larger than new_node
        if((void *)temp > addr){
            Node * prev = get_prev(temp);
            //add at head
            if(prev == NULL){
                new_node->next = temp;
                head = new_node;
                merge(new_node);
                return;
            }
            //add at middle
            prev->next = new_node;
            new_node->next = temp;
            merge(new_node);
            merge(prev);
            return;
        }
        temp = temp->next;
    }
    //if we can't find temp node' address larger than new node, we should add it at end
    Node * cur_end = head;
    while(cur_end->next){
        cur_end = cur_end->next;
    }
    cur_end->next = new_node;
    new_node->next = NULL;
    //don't need to check prev existence because if prev equals to NULL, head equals to NULL
    merge(cur_end);
    return;
}




// this function is to implement the Best Fit malloc
void *bf_malloc(size_t size){
    Node * temp = head, * cur = NULL;
    // find the node in linked list that contains the smallest mem
    // greater than or equal to the requested allocation size
    int diff = INT32_MAX;
    while(temp){
        if(temp->mem >= size && (temp->mem - size) < diff){
            if(temp->mem == size){
                cur = temp;
                break;
            }
            diff = temp->mem - size;
            cur = temp;
        }
        temp = temp->next;
    }
    if(cur){
        split(size, cur);
        remove_node(cur);
        return (void *) cur + meta;
    }
    //if there is no node or no suitable node in linked list
    //allocate the new space use sbrk
    return allocate_new_space(size);
}

// this function is best fit free, the implementation is the same as the first fit free
void bf_free(void *ptr){
    ff_free(ptr);
}

//this function is to merge the newly freed region with any adjacent region with larger address
void merge(Node * cur){
    if((void *)cur + meta + cur->mem == cur->next){
        cur->mem = cur->mem + meta + cur->next->mem;
        remove_node(cur->next);
    }
}

//this function is to split the memory block in linked list
//after we split the node, the left memory space should still be in linked list
//while the used-part node should be deleted in linked list in the remove_node function
void split(size_t size, Node * cur){
    // if the left space is smaller than or equal to metadata size
    // there is no need to split the node
    if(cur->mem - size <= meta) return;
    Node * temp = cur->next;
    cur->next = (Node *)((void *)cur+meta+size);
    cur->next->next = temp;
    cur->next->mem = cur->mem - meta - size;
    cur->mem = size;
    return;
}

//this function is to get the previous node
Node * get_prev(Node * cur){
    if(cur == head){
        return NULL;
    }
    Node * temp = head;
    while(temp->next != cur){
        temp = temp->next;
    }
    return temp;
}

// this function is to remove the node
void remove_node(Node * cur){
    //remove at head
    if(cur == head){
        head = cur->next;
        cur->next = NULL;
        return;
    }
    //find previous node of cur
    Node * prev = get_prev(cur);
    //remove at the end
    if(cur->next == NULL){
        prev->next = NULL;
        return;
    }
    //remove at middle
    prev->next = cur->next;
    cur->next = NULL;
    return;
}


// this function is for performance experiment
// return in bytes
// get the entire heap memory, including metadata size
unsigned long get_data_segment_size(){
    return heap_size;
}

// this function is for performance experiment
// return in byte
// get the size of the "free list", including metadata size
unsigned long get_data_segment_free_space_size(){
    Node * cur = head;
    unsigned long free_size = 0;
    while(cur){
        free_size += cur->mem + meta;
        cur = cur->next;
    }
    return free_size;
}

