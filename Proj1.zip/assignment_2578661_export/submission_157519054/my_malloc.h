#include <stdio.h>

#ifndef MYMALLOC_MY_MALLOC_H
#define MYMALLOC_MY_MALLOC_H

typedef struct Node_t{
    size_t mem;
    struct Node_t * next;
}Node;

Node * head = NULL;

unsigned long heap_size = 0;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);


void merge(Node * cur);

void split(size_t size, Node * cur);

void * allocate_new_space(size_t size);

Node * get_prev(Node * cur);

void remove_node(Node * cur);

//for performance
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte


#endif //MYMALLOC_MY_MALLOC_H
