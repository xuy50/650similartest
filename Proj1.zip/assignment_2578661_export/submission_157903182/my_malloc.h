#include <stdio.h>
#include <stdlib.h>

struct metadata{
    struct metadata * prev;
    struct metadata * next;
    size_t size; 
};
typedef struct metadata meta;

void * ff_malloc(size_t size);
void ff_free(void * ptr);

void * bf_malloc(size_t size);
void bf_free(void * ptr);

void * allocate(size_t size,meta * p);
void free_region(void * ptr);
void insert_freelist(meta * current);
void remove_freelist( meta * current);
void * split_region(size_t size,meta * ptr);
meta * compare(size_t size,meta * p,meta * best);
void merge_back(meta * current);
void merge_front(meta * current);

// void print_freeList();

unsigned long entire_heap_memory = 0;
unsigned long get_data_segment_size();             //in bytes
unsigned long get_data_segment_free_space_size();  //in bytes