#include <stdio.h>
#include <unistd.h>
#include <limits.h>

#include "my_malloc.h"

//Initialiazation of free list head and tail
block_t * free_head = NULL;
block_t * free_tail = NULL;

//For analyzation of fragmentation
unsigned long data_segment_size = 0;
long long data_segment_free_space_size = 0;
unsigned long get_data_segment_size(){ return data_segment_size; }
unsigned long get_data_segment_free_space_size(){ return data_segment_free_space_size; }

//ff malloc and free function
void *ff_malloc(size_t size){ return help_malloc(size, 0); }
void ff_free(void *ptr){ help_free(ptr); }

//bf malloc and free function
void *bf_malloc(size_t size){ return help_malloc(size, 1); }
void bf_free(void *ptr){ help_free(ptr); }

//This function is to implement malloc in either FF or BF way
//When type is 0, it performs FF search, when type is 1, it performs a BF search
void *help_malloc(size_t size, int type){
  if(free_head == NULL){
    //request new memory block
    block_t * new_block = alloc_block(size);
    if(new_block != NULL)
      return (block_t *)((char *)new_block + sizeof(block_t));
    else 
      return NULL;
  }

  //use FF of BF to find suitable block in free list
  block_t * tar_block = NULL;
  if(type == 0){
    tar_block = find_ff(size);
  }else if(type == 1){
    tar_block = find_bf(size);
  }else{
    printf("Invalid type!\n");
    return NULL;
  }
  
  if(tar_block == NULL){
    //request new memory block
    block_t * new_block = alloc_block(size);
    if(new_block != NULL)
      return (block_t *)((char *)new_block + sizeof(block_t));
    else 
      return NULL;
  }

  if(tar_block->size > size + 2 * sizeof(block_t)){
    //split to a new free block
    data_segment_free_space_size -= size + sizeof(block_t);
    block_t * new_block = split_block(tar_block, size);
    return (block_t *)((char *)new_block + sizeof(block_t));
  }else{
    //directly malloc
    data_segment_free_space_size -= tar_block->size + sizeof(block_t);
    freelist_remove(tar_block);
    return (block_t *)((char *)tar_block + sizeof(block_t));
  }
}

//This function is to split target block into 2 parts
//It returns the splited new block and resizes target block
block_t * split_block(block_t * tar_block, size_t size){
  block_t * new_block = (block_t *)((char *)tar_block + tar_block->size - size);
  new_block->size = size;
  new_block->next = NULL;
  new_block->prev = NULL;
  tar_block->size -= sizeof(block_t) + size;
  return new_block;
}

//This function is to find the best fit block in freelist in FF way
block_t * find_ff(size_t size){
  block_t * it = free_head;
  while(it!= NULL){
    if(it->size >= size){
      return it;
    }
    it = it->next;
  }
  return NULL;
}

//This function is to find the best fit block in freelist in BF way
block_t * find_bf(size_t size){
  block_t * it = free_head;
  block_t * temp = NULL;
  int diff = INT_MAX;
  while(it != NULL){
    if(it->size == size){
      return it;
    }
    if(it->size >= size && it->size - size < diff){
      diff = it->size - size;
      temp = it;
    }
    it = it->next;
  }
  return temp;
}

//This function is to ask new memory for a new block
block_t * alloc_block(size_t size){
  block_t * ptr = sbrk(size + sizeof(block_t));
  if (ptr == (block_t *)((char *)(-1))) {
    return NULL;
  }
  data_segment_size += size + sizeof(block_t);
  block_t * new_block = ptr;
  new_block->size = size;
  new_block->next = NULL;
  new_block->prev = NULL;
  return new_block;
}

//This function is to implement free function
void help_free(void *ptr){
  if(ptr == NULL){ return; }
  block_t *temp = (block_t *)((char *)ptr - sizeof(block_t));
  freelist_add(temp);
  freelist_merge(temp);
}

//This is to help print out freelist when debugging
void print_freeList() {
  block_t * p = free_head;
  while (p != NULL) {
    printf("p: %p, p->size: %lu\n", (void *)p, p->size);
    p = p->next;
  }
  printf("\n\n");
}

//This function is to add a new block into freelist in order of address
void freelist_add(block_t * block){
  data_segment_free_space_size += block->size + sizeof(block_t);

  if(free_head == NULL){
    //no block in freelist
    free_head = block;
    free_tail = block;
    block->next = NULL;
    block->prev = NULL;
    return;
  }

  if((block_t *)block < (block_t *)free_head){
    //put block in head
    free_head->prev = block;
    block->next = free_head;
    block->prev = NULL;
    free_head = block;
  }else if((block_t *)block > (block_t *)free_tail){
    //put block in tail
    free_tail->next = block;
    block->prev = free_tail;
    block->next = NULL;
    free_tail = block;
  }else{
    //iterate to put block in middle
    block_t * cur = free_head;
    while(cur != NULL){
      if((block_t *)block < (block_t *)cur){
        cur->prev->next = block;
        block->prev = cur->prev;
        cur->prev = block;
        block->next = cur;
        break;
      }
      cur = cur->next;
    }
  }
}

//This function is to merge freelist which is adjacent in address
void freelist_merge(block_t * block){
  if(block->next && ((block_t *)((char *)block + sizeof(block_t) + block->size) == block->next)){
    //merge block to next
    mem_merge(block);
  }

  if(block->prev && ((block_t *)((char *)block->prev + sizeof(block_t) + block->prev->size) == block)){
    //merge prev to block
    mem_merge(block->prev);
  }

}

//This function is to merge block to its next block
void mem_merge(block_t * block){
  block->size += (sizeof(block_t) + block->next->size);
  if(block->next == free_tail){
    block->next->prev = NULL;
    block->next->next = NULL;
    block->next->size = 0;
    block->next = NULL;
    free_tail = block;
  }else{
    block_t * next = block->next;
    block->next = next->next;
    next->next->prev = block;
    next->next = NULL;
    next->prev = NULL;
    next->size = 0;
  }
}

//This function is to remove block from freelist
void freelist_remove(block_t * block){
  block_t * prev = block->prev;
  block_t * next = block->next;

  block->prev = NULL;
  block->next = NULL;
  if(prev != NULL){
    prev->next = next;
  }else{
    free_head = next;
  }
  if(next != NULL){
    next->prev = prev;
  }else{
    free_tail = prev;
  }
}
