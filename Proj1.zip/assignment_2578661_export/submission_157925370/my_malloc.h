#ifndef __MY_MALLOC_H__
#define __MY_MALLOC_H__

#include <stdio.h>
#include <unistd.h>

typedef struct _block_t{
  struct _block_t * next;
  struct _block_t * prev;
  size_t size;
}block_t;

void *ff_malloc(size_t size);
void ff_free(void *ptr);

void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

void *help_malloc(size_t size, int type);
block_t * find_ff(size_t size);
block_t * find_bf(size_t size);
block_t * alloc_block(size_t size);
block_t * split_block(block_t * block, size_t size);
void print_freeList();
void help_free(void *ptr);
void freelist_add(block_t * block);
void freelist_merge(block_t * block);
void mem_merge(block_t * block);
void freelist_remove(block_t * block);

#endif 
