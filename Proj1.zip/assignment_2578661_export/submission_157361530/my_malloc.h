#ifndef __MY_MALLOC_H__
#define __MY_MALLOC_H__

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>

/// @brief doublelinked list that represents a list of free memory regions
typedef struct DoubleLinkedNode
{
    /* data */
    // pointer to next free list node
    struct DoubleLinkedNode *next;
    // pointer to prev free list node
    struct DoubleLinkedNode *prev;
    // requested size of memory
    size_t size;
} LinkedNode;

void *ff_malloc(size_t size);

void ff_free(void *ptr);

void *ff_FindFreeRegion(size_t size);

void *bf_malloc(size_t size);

void bf_free(void *ptr);

void *bf_FindFreeRegion(size_t size);

void splitting(LinkedNode *nodeToSplit, size_t size);

void removeNode(LinkedNode *nodeToRemove);

void addNode(LinkedNode *nodeToAdd);

void merging(LinkedNode *nodeToMerge);

unsigned long get_data_segment_size(); //in bytes

unsigned long get_data_segment_free_space_size(); //in byte

#endif