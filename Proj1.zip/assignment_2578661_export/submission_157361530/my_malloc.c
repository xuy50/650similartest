#include "my_malloc.h"

/// @brief freelist head
LinkedNode *head = NULL;
/// @brief freelist tail
LinkedNode *tail = NULL;

/// @brief entire heap memory
unsigned long totalSize = 0;

/// @brief thread-unsafe first fit malloc()
/// @param size size of requested size of memory
/// @return return a pointer to the allocated memory, which is suitably aligned for any built-in type
void *ff_malloc(size_t size)
{
    // NULL may be returned by a successful call to malloc() with a size of zero
    if (size == 0)
    {
        return NULL;
    }
    void *ans = ff_FindFreeRegion(size);
    // if there is no free space that fits an allocation space, call sbrk() to increase the heap
    if (ans == NULL)
    {
        void *temp = sbrk(sizeof(LinkedNode) + size);
        // if sbrk() fails, return NULL
        if (temp == (void *)-1)
        {
            return NULL;
        }
        totalSize += sizeof(LinkedNode) + size;
        LinkedNode *node = (LinkedNode *)temp;
        node->next = NULL;
        node->prev = NULL;
        node->size = size;
        return (void *)((char *)node + sizeof(LinkedNode));
    }
    return ans;
}

/// @brief thread-unsafe first fit free()
/// @param ptr pointer return by a previous call to ff_malloc()
void ff_free(void *ptr)
{
    if (ptr == NULL)
    {
        return;
    }
    // add node to free list
    LinkedNode *nodeToAdd = (LinkedNode *)((char *)ptr - sizeof(LinkedNode));
    addNode(nodeToAdd);
    // try to merge nodes after adding a new node
    merging(nodeToAdd);
}

/// @brief find the first fit region
/// @param size size of requested size of memory
/// @return return a pointer to suitable region, NULL may be returned if it fails to find a suitable region
void *ff_FindFreeRegion(size_t size)
{
    LinkedNode *curr = head;
    while (curr != NULL)
    {
        if (curr->size >= size)
        {
            // if remaining region is larger than the size of metadata
            if (curr->size - size > sizeof(LinkedNode))
            {
                splitting(curr, size);
            }
            // remove soon-to-be-occupied nodes from freelist
            removeNode(curr);
            return (char *)curr + sizeof(LinkedNode);
        }
        curr = curr->next;
    }
    // return NULL if there is no suitable region or free region
    return NULL;
}

/// @brief thread-unsafe best fit malloc()
/// @param size size of requested size of memory
/// @return return a pointer to the allocated memory, which is suitably aligned for any built-in type
void *bf_malloc(size_t size)
{
    // NULL may be returned bt a successful call to malloc() with a size of zero
    if (size == 0)
    {
        return NULL;
    }
    void *ans = bf_FindFreeRegion(size);
    // if there is no free space that fits an allocation space, call sbrk() to increase the heap
    if (ans == NULL)
    {
        void *temp = sbrk(sizeof(LinkedNode) + size);
        // if sbrk() fails, return NULL
        if (temp == (void *)-1)
        {
            return NULL;
        }
        totalSize += sizeof(LinkedNode) + size;
        LinkedNode *node = (LinkedNode *)temp;
        node->next = NULL;
        node->prev = NULL;
        node->size = size;
        return (void *)((char *)node + sizeof(LinkedNode));
    }
    return ans;
}

/// @brief thread-unsafe first fit free()
/// @param ptr pointer return by a previous call to ff_malloc()
void bf_free(void *ptr)
{
    if (ptr == NULL)
    {
        return;
    }
    // add node to free list
    LinkedNode *nodeToAdd = (LinkedNode *)((char *)ptr - sizeof(LinkedNode));
    addNode(nodeToAdd);
    // try to merge nodes after adding a new node
    merging(nodeToAdd);
}

/// @brief find the best fit region
/// @param size size of requested size of memory
/// @return return a pointer to suitable region, NULL may be returned if it fails to find a suitable region
void *bf_FindFreeRegion(size_t size)
{
    LinkedNode *curr = head;
    // pointer to the best-fit region
    LinkedNode *bestFit = NULL;
    while (curr != NULL)
    {
        // if the space in the current node is equal to the space to be allocated, then it is the best fit
        if (curr->size == size)
        {
            bestFit = curr;
            break;
        }
        if (curr->size > size)
        {
            if (bestFit == NULL)
            {
                bestFit = curr;
            }
            else if (bestFit->size > curr->size)
            {
                bestFit = curr;
            }
        }
        curr = curr->next;
    }
    // if no free area or no suitable area found, return NULL
    if (bestFit == NULL)
    {
        return NULL;
    }
    if (bestFit->size - size >= sizeof(LinkedNode))
    {
        splitting(bestFit, size);
    }
    removeNode(bestFit);
    return (char *)bestFit + sizeof(LinkedNode);
}

/// @brief splitting the free region being used
/// @param nodeToSplit free region to be split
/// @param size size to be split from nodeToSplit
void splitting(LinkedNode *nodeToSplit, size_t size)
{
    assert(nodeToSplit != NULL);
    LinkedNode *newNode = (LinkedNode *)((char *)nodeToSplit + sizeof(LinkedNode) + size);
    newNode->next = nodeToSplit->next;
    // insert newNode into freelist
    // tail insertion
    if (newNode->next == NULL)
    {
        tail = newNode;
    }
    else
    {
        newNode->next->prev = newNode;
    }
    newNode->prev = nodeToSplit;
    nodeToSplit->next = newNode;
    newNode->size = nodeToSplit->size - sizeof(LinkedNode) - size;
    assert(newNode->size >= 0);
    nodeToSplit->size = size;
}

/// @brief remove node from freelist
/// @param nodeToRemove node to be removed
void removeNode(LinkedNode *nodeToRemove)
{
    if (nodeToRemove->prev != NULL)
    {
        nodeToRemove->prev->next = nodeToRemove->next;
    }
    // update the head if head is removed
    else
    {
        head = head->next;
    }

    if (nodeToRemove->next != NULL)
    {
        nodeToRemove->next->prev = nodeToRemove->prev;
    }
    // update the tail if tail is removed
    else
    {
        tail = nodeToRemove->prev;
    }

    nodeToRemove->next = NULL;
    nodeToRemove->prev = NULL;
}

/// @brief add node to freelist
/// @param nodeToAdd node to be added
void addNode(LinkedNode *nodeToAdd)
{
    if (head == NULL)
    {
        head = nodeToAdd;
        tail = nodeToAdd;
        return;
    }
    // add from head
    LinkedNode *curr = head;
    if (curr > nodeToAdd)
    {
        nodeToAdd->next = curr;
        curr->prev = nodeToAdd;
        head = nodeToAdd;
        return;
    }
    // add to tail
    if (tail < nodeToAdd)
    {
        nodeToAdd->prev = tail;
        tail->next = nodeToAdd;
        tail = nodeToAdd;
        return;
    }
    // add in the middle
    while (curr < nodeToAdd)
    {
        curr = curr->next;
    }
    nodeToAdd->next = curr;
    nodeToAdd->prev = curr->prev;
    curr->prev->next = nodeToAdd;
    curr->prev = nodeToAdd;
}

/// @brief try to merge the region added to freelist with the first region before and after it
/// @param nodeToMerge node to be merged
void merging(LinkedNode *nodeToMerge)
{
    // check the next node
    // merge if the end of the current node and start of the next node are the same
    if (nodeToMerge->next != NULL && (char *)nodeToMerge + nodeToMerge->size + sizeof(LinkedNode) == (char *)nodeToMerge->next)
    {
        nodeToMerge->size = nodeToMerge->size + sizeof(LinkedNode) + nodeToMerge->next->size;
        removeNode(nodeToMerge->next);
    }
    // check the prev node
    // merge if the end of the prev node and start of the current node are the same
    if (nodeToMerge->prev != NULL && (char *)nodeToMerge->prev + sizeof(LinkedNode) + nodeToMerge->prev->size == (char *)nodeToMerge)
    {
        nodeToMerge->prev->size = nodeToMerge->prev->size + sizeof(LinkedNode) + nodeToMerge->size;
        removeNode(nodeToMerge);
    }
}

/// @brief get entire heap memory (this includes memory used to save metadata)
/// @return size of entire heap memory
unsigned long get_data_segment_size()
{
    return totalSize;
}

/// @brief (actual usable free space + space occupied by metadata) of the blocks in the free list
/// @return size of the "free list"
unsigned long get_data_segment_free_space_size()
{
    LinkedNode *curr = head;
    unsigned long ans = 0;
    while (curr != NULL)
    {
        ans += curr->size + sizeof(LinkedNode);
        curr = curr->next;
    }
    return ans;
}