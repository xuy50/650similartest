
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>


// /*
// EachListDat is used as a double linked list, each of size 1 and it 
// tracks how many blocks are in the ListData with its size
// */
// typedef struct EachListData_t{
//     struct EachListData_t* head;
//     struct EachListData_t* tail;
//     struct EachListData_t* next;
//     struct EachListData_t* prev;
//     int freeBlock;
// }EachListData;

/*
ListData is used as a double linked list, each set of blocks is considered as one part
*/
typedef struct ListData_t{
    struct ListData_t* prev; // Record the previous free memory region
    struct ListData_t* next; // Record the next free memory region
    size_t size; // The size
}ListData;


/*Required methods*/
//First fit
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best fit
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//helper methods
void my_free(void* ptr);
void* my_malloc(size_t size, int ffOrbf);


/*
Finding the first or best fit: These two methods work as finder
*/
ListData* malloc_helper_firstFit(ListData* temp);
// void malloc_helper_bestFit(ListData* start);
ListData *malloc_helper_bestFit(ListData* temp);

/*
Tool methods: These methods work as helper methods
*/
void setListData( ListData* ld, ListData* n, ListData* p, size_t size);
void *useExistingData(ListData* curr, size_t size);
void deleteFreeRegion(ListData* curr);
void addFreeRegion(ListData* curr);
void printListData();

//Getting the space
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


