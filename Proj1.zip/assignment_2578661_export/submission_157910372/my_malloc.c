
#include "my_malloc.h" 

#define HEADER_SIZE   sizeof(ListData)

ListData* head_free = NULL; //The head of the list that tracks the free memory regions
ListData* all_free;
size_t mallocSize;
size_t addressFirst;
int sz = HEADER_SIZE; //Get the size of ListData 
unsigned long size_for_all = 0;


// For testing the dataset
void printListData(){
    //printf("all: %ld\n", size_for_all);
    //printf("free: %ld\n", size_for_free);
    // curr = head_free;
    ListData* curr = head_free;
    while(curr != NULL){
        printf(" the curr - address is : %p, ", curr);
        // printf("%p\n", curr->next);
        // printf("%p\n", curr->prev);
        printf("%ld\n", curr->size);
        curr = curr->next;
    }
    printf("\n\n");
}

/*
A method that initialize the data
*/
void setListData(ListData* ld, ListData* n, ListData* p, size_t size){
    ld->next = n;
    ld->prev = p;
    ld->size = size;
}

//Tool methods: add, delete
/*
This method adds the free region in the front of the list by its address
*/
void addFreeRegion(ListData* curr){
    //1. If the list is empty
    if(head_free == NULL){
        head_free = curr;
        head_free->next = NULL;
        head_free->prev = NULL;
        return;
    }

    //2. If the curr's address is before head, curr becomes head
    else if(curr < head_free){
        curr->next = head_free;
        head_free->prev = curr;
        curr->prev = NULL;
        head_free = curr;
        return; 
    }
    // //3. If the curr's address is after the end, curr becomes the end
    // else if(curr > end){
    //     end->next = curr;
    //     curr->prev = end;
    //     curr->next = NULL;
    //     end = curr;
    //     printf("end address: %p\n", end);
    // }
    
    ListData* temp = head_free;
    // ListData* test = head_free;//to test the list

    while(temp != NULL){
        //adding curr in the middle
        if(temp < curr && temp->next > curr){
            curr->next = temp->next;
            curr->prev = temp;
            temp->next = curr;
            curr->next->prev = curr;
            return;
        }
        //adding curr in the end
        if(curr > temp && temp->next == NULL){
            temp->next = curr;
            curr->prev = temp;
            curr->next = NULL;
            return;
        }
        temp = temp->next;
    };
}


/*
This method deletes the free region in the list, which means the space has been allocated
It deletes the curr in the ListData
*/
void deleteFreeRegion(ListData* curr){
    //1. curr is an empty block: do nothing
    if(curr == NULL){
        return;
    }

    //2. curr is the only block: head_free is empty now!
    if(curr->prev == NULL && curr->next == NULL){
        head_free = NULL;//to be checked!
        return;
    }
    
    //3. curr is the head: else if: curr->next is not empty!
    else if(curr == head_free){       
        head_free = curr->next;
        head_free->prev = NULL;

        curr->next = NULL;
    }
    //4. curr is in the ending
    else if(curr->next == NULL){
        curr->prev->next = NULL;

        curr->prev = NULL;
    }
    //5. curr is in the middle
    else{
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        curr->next = NULL;
        curr->prev = NULL;
    }
    
}

/*
This method reused the block by checking whether to split the current block
Pay attention that curr is not NULL!
*/
void *useExistingData(ListData* curr, size_t size){
    int splitFlag; //1: need to split; 0: does not need to split

    //  printf("test! cur->size: %d, compare size+sizeof(lds):%d\n", curr->size, size + HEADER_SIZE);

   //When the block is larger enough to hold the current data
    if(curr->size > size + HEADER_SIZE){
        ListData* new_free = (ListData *)((char*)curr + size + HEADER_SIZE);//The new block starting address
        ListData* prev = curr->prev;
        ListData* next = curr->next;

        //Adding the new free block into the list: add first because it needs the current location
        //If the curr is the only block
        if(prev == NULL && next == NULL){
            head_free = new_free; //Directly set head here 
            head_free->next = NULL;
            head_free->prev = NULL;
        }
        //If the curr is the head 
        else if(curr == head_free){
            head_free = new_free; //putting the starting of head to new_free
            new_free->next = next;
            next->prev = new_free;
            new_free->prev = NULL;

            curr->next = NULL;
        }
        //If the curr is the last node in the list
        else if(next == NULL){
            prev->next = new_free;
            new_free->next = NULL;
            new_free->prev = prev;

            curr->next = NULL;
            curr->prev = NULL;
        }
        else{
            prev->next = new_free;
            new_free->prev = prev;
            new_free->next = next;
            next->prev = new_free;
            
            curr->prev = NULL;
            curr->next = NULL;
        }
        new_free->size = curr->size - size - HEADER_SIZE;
        ListData* test = head_free;
        curr->size = size;//Updating the current size!
    }
    //The perfect block
    // else if(curr->size == (size + HEADER_SIZE)){
    //     return curr + HEADER_SIZE;
    // }
    
    else{
        deleteFreeRegion(curr);
    }
    return (char*)curr + HEADER_SIZE; //malloc returns the ending address of the allocation
}


//For First Fit Policy
/*
Using recursion to find the first free space
*/
ListData* malloc_helper_firstFit(ListData* curr){
    if(head_free == NULL){
        return NULL;
    }
    curr = head_free;
    if(curr->size >= mallocSize){
        return curr;
    }
    //If the free list reaches its end or the size is greater or equal to the desire size
    while(curr != NULL){
        if(curr->size >= mallocSize){
            return curr;
        }
        curr = curr->next;
    };
    return curr;
}



/*
The helper method for best fit malloc
*/
ListData* malloc_helper_bestFit(ListData* temp){
    int minSize = INT_MAX;
    ListData* find = NULL;
    //Finding the best fit: the greater smallest block in the DataList
    while(temp != NULL){
        if(temp->size == mallocSize){
            return temp;
        }
        else if(temp->size > mallocSize){
            if(temp->size < minSize){
                minSize = temp->size;
                find = temp;
            }
        }
        temp = temp->next;
    };
    return find;
}

/*
This method mallocs the memory depends on first fit policy(0) or best fit policy(1)
*/
void* my_malloc(size_t size, int ffOrbf){
    mallocSize = size; //The size that needs to malloc

    //If the size is 0 malloc returns NULL
    if(size == 0){
        return NULL;
    }

    ListData* f = head_free;

    //If the function is first fit (passed on value is 0)
    if(ffOrbf == 0){
        f = malloc_helper_firstFit(f);
    }
    //If the function is best fit (passed on value is 1)
    if(ffOrbf == 1){
        f = malloc_helper_bestFit(f);
    }
    
    //If the the block is not found, directly allocate it and return the malloced space
    if(f == NULL){  
        //Increase the size for the total heap
        size_for_all += (mallocSize + HEADER_SIZE); 

        //Allocate the space for newAllocation
        ListData* newAllocation = sbrk(mallocSize + HEADER_SIZE);

        //Initialize the data
        setListData(newAllocation, NULL, NULL, mallocSize); 

        return (void*) newAllocation + HEADER_SIZE; 
    }
    //If the block is found, reuse the block
    return useExistingData(f, size);
}

void my_free(void* ptr){
    //If the current pointer is NULL, return direcly 
    if(ptr == NULL){
        return;
    }
    //Getting the curr needed-to-be freed region: minus the header size
    ListData* temp = (ListData*)((void*)ptr - HEADER_SIZE);

    if(temp == NULL){
        return;
    }
    //Adding the free region into the list
    addFreeRegion(temp);

    //Checking whether it can be merge and merge it if needed
    if(temp->next != NULL){
        if(temp->next == (void*)temp + temp->size + HEADER_SIZE){
            ListData* next = temp->next;
            if(next == NULL){
                return;
            }
            ListData* connect = next->next; //The next block to connect
            temp->next = connect; 
            if(connect){
                connect->prev = temp;
            }

            //Increase the current size: combine two together
            temp->size += next->size + HEADER_SIZE;
        }

    }
    if(temp->prev != NULL){
        if((void*)temp->prev + temp->prev->size + HEADER_SIZE == (void*)temp){
            ListData* prev = temp->prev;
            prev->next = temp->next;
            if(temp->next != NULL){
                temp->next->prev = prev;
            }

            //Increase the current size: combine two together
            prev->size += temp->size + HEADER_SIZE;
        }
    }
}


/*
First fit malloc and free.
*/
void *ff_malloc(size_t size){
   my_malloc(size, 0);
}
void ff_free(void *ptr){ 
   my_free(ptr);
}

/*
Best fit malloc and free.
*/
void *bf_malloc(size_t size){
   my_malloc(size, 1);
}
void bf_free(void *ptr){
    my_free(ptr);
}

//Entire heap memory(includes memory used to sve metadata) - in bytes
unsigned long get_data_segment_size(){
    return size_for_all; //Increse every time it allocates new space
}

//Size of the "free list" is actual usable free space + space occupied by metadata of the blocks in the free list
unsigned long get_data_segment_free_space_size(){
    unsigned long sz = 0;
    ListData* temp = head_free;
    while(temp != NULL){
        sz += temp->size + HEADER_SIZE;
        temp = temp->next;
    }
    return sz;
}