#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct Datablock{
  size_t size;
  struct Datablock* prev;
  struct Datablock* next;
}Datablock;

void *ff_malloc(size_t size);
void ff_free(void *ptr);

void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

Datablock* matcher(size_t size);
void node_delete(Datablock* node);
void node_add(Datablock* node);
void* split(Datablock* finder, size_t size);
void* true_malloc(size_t size);