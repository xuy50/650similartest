#include "my_malloc.h"

// user block_holder to indicate the block currently linked
Datablock* block_holder = NULL;
// // use two global sizes to record memory size
size_t block_size = 0;
size_t freelist_size = 0;
// the data now has been examined and is ready to be allocated

void* true_malloc(size_t size){
  block_size += size + sizeof(Datablock);
// now new_holder will be used as the new segement connecting with the original block
  Datablock* new_holder = sbrk(size+ sizeof(Datablock));
  new_holder->size = size;
  new_holder->prev = NULL;
  new_holder->next = NULL;
  return (void*) new_holder + sizeof(Datablock);
}

void* ff_malloc(size_t size){
  if (block_holder != NULL){
    Datablock* finder = block_holder;
    while(finder != NULL){
      if (finder->size >= size){
        freelist_size -= size+sizeof(Datablock);
        if (finder->size > size+sizeof(Datablock)){
          return split(finder, size);
        }
        else{
           node_delete(finder);
           return (void *)finder + sizeof(Datablock);
        }
      }
      else{
        finder = finder->next;
      }
    }

    return true_malloc(size);
  }
  else{
    return true_malloc(size);
  }
}

void* split(Datablock* finder, size_t size){
  // the pointer to the starter
  void* header = (void*)finder + sizeof(Datablock);
  Datablock* blank = (Datablock*)(header+size);
  blank->size = finder->size - size - sizeof(Datablock);
  finder->size = size;
  node_add(blank);
  node_delete(finder);
  return (void*) finder +sizeof(Datablock);
}

void node_add(Datablock* node){
  if (block_holder == NULL){
    block_holder = node;
    return;
  }


  Datablock* temp = block_holder;
  if (node < block_holder){
    block_holder = node;
    node->next = temp;
    temp->prev = block_holder;
    block_holder->prev = NULL;
    return;
  }
// add the node in the order of its size
// Datablock* temp = block_holder;

  while ((temp->next != NULL) && (node > temp->next)){
    temp = temp->next;
  }
  node->prev = temp;
  node->next = temp->next;
  temp->next = node;
  if (node->next != NULL){
    node->next->prev = node;
  }
}

void node_delete(Datablock* node){
  if (node->next == NULL && node->prev == NULL){
    node->prev = NULL; node->next = NULL;
    block_holder = NULL;
  }
  else if (node->prev == NULL){
    block_holder = node->next;
    node->next->prev = NULL;
    node->next = NULL;
  }

  else if (node->next == NULL){
    node->prev->next = NULL;
    node->prev = NULL;
  }
  else{
    node->prev->next = node->next;
    node->next->prev = node->prev;
    node->prev = NULL;
    node->next = NULL;
  }
}

void ff_free(void* ptr){
  Datablock* finder = (Datablock*)((void*)ptr - sizeof(Datablock));
  size_t bar = finder->size + sizeof(Datablock);
  freelist_size += bar;
  node_add(finder);

// then merge the continous space by first next node then prev node
  if (finder->next != NULL){
    size_t nextbar = finder->next->size+ sizeof(Datablock);
    if ((void*)finder+bar == (void*)finder->next ){
      finder->size += nextbar;
      finder->next = finder->next->next;
      if (finder->next != NULL){
        finder->next->prev = finder;
      }
    }
  }

  if (finder->prev != NULL){
    size_t prevbar = finder->prev->size+ sizeof(Datablock);
    if ( (void*)finder->prev+prevbar == (void*)finder){
      finder->prev->size += finder->size + sizeof(Datablock);
      finder->prev->next = finder->next;
      if (finder->next != NULL){
        finder->next->prev = finder->prev;
      }
    }
  }
}

void* bf_malloc(size_t size){
  if (block_holder != NULL){
    Datablock* finder = matcher(size);
    //Datablock* best = NULL;
    if(finder != NULL){
      if (finder->size >= size){
        freelist_size -= size+sizeof(Datablock);
        if (finder->size > size+sizeof(Datablock)){
          return split(finder, size);
        }
        else{
           node_delete(finder);
           return (void *)finder + sizeof(Datablock);
        }
      }
    }
    return true_malloc(size);
  }
  else{
    return true_malloc(size);
  }
}

Datablock* matcher(size_t size){
  Datablock* temp = block_holder;
  Datablock* best = NULL;
  while(temp != NULL){
    if (temp->size == size){
      return temp;
    }
    else if (temp->size > size){
      if (best == NULL){
        best = temp;
      }
      else if (temp->size < best->size){
        best = temp;
      }
    }


    temp = temp->next;
  }
  return best;

}

void bf_free(void* ptr){
  ff_free(ptr);
}

unsigned long get_data_segment_size(){
  return block_size;
}

unsigned long get_data_segment_free_space_size(){
  return freelist_size;
}

