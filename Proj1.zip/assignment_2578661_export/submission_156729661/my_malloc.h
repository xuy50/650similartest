#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

// struct for blocks
struct BlockForInfo{
  size_t size;
  struct BlockForInfo *next;
  struct BlockForInfo *prev;
};
typedef struct BlockForInfo Block;

// first fit malloc
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// best fit malloc
void *bf_malloc(size_t size);
void bf_free(void* ptr);

// search algo
Block* ff_find(size_t size);
Block* bf_find(size_t size);

// helper functions
void* my_malloc(size_t size, int mode);
Block* allocate_memo(size_t size);
Block* split_block(Block* target_block, size_t size);
void remove_block(Block* target_block);
void my_free(void* ptr);
int add_to_list(Block* target_block);
void merge_block(Block* target_block);

// additional library functions (in bytes)
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

// global variables
unsigned long data_segment_size = 0;
unsigned long data_segment_free_space_size = 0;
Block* head_block = NULL;
Block* tail_block = NULL;

