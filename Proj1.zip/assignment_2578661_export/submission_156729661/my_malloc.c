#include "my_malloc.h"
#include "assert.h"
// First fit malloc
void *ff_malloc(size_t size){
  return my_malloc(size,1);
}

// First fit free
void ff_free(void* ptr){
  my_free(ptr);
}

// Best fit free
void *bf_malloc(size_t size){
  return my_malloc(size,2);
}

// Best fit free
void bf_free(void *ptr){
  my_free(ptr);
}

Block* ff_find(size_t size){
  if(head_block==NULL){
    return NULL;
  }
  Block* cur_block = head_block;
  while(cur_block!=NULL){
    if(cur_block->size>=size){
      return cur_block;
    }
    else{
      cur_block = cur_block->next;
    }
  }
  return NULL;
}

Block* bf_find(size_t size){
  if(head_block == NULL){
    return NULL;
  }
  Block* cur_block = head_block;
  Block* best_block = NULL;
  while(cur_block!=NULL){
    if(cur_block->size==size){
      return cur_block;
    }
    else if(cur_block->size>size){
      if(best_block==NULL||(best_block!=NULL&&best_block->size>cur_block->size)){
	best_block = cur_block;
      }
    }
    cur_block = cur_block->next;
  }
  return best_block;
}

void* my_malloc(size_t size, int mode){
  if(head_block == NULL){
    Block* new_block = allocate_memo(size);
    assert(new_block);
    return new_block+1;
  }
  // find the target block due to different strategy
  Block* target_block = NULL;
  Block* new_block = NULL;
  if(mode==1){
     target_block = ff_find(size);
  }
  else{
    target_block = bf_find(size);
  }
  
  // malloc space in target block
  if(target_block == NULL){
    new_block = allocate_memo(size);
  }
  // if remaining free space is too small to keep track of
  else if(target_block->size>=size &&target_block->size <= sizeof(Block)+size){
    new_block = target_block;
    remove_block(target_block);
    //data_segment_free_space_size -= target_block->size;
  }
  else{
    new_block = split_block(target_block,size);
    //data_segment_free_space_size -= size+sizeof(Block);
  }
  return new_block+1;
}


Block* allocate_memo(size_t size){
  size_t total_size = size+sizeof(Block);
  // use syscall sbrk()
  void* new_memo = sbrk(total_size);
  assert(new_memo!=(void*)-1);
  data_segment_size += total_size;
  Block* new_block = new_memo;
  new_block->size = size;
  new_block->next = NULL;
  new_block->prev = NULL;

  return new_block;
}

Block* split_block(Block* target_block, size_t size){
  assert(target_block);
  Block* new_block = (Block*)((char*)target_block+sizeof(Block)+size);
  new_block->size = target_block->size - size - sizeof(Block);
  new_block->prev = target_block;
  new_block->next = target_block->next;
  target_block->size = size;
  if(target_block==tail_block){
    tail_block = new_block;
  }
  else{
    target_block->next->prev = new_block;
  }
  target_block->next = new_block;
  remove_block(target_block);
  return target_block;
}

void remove_block(Block* target_block){
  if(target_block==NULL){
    return;
  }
  if(target_block==head_block&&target_block==tail_block){
    head_block = NULL;
    tail_block = NULL;
    return;
  }
  if(target_block==head_block){
    head_block = target_block->next;
    head_block->prev = NULL;
    target_block->next = NULL;
  }
  else if(target_block==tail_block){
    tail_block = target_block->prev;
    tail_block->next = NULL;
    target_block->prev = NULL;
  }
  else{
    target_block->next->prev = target_block->prev;
    target_block->prev->next = target_block->next;
    target_block->next = NULL;
    target_block->prev = NULL;
  }
}

void my_free(void* ptr){
  if(ptr==NULL){
    return;
  }
  Block* target_block = (Block*)((char*)ptr-sizeof(Block));
  // check if we need to merge two adjacent blocks, if so, merge them
  int need_merge = add_to_list(target_block);
  if(need_merge==1){
      merge_block(target_block);
  }
}

int add_to_list(Block* target_block){
  if(head_block==NULL){
    head_block = target_block;
    tail_block = target_block;
    target_block->next = NULL;
    target_block->prev = NULL;
    return 0;
  }
  Block* cur_block = head_block;
  while(cur_block!=NULL&&cur_block<target_block){
    cur_block = cur_block->next;
  }
  // insert target block
  if(cur_block==head_block){
    head_block = target_block;
    target_block->next = cur_block;
    cur_block->prev = target_block;
  }
  else if(cur_block==NULL){
    cur_block = tail_block;
    cur_block->next = target_block;
    target_block->prev = cur_block;
    tail_block = target_block;
  }
  else{
    cur_block = cur_block->prev;
    Block* temp = cur_block->next;
    target_block->next = temp;
    temp->prev = target_block;
    cur_block->next = target_block;
    target_block->prev = cur_block;
  }
  
  // if merge or not
  if(target_block==head_block){
    if((char*)target_block+sizeof(Block)+target_block->size==(char*)target_block->next){
      return 1;
    }
    else{
      return 0;
    }
  }
  else if(target_block==tail_block){
    if((char*)target_block->prev+sizeof(Block)+target_block->prev->size==(char*)target_block){
      return 1;
    }
    else{
      return 0;
    }
  }
  else{
    if((char*)target_block+sizeof(Block)+target_block->size==(char*)target_block->next||(char*)target_block->prev+sizeof(Block)+target_block->prev->size==(char*)target_block){
      return 1;
    }
    else{
      return 0;
    }
  }
  return 0;
}

void merge_block(Block* target_block){
  if(target_block->next!=NULL){
    // merge next
    if((char*)target_block+sizeof(Block)+target_block->size==(char*)target_block->next){
      target_block->size+=target_block->next->size+sizeof(Block);
      remove_block(target_block->next);
    }
  }
  if(target_block!=head_block){
    // merge front
    if((char*)target_block->prev+sizeof(Block)+target_block->prev->size==(char*)target_block){
      target_block->prev->size+=target_block->size+sizeof(Block);
      remove_block(target_block);
    }
  }
}

unsigned long get_data_segment_size(){
  return data_segment_size;
}

unsigned long get_data_segment_free_space_size(){
  Block* cur = head_block;
  while(cur!=NULL){
    data_segment_free_space_size+=cur->size+sizeof(Block);
    cur =cur->next;
  }  
  return data_segment_free_space_size;
}
