#include "my_malloc.h"
#include<stdlib.h>
#include<unistd.h>

static size_t  dataSegmentSize=0;
static size_t  dataSegmentFreeSize=0;


static block* head=NULL;//free list head

//First Fit malloc/free
void *ff_malloc(size_t size){
  if(size==0)
    return NULL;
  //use first fit strategy to search the free list
  block* p=head;
  while(p!=NULL&&p->size<size){
    p=p->next;
  }
   //if finding an approriate block, allocate block from free list
  if(p!=NULL)
   return allocateBlock(p,size);
   //else extend heap space
  else
   return extendHeap(size);
}
void ff_free(void *ptr){
  if(ptr==NULL)
    return;
  //call freeSpace() method
  freeSpace(ptr);
  //possibly merge adjacent free regions, call mergeRegion()
  mergeRegion(ptr);
}

//Best Fit malloc/free
void *bf_malloc(size_t size){
  if(size==0)
    return NULL;
  block* p=head,*best=NULL;
  while(p!=NULL){
    if(p->size==size){
      best=p;
      break;
    }
    else if(p->size>size){
      if(best==NULL)
	best=p;
      else
	best=p->size<best->size?p:best;
    }
    p=p->next;
  }
  if(best!=NULL)
   return allocateBlock(best,size);
  else
   return extendHeap(size);
}
void bf_free(void *ptr){
  if(ptr==NULL)
    return;
  freeSpace(ptr);
  mergeRegion(ptr);
}

void* allocateBlock(block* ptr,size_t size){//allocate block from free list
  if(ptr->size<=size+sizeof(block)){//allocate the whole block without splitting
    dataSegmentFreeSize-=ptr->size+sizeof(block);
    if(ptr->next!=NULL)
      ptr->next->prev=ptr->prev;
    if(ptr->prev!=NULL)
      ptr->prev->next=ptr->next;
    if(head==ptr)
      head=ptr->next;
  }
  else{ //split the block
    dataSegmentFreeSize-=size+sizeof(block);
    block* pnewBlock=(block*)((size_t)ptr+sizeof(block)+size);
    pnewBlock->size=ptr->size-size-sizeof(block);
    ptr->size=size;//don't forget!!!
    pnewBlock->prev=ptr->prev;
    pnewBlock->next=ptr->next;
    if(pnewBlock->prev!=NULL){
      pnewBlock->prev->next=pnewBlock;
    }
    if(pnewBlock->next!=NULL){
      pnewBlock->next->prev=pnewBlock;
    }
    if(head==ptr){
      head=pnewBlock;
    }
  }
  ptr->prev=NULL;
  ptr->next=NULL;
  return (void*)((size_t)ptr+sizeof(block));
}

void* extendHeap(size_t size){
  block* pnewSpace=(block*)sbrk(size+sizeof(block));
  if(pnewSpace==(void*)-1)
    return NULL;
  dataSegmentSize+=size+sizeof(block);
  pnewSpace->size=size;
  pnewSpace->prev=NULL;
  pnewSpace->next=NULL;
  return (void*)((size_t)pnewSpace+sizeof(block));
}

void freeSpace(void* ptr){//add to free list without merge
  block* pblock=(block*)((size_t)ptr-sizeof(block));
  if(head==NULL){
    head=pblock;
    pblock->prev=NULL;
    pblock->next=NULL;
  }
  else if(head>pblock){
    head->prev=pblock;
    pblock->next=head;
    pblock->prev=NULL;
    head=pblock;
  }
  else{
    block* p=head;
    while(p->next!=NULL&&p->next<pblock){
      p=p->next;
    }
    pblock->prev=p;
    pblock->next=p->next;
    p->next=pblock;
    if(pblock->next!=NULL){
      pblock->next->prev=pblock;
    }//modified
  }
  dataSegmentFreeSize+=pblock->size+sizeof(block);
}

void mergeRegion(void* ptr){
  block* pblock=(block*)((size_t)ptr-sizeof(block));
  if(pblock!=head){
    if((size_t)pblock->prev+sizeof(block)+pblock->prev->size==(size_t)pblock){//check whether to merge the block ahead
      pblock->prev->size+=pblock->size+sizeof(block);
      pblock->prev->next=pblock->next;
      if(pblock->next!=NULL)
	pblock->next->prev=pblock->prev;
      pblock=pblock->prev;
    }
  }
  if(pblock->next!=NULL){
    if((size_t)pblock+sizeof(block)+pblock->size==(size_t)pblock->next){
      pblock->size+=sizeof(block)+pblock->next->size;
      pblock->next=pblock->next->next;
      if(pblock->next!=NULL)//not pblock->next->next, because pblock->next has changed!
	pblock->next->prev=pblock;
    }
  }
}
unsigned long get_data_segment_size(){
  return dataSegmentSize;
}//in bytes

unsigned long get_data_segment_free_space_size(){
  return dataSegmentFreeSize;
}//in byte

