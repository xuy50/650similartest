//First Fit malloc/free
#include<stddef.h>
typedef struct block{
  size_t size;
  struct block* prev;
  struct block* next;
}block;

void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//auxiliary functions
void* allocateBlock(block* ptr,size_t size);//pass in already verified approriate block metadata pointer
void* extendHeap(size_t size);//return address to usable space
void freeSpace(void* ptr);
void mergeRegion(void * ptr);

unsigned long get_data_segment_size();//in bytes

unsigned long get_data_segment_free_space_size();//in bytes
