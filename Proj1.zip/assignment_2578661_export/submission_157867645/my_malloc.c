#include "my_malloc.h"
#include <unistd.h>//used for calling sbrk()

//helper function 1
//it processes an ample free block for use
int reuseCheck(Block * block, size_t size) {
    //do case analysis based on reusability
    if (sizeof(Block) + size >= block->size) {
        return 0;
    }
    else {
        return 1;
    }
}
void * processBlock(Block * block, size_t size) {
    //do case analysis based on reusability
    int reusable = reuseCheck(block, size);
    //case 1: this space is not reusable
    if (reusable == 0) {
        removeBlock(block);
        //the rest is not freeable (cannot be freed in the future)
        freeSize = freeSize - sizeof(Block) - block->size;
    }
    //case 2: this space is reusable
    else {
        //(char *)ptr transfers an address into calculable type
        Block * rest = (Block *) (sizeof(Block) + size + (char *)block);
        rest->size = block->size - sizeof(Block) - size;
        removeBlock(block);
        block->size = size;//remember to modify the information stored in block's metadata
        addBlock(rest);
        freeSize = freeSize - sizeof(Block) - size;
    }  
    return sizeof(Block) + (char *)block;
}

//helper function 2
//it removes one element from linked list
void removeBlock(Block * block) {
    //corner case 1: there is no element in linked list
    if (head == NULL) {
        return;
    }
    //corner case 2: there is only one element in linked list
    else if (head == tail) {
        //case 2.1: it is the one to remove
        if (head == block) {
            head = NULL;
            tail = NULL;
        }
        //case 2.2: it is not the one to remove
        else {
            return;
        }
    }
    //case 3: there are at least two elements in linked list
    //case 3.1: head is the one to remove
    else if (head == block) {
        head = head->next;
        head->prev = NULL;
    }
    //case 3.2: tail is the one to remove
    else if (tail == block) {
        tail = tail->prev;
        tail->next = NULL;
    }
    //case 3.3: block is not the head or the tail
    else {
        Block * temp = head;
        while (temp != NULL) {
            if (temp == block) {
                break;
            }
            temp = temp->next;
        }
        //case 3.3.1: block is inside linked list
        if (temp != NULL) {
            block->prev->next = block->next;
            block->next->prev = block->prev;
            block->prev = NULL;
            block->next = NULL;
        }
        //case 3.3.2: block does not exist inside linked list
        else {
            return;
        }
    }
}

//helper function 3
//it adds one element to linked list
void addBlock(Block * block) {
    
    //corner case 1: there is no element in linked list
    if (head == NULL) {
        head = block;
        head->prev = NULL;
        head->next = NULL;
        tail = block;
    }
    //corner case 2: block is not in the middle of linked list
    //case 2.1: add to front
    else if (block < head) {
        block->prev = NULL;
        block->next = head;
        head->prev = block;
        head = block;
    }
    //case 2.2: add to back
    else if (block > tail) {
        block->prev = tail;
        block->next = NULL;
        tail->next = block;
        tail = block;
    }
    //case 3: block is in the middle of linked list
    else {
        Block * temp = head;
        while (temp != NULL) {
            if (temp < block && temp->next > block) {
                break;
            }
            temp = temp->next;
        }
        temp->next->prev = block;
        block->next = temp->next;
        temp->next = block;
        block->prev = temp;
    }
}

//main function 1
void * ff_malloc(size_t size) {
    //corer case: size must be valid (pisitive)
    if (size <= 0) {
        return NULL;
    }
    else {
        int available = 0;
        Block * temp = head;
        //case 1: there are no free blocks
        if (head == NULL) {
            available = 0;
        }
        else {
            while (temp != NULL) {
                if (size <= temp->size) {
                    available = 1;
                    break;
                }
                temp = temp->next;
            }
        }
        //case 2: there is at least one ample free block
        if (available == 1) {
            return processBlock(temp, size);
        }
        //case 3: there is no ample free block
        else {
            entireSize = entireSize + sizeof(Block) + size;
            Block * ans = sbrk(sizeof(Block) + size);
            ans->size = size;
            //return the address of data, not the entire block
            return sizeof(Block) + (char *)ans;
        }
    }
}

//main function 2
void ff_free(void * ptr) {
    Block * block = (Block *)((char *)ptr - sizeof(Block));
    freeSize = freeSize + sizeof(Block) + block->size;
    addBlock(block);
    //note that if we deal with right before left, the efficiency is remarkably higher
    int rightFree = 0;
    int leftFree = 0;
    if (block->next != NULL) {
        if ((char *)block->next == sizeof(Block) + block->size + (char *)block) {
            rightFree = 1;
        }
    }
    if (block->prev != NULL) {
        if ((char *)block == sizeof(Block) + block->prev->size + (char *)block->prev) {
            leftFree = 1;
        }
    }
    //corner case 1: the right block is free
    if (rightFree == 1) {
        block->size = block->size + sizeof(Block) + block->next->size;
        removeBlock(block->next);
    }
    //corner case 2: the left block is free
    if (leftFree == 1) {
        block->prev->size = block->prev->size + sizeof(Block) + block->size;
        removeBlock(block);
    }
}

//main funtion 3
void * bf_malloc(size_t size) {
    //corer case: size must be valid (positive)
    if (size <= 0) {
        return NULL;
    }
    else {
        Block * temp = head;
        Block * minBlock = NULL;
        int available = 0;
        //case 1: there are no free blocks
        if (head == NULL) {
            available = 0;
        }
        else {
            while (temp != NULL) {
                if (size <= temp->size) {
                    available = 1;
                    if (size == temp->size) {
                        minBlock = temp;
                        break;
                    }
                    else if (minBlock == NULL) {
                        minBlock = temp;//initialize minBlock
                    }
                    else if (minBlock->size > temp->size) {
                        minBlock = temp;
                    }
                }
                temp = temp->next;
            }
        }
        //case 2: there is at least one ample free block
        if (available == 1) {
            return processBlock(minBlock, size);
        }
        //case 3: there is no ample free block
        else {
            entireSize = entireSize + sizeof(Block) + size;
            Block * ans = sbrk(sizeof(Block) + size);
            ans->size = size;
            //return the address of data, not the entire block
            return sizeof(Block) + (char *)ans;
        }
    }
}

//main function 4
void bf_free(void * ptr) {
    ff_free(ptr);
}

//main function 5
size_t get_data_segment_size() {
    return entireSize;
}

//main function 6
size_t get_data_segment_free_space_size() {
    return freeSize;
}