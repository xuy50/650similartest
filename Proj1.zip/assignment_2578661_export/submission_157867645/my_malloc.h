#include <stdio.h>
#include <stdlib.h>

//I used (doubly) linked list to keep track of all the empty space
//each element in this linked list is a struct named Block
struct Block_t {
  size_t size;
  struct Block_t * next;
  struct Block_t * prev;
};
typedef struct Block_t Block;

//global variables
//the head of linked list
Block * head = NULL;
//the tail of linked list
Block * tail = NULL;
//the data segment size
size_t entireSize = 0;
//the data segment free space size
size_t freeSize = 0;

//helper functions
void * processBlock(Block * block, size_t size);
void  removeBlock(Block * block);
void  addBlock(Block * block);

//main funtions
void * ff_malloc(size_t size);
void ff_free(void * ptr);
void * bf_malloc(size_t size);
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();