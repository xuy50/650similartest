#include "my_malloc.h"

#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <unistd.h>

void add_this_node(node * nd) {
  if (head == NULL) {
    head = nd;
    head->prev = NULL;
    head->next = NULL;
  }
  else {
    node * curr = head;
    node * prev_curr = NULL;
    while (curr != NULL && curr < nd) {
      prev_curr = curr;
      curr = curr->next;
    }

    if (curr == head) {
      nd->next = curr;
      curr->prev = nd;
      nd->prev = NULL;
      head = nd;
    }
    else {
      //curr is NULL
      nd->prev = prev_curr;
      prev_curr->next = nd;
      nd->next = curr;
      if (curr != NULL) {
        curr->prev = nd;
      }
    }
  }
}

void coalesce_this_node(node * nd) {
  //merge the current node with its next if they are adjacent
  if (nd->next != NULL) {
    if (nd->address + nd->size == (char *)nd->next) {
      node * next_node = nd->next;
      nd->size += next_node->size + sizeof(node);
      if (next_node->next != NULL) {
        next_node->next->prev = nd;
      }
      nd->next = next_node->next;
      next_node->prev = NULL;
      next_node->next = NULL;
    }
  }
  //merge the current node with its prev if they are adjacent
  if (nd->prev != NULL) {
    if (nd->prev->address + nd->prev->size == (char *)nd) {
      node * prev_node = nd->prev;
      prev_node->size += nd->size + sizeof(node);
      if (nd->next != NULL) {
        nd->next->prev = prev_node;
      }
      prev_node->next = nd->next;
      nd->prev = NULL;
      nd->next = NULL;
    }
  }
}

void delete_this_node(node * nd) {
  if (nd == head) {
    head = nd->next;
    if (head != NULL) {
      head->prev = NULL;
    }
  }
  else {
    node * p = nd->prev;
    node * n = nd->next;
    p->next = n;
    if (n != NULL) {
      n->prev = p;
    }
  }
  /*
  nd->size = 0;
  nd->prev = NULL;
  nd->next = NULL;*/
}

void split_this_node(node * curr, size_t size) {
  assert(curr->size >= size);
  node * nd = (node *)(curr->address + size);
  nd->address = (char *)nd + sizeof(node);
  nd->size = curr->size - size - sizeof(node);

  nd->prev = curr->prev;
  nd->next = curr->next;
  if (curr == head) {
    head = nd;
  }
  else {
    curr->prev->next = nd;
  }
  if (curr->next != NULL) {
    curr->next->prev = nd;
  }

  curr->size = size;
  curr->prev = NULL;
  curr->next = NULL;
}

node * bf_node(size_t size) {
  node * res = NULL;
  node * curr = head;
  size_t min = INT_MAX;
  while (curr != NULL) {
    if (curr->size >= size && curr->size < min) {
      min = curr->size;
      res = curr;
      if (res->size == size) {
        break;
      }
    }
    curr = curr->next;
  }
  return res;
}

void * ff_malloc(size_t size) {
  node * curr = head;
  while (curr != NULL && curr->size < size) {
    assert(curr->next != curr);
    curr = curr->next;
  }
  if (head == NULL || curr == NULL) {
    void * addr = sbrk(size + sizeof(node));
    if (addr == (void *)-1) {
      return NULL;
    }
    entire_memory += size + sizeof(node);
    node * nd = addr;
    nd->prev = NULL;
    nd->next = NULL;
    nd->size = size;
    nd->address = addr + sizeof(node);

    occupied_memory += size + sizeof(node);
    //assert(occupied_memory <= entire_memory);
    return (char *)addr + sizeof(node);
  }
  else {
    if (curr->size > size + sizeof(node)) {
      split_this_node(curr, size);
    }
    else {
      delete_this_node(curr);
    }
    occupied_memory += size + sizeof(node);
    //   assert(occupied_memory <= entire_memory);
    return (char *)curr->address;
  }
}

void * bf_malloc(size_t size) {
  node * curr = head;
  while (curr != NULL && curr->size < size) {
    curr = curr->next;
  }
  if (head == NULL || curr == NULL) {
    void * addr = sbrk(size + sizeof(node));
    if (addr == (void *)-1) {
      return NULL;
    }
    entire_memory += size + sizeof(node);
    node * nd = addr;
    nd->prev = NULL;
    nd->next = NULL;
    nd->size = size;
    nd->address = addr + sizeof(node);
    occupied_memory += size + sizeof(node);
    //    assert(occupied_memory <= entire_memory);
    return (char *)addr + sizeof(node);
  }
  else {
    node * curr = bf_node(size);
    if (curr->size > size + sizeof(node)) {
      split_this_node(curr, size);
    }
    else {
      delete_this_node(curr);
    }
    occupied_memory += size + sizeof(node);
    //    assert(occupied_memory <= entire_memory);
    return (char *)curr->address;
  }
}

void ff_free(void * ptr) {
  node * nd = (node *)((char *)ptr - sizeof(node));
  occupied_memory -= nd->size + sizeof(nd);
  add_this_node(nd);
  coalesce_this_node(nd);
}

void bf_free(void * ptr) {
  node * nd = (node *)((char *)ptr - sizeof(node));
  occupied_memory -= nd->size + sizeof(nd);
  add_this_node(nd);
  coalesce_this_node(nd);
}

unsigned long get_data_segment_size() {
  return entire_memory;
}

unsigned long get_data_segment_free_space_size() {
  printf("entire_memory = %lul\n", entire_memory);
  printf("occupied_memory = %lul\n", occupied_memory);
  return entire_memory - occupied_memory;
}
