#include <stdio.h>

//metadata
struct _node {
  void * address;
  size_t size;
  struct _node * prev;
  struct _node * next;
};
typedef struct _node node;

//establish a free list
node * head = NULL;

//memory sizes
unsigned long entire_memory = 0;
unsigned long occupied_memory = 0;

//additional functions
void add_this_node(node * nd);
void delete_this_node(node * curr);
void split_this_node(node * curr, size_t size);
void coalesce_this_node(node * nd);
node * bf_node(size_t size);

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

//additional library functions
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
