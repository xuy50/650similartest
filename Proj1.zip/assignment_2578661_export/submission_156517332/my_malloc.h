#ifndef MY_MALLOC_H
#define MY_MALLOC_H
#include <stdio.h>
#include <stdlib.h>
//#define HEADER_T_SIZE sizeof(header_t)  // bytes

typedef enum _malloc_t { FIRST_FIT, BEST_FIT } malloc_t;

typedef struct _header_t {
  // a meta header data structure linking free memory blocks
  size_t size;  // blk size
  struct _header_t * prev;
  struct _header_t * next;
} header_t;

#define HEADER_T_SIZE sizeof(header_t)  // byte

// data structure representing a list of free memory regions
typedef struct _heap_info_t {
  header_t * head;
  header_t * tail;
  // size_t length;
  unsigned long heapTotal;  // freeMemorySumUp;
  unsigned long freeTotal;
} heap_info_t;

/* Deal with header and pointer casting. */
void initUsableMem(header_t * ph, size_t size, header_t * prev, header_t * next);
void * getUsableMem(header_t * ph);
void * getUsableMem(header_t * ph);
header_t * getHeaderAddr(void * addr);

/* Reorganize blocks. */
void removeBlks(header_t * rm);
void mergeMemToFirst(header_t * first, header_t * second);
void mergeFreeMem(header_t * mid);
void insertBlksToPosition(header_t * prev, header_t * toInsert);
void reorganizeBlks(header_t * ptr, size_t size);
// insert a free memory block when having no idea of the insert position
void insertBlks(header_t * ph);

/* Allocate new memory blocks with sbrk(). */
header_t * allocBlks(size_t t);

/* Deal with find corresponding allocating methods. */
header_t * findFirstFitBlk(size_t size);

void * my_malloc(size_t size, malloc_t type);

/* Prototypes for custom malloc and free methods. */
void * ff_malloc(size_t size);
void ff_free(void * ptr);
void * bf_malloc(size_t size);
void bf_free(void * ptr);
unsigned long get_data_segment_size();             //in bytes
unsigned long get_data_segment_free_space_size();  //in byte
#endif
