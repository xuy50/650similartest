#include "my_malloc.h"

#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>

// Initialize LinkedList for free memory regions
static heap_info_t lst = {.head = NULL, .tail = NULL, .heapTotal = 0, .freeTotal = 0};

int main() {
  // void * a = ff_malloc(10);
  // ff_free(a);  // invalid read

  int size = 8;
  char * pc = (char *)ff_malloc(size * sizeof(char));
  pc[0] = 'a';
  pc[1] = 'b';

  for (size_t i = 0; i < size; i++) {
    pc[i] = 'a' + i;  // invalid write
  }

  int size2 = 4;
  int * pi = (int *)ff_malloc(size2 * sizeof(int));
  for (int i = 0; i < size2; i++) {
    pi[i] = i;
  }
  return EXIT_SUCCESS;
}

void initUsableMem(header_t * ph, size_t size, header_t * prev, header_t * next) {
  assert(size >= 0);
  ph->size = size;
  ph->prev = prev;
  ph->next = next;
}

void * getUsableMem(header_t * ph) {
  assert(ph->size >= 0);
  return (char *)ph + HEADER_T_SIZE;
}

header_t * getHeaderAddr(void * addr) {
  // TODO: Add more assertions?
  return (header_t *)((char *)addr - HEADER_T_SIZE);
}

void removeBlks(header_t * rm) {
  if (rm == NULL)
    return;
  // assert(rm != NULL);

  if (rm->prev == NULL) {
    if (rm->next == NULL) {
      lst.head = NULL;
      lst.tail = NULL;
    }
    else {
      rm->next->prev = NULL;
      lst.head = rm->next;
      // rm->next = NULL;
    }
  }
  else {
    if (rm->next == NULL) {
      rm->prev->next = NULL;
      lst.tail = rm->prev;
      // rm->prev = NULL;
    }
    else {
      rm->prev->next = rm->next;
      rm->next->prev = rm->prev;
      // rm->prev = NULL;
      // rm->next = NULL;
    }
  }

  lst.freeTotal -= (HEADER_T_SIZE + rm->size);
}
/*
void mergeMemToFirst(header_t *first, header_t *second)
{
  assert(first != NULL);
  assert(second != NULL);

  assert(first->size >= 0);
  assert(second->size >= 0);

  assert(first->next == second);

  removeBlks(second);

  first->size += HEADER_T_SIZE + second->size;

  second->prev = NULL;
  second->next = NULL;
  second->size = 0;
  second = NULL;
}
*/

void mergeFreeMem(header_t * mid)  // Fixme
{
  assert(mid != NULL);
  // assert(mid->size >= 0);

  int left = 0;
  int right = 0;

  if (mid->prev != NULL &&
      ((header_t *)(char *)mid->prev + HEADER_T_SIZE + mid->prev->size == mid)) {
    left = 1;
  }

  if (mid->next != NULL &&
      ((header_t *)(char *)mid + HEADER_T_SIZE + mid->size == mid->next)) {
    right = 1;
  }

  if (left && right) {
    mid->prev->size += 2 * HEADER_T_SIZE + mid->size + mid->next->size;
    // assert(mid != NULL);
    removeBlks(mid);
    // assert(mid->next != NULL);
    removeBlks(mid->next);
  }
  else if (left) {
    mid->prev->size += HEADER_T_SIZE + mid->size;
    assert(mid != NULL);
    removeBlks(mid);
  }
  else if (right) {
    mid->size += HEADER_T_SIZE + mid->next->size;
    assert(mid->next != NULL);
    removeBlks(mid->next);
  }
}

void insertBlksToPosition(header_t * prev, header_t * toInsert) {
  if (toInsert == NULL)
    return;
  // assert(toInsert != NULL);
  // assert(toInsert->size >= 0);

  size_t localVar = HEADER_T_SIZE;  // for debug
  // assert(toInsert->size >= 0);      // Fixme: check beforehand (fixed: should not be > HEADER_T_SIZE)

  /* Insert free blks */
  if (prev == NULL) {
    toInsert->next = lst.head;
    toInsert->prev = NULL;
    if (lst.head != NULL) {
      (lst.head)->prev = toInsert;
    }
    lst.head = toInsert;
    if (lst.tail == NULL) {
      lst.tail = toInsert;
    }
  }
  else if (prev != NULL && prev->next == NULL)  // segmentation fault
  {
    // append to tail
    toInsert->prev = prev;
    toInsert->next = NULL;
    prev->next = toInsert;
    lst.tail = toInsert;
  }
  else {
    toInsert->prev = prev;
    toInsert->next = prev->next;
    prev->next->prev = toInsert;
    prev->next = toInsert;  // must be at the end
  }

  /* Merge free memory blks*/
  mergeFreeMem(toInsert);

  /* Update total free mem size */
  lst.freeTotal += HEADER_T_SIZE + toInsert->size;
}

void insertBlks(header_t * ph) {
  header_t * ptr = lst.head;
  // assert(ph->size >= 0);

  while (ptr != NULL) {  // TODO check the condition correctness
    // assert(ph != ptr);
    // assert(ph->size >= 0);
    // assert(ptr->size >= 0);
    if (ph < ptr) {
      insertBlksToPosition(ptr->prev, ph);
      return;
    }
    else if (ph == ptr)  // Fixme: unnecessary
    {
      return;
    }
    else {
      if (ptr->next == NULL) {
        insertBlksToPosition(ptr, ph);
        return;
      }
      ptr = ptr->next;
    }
  }

  // run otherwise
  // lst.head = ph;
  // lst.tail = ph;
  // ph->prev = NULL;
  // ph->next = NULL;
  insertBlksToPosition(NULL, ph);
}

/* Remove a blk from lst, split and insert new blks, merge possible free blks */
void reorganizeBlks(header_t * ptr, size_t size) {
  // assert(size >= 0);
  // assert(ptr != NULL);
  // assert(lst.head != NULL);
  // assert(lst.tail != NULL);

  if (ptr->size <= size + HEADER_T_SIZE) {
    // not splitable
    return;
  }

  header_t * prev = ptr->prev;
  header_t * next = ptr->next;

  header_t * splitBlks = (header_t *)((char *)ptr + HEADER_T_SIZE + size);

  assert(splitBlks != NULL);
  initUsableMem(splitBlks, ptr->size - size - HEADER_T_SIZE, prev, next);

  // remove the free blk from the list
  ptr->size = size;
  removeBlks(ptr);

  // assert(splitBlks->size >= 0);
  //  split another free blk out, add it to the lst, and merge possible free blks
  insertBlksToPosition(prev, splitBlks);
}

header_t * allocBlks(size_t size) {
  // call system memory management tool "sbrk" here
  // Usage1: get heap starting addr; (size_t)sbrk(0).
  // Usage2: allocate new memory blocks and return the starting addr to the block; void * sbrk(increSize);

  // may custom memory incremental size by requesting memory larger than needed. => change to 2 * size + header_t_size
  // assert(size >= 0);
  size_t increSize = size + HEADER_T_SIZE;  // # of Bytes
  // assert(increSize > HEADER_T_SIZE);
  header_t * ph = sbrk(increSize);  // reside in <unistd.h> header file

  // exception detection
  if (ph == (void *)-1) {
    return NULL;
  }

  // Init the new header
  ph->prev = NULL;
  ph->next = NULL;
  ph->size = size;

  // /* Insert the free blk into list. */
  if (lst.head == NULL) {
    // assert(lst.tail == NULL);
    // assert(ph->size >= 0);
    insertBlksToPosition(NULL, ph);
  }
  else {
    // assert(ph->size >= 0);
    insertBlks(ph);
  }

  /* Update heap size info. */
  lst.heapTotal += increSize;

  // assert(ph->size >= 0);
  return ph;
}

/* Preconditions:
 * 1. ptr->size > 0 (or have been merge or deleted)
 * 2.
 */
header_t * findFirstFitBlk(size_t size) {
  // assert(size >= 0);

  if (lst.head == NULL) {
    // assert(lst.head == lst.tail);
    return lst.head;
  }

  header_t * ptr = lst.head;
  while (ptr != NULL) {
    if (ptr->size < size || (ptr->size > size && ptr->size <= size + HEADER_T_SIZE)) {
      /*not usable / splitable: no enough mem for alloc || if alloc, cannot split out another usable mem*/
      // assert(ptr->size >= 0);

      ptr = ptr->next;
      continue;
    }
    else if (ptr->size == size) {
      // assert(ptr->size >= 0);
      /* Usable blks: the exact expecting size */
      removeBlks(ptr);
      ptr->prev = NULL;
      ptr->next = NULL;
      return ptr;
    }
    else {
      /* usable && splitable blks*/
      // remove the blk, split the blk (add free blk & merge free blks), and ret the blk
      // assert(ptr->size >= 0);
      // assert(size >= 0);
      reorganizeBlks(ptr, size);  // including add free and merge
      return ptr;
    }
  }
  return NULL;
}

/*
 *
 */
void * my_malloc(size_t size, malloc_t type) {
  // assert(size >= 0);

  header_t * mem = NULL;

  switch (type) {
    case FIRST_FIT:
      mem = findFirstFitBlk(size);
      break;
    case BEST_FIT:
      // TODO: do best fit search
      // mem = findBestFit(size);
      break;
  }

  if (mem == NULL) {
    mem = allocBlks(size);
  }

  if (mem == NULL)  // Fixme? throw exception?
    exit(EXIT_FAILURE);
  // assert(mem != NULL); // sbrk exception may occur

  // assert(mem->size >= 0);

  return getUsableMem(mem);  // user-requesting usable mem blks
}

/*
 * First Fit malloc
 */
void * ff_malloc(size_t size) {
  // assert(size >= 0);
  if (size < 0)  // fixme
  {
    return NULL;
  }

  return my_malloc(size, FIRST_FIT);
}

void ff_free(void * ptr) {
  if (ptr == NULL)
    return;

  header_t * ph = getHeaderAddr(ptr);
  // assert(ph != NULL);
  // printf("%d", (int)ph->size);
  // assert(ph->size >= 0);
  insertBlks(ph);

  mergeFreeMem(ph);
}

void * bf_malloc(size_t size) {
  return NULL;
}
void bf_free(void * ptr) {
}

unsigned long get_data_segment_size() {
  // in bytes
  return lst.heapTotal;
}
unsigned long get_data_segment_free_space_size() {
  // in byte
  return lst.freeTotal;
}
