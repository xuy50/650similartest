#include "my_malloc.h"
#include <stdio.h>
#include <unistd.h>

// Global macro, 1 for verbose enable, 0 for disable.
#define VERBOSE 0

Block * freeHead = NULL;
Block * freeTail = NULL;
unsigned long ds_size = 0;
unsigned long ds_free_size = 0;

//@Function:    Allocates size bytes of uninitialized storage using "fist find" policy
//@Para:        size:   request size
//@Return:      If success, return the address, else return NULL
void * ff_malloc(size_t size){
    //if(VERBOSE) printList();
    //if(VERBOSE) printf("FF: malloc size: %lu \n",size);
    Block * curr = freeHead;
    while(curr!=NULL && curr->size < size){
        curr=curr->nextFree;
    }
    return myMalloc(curr, size);
}

//@Function:    Allocates size bytes of uninitialized storage using "best find" policy
//@Para:        size:   request size
//@Return:      If success, return the address, else return NULL
void * bf_malloc(size_t size){
    if (VERBOSE) printList();
    Block * curr = freeHead;
    Block * ans = NULL;
    // use overflow to initialize the maximum value of size_t
    size_t min_size = (size_t) -1;
    //seach for smallest eligible block
    while(curr){
        if(curr->size >= size && curr->size < min_size){
            ans = curr;
            min_size = curr->size;
            //if curr->size == size, this is the mimimum, break the loop
            if(curr->size == size){
                break;
            }
        }
        curr = curr->nextFree;
    }
    return myMalloc(ans, size);
}

//@Function:    allocate the size byte at blk address
//@Para:        blk:address   request size
//@Return:      If success, return the address, else return NULL
void * myMalloc(Block * blk, size_t size){
    // no eligible block, extend heap
    if(blk==NULL){
        return extendHeap(size);
    // can be splitted
    }else if(blk->size > size + sizeof(Block)){
        split(blk, size);
    // cannot be splitted, fill 
    }else{
        blk->size = size;
        removeFree(blk);
    }
    return (void *) blk + sizeof(Block);
}

//@Function:    Extend the heap when the space is insufficient
//@Para:        size: increment size
//@Return:      If success, return the address, else return NULL
void * extendHeap(size_t size){
    //if(VERBOSE) printf("extend heap \n");
    Block * newBlock = sbrk(size + sizeof(Block));

    // out of memory
    if(newBlock==(void *)-1){
        return NULL;
    }

    ds_size += size + sizeof(Block);
    newBlock->size = size;
    //if(VERBOSE) printf("extend heap at %p, size %lu \n", (char *)newBlock + sizeof(*newBlock), size);
    return (void *)newBlock + sizeof(Block);
}

//@Function:    Split start the target position for size.
//@Para:        target: position of the target, size: modified target size
//@Return:      void
void split(Block * target, size_t size){
    //if(VERBOSE) printf("split at %p, size %lu asked %lu \n",target, target->size, size);
    //remove old
    removeFree(target);
    //create new Block
    Block * newBlock = (void *)target + size + sizeof(Block);
    newBlock->size = target->size - size - sizeof(Block);
    addFree(newBlock);
    target->size = size;
    //if(VERBOSE) printf("splitted, remain %lu \n",newBlock->size);
}

//@Function:    Insert free block to the free list and add the free size
//@Para:        blk: pointer of the block want to add
//@Return:      void
void addFree(Block * blk){
    ds_free_size += blk->size + sizeof(Block);
    // add front
    if(freeHead==NULL || blk < freeHead){
        blk->nextFree = freeHead;
        blk->prevFree = NULL;
        freeHead = blk;
        if(blk->nextFree){
            blk->nextFree->prevFree = blk;
        }else{
            // first free block
            freeTail = blk;
        }
    }else{
    // add to middle / tail
        Block * curr = freeHead;
        while(curr->nextFree && curr->nextFree <= blk){
            curr = curr->nextFree;
        }
        blk->nextFree = curr->nextFree;
        blk->prevFree = curr;
        curr->nextFree = blk;
        if(blk->nextFree){
            // middle
            blk->nextFree->prevFree = blk;
        }else{
            // tail
            freeTail = blk;
        }
    }
}

//@Function:    Remove Block from the free list and reduce the free size
//@Para:        blk: pointer of the block want to remove    
//@Return:      void 
void removeFree(Block * blk){
    ds_free_size -= blk->size + sizeof(Block);
    //if list contains only one blk
    if(freeHead==blk && freeTail==blk){
        freeHead = NULL;
        freeTail = NULL;
    //remove front
    }else if(freeHead == blk){
        freeHead = freeHead->nextFree;
        freeHead->prevFree = NULL;
    //remove tail
    }else if(freeTail == blk){
        freeTail = freeTail->prevFree;
        freeTail->nextFree = NULL;
    //remove middle
    }else{
        blk->nextFree->prevFree = blk->prevFree;
        blk->prevFree->nextFree = blk->nextFree;
    }
    blk->nextFree  = NULL;
    blk->prevFree = NULL;
}

void bf_free(void *ptr){
    myFree(ptr);
}

void ff_free(void *ptr){
    myFree(ptr);
}

//@Function:    Deallocates the space previously allocated by malloc()
//@Para:        ptr: address of the allocted space
//@Return:      void
void myFree(void *ptr){
    if(!ptr) return;
    //get the Block pointer using ptr address
    Block * curr = ptr - sizeof(Block);
    //if(VERBOSE) printf("free %p %lu \n", curr, curr->size);

    //add to free list
    addFree(curr);

    //check whether it can be merged with the next block
    if(curr->nextFree && (void *) curr->nextFree == (void *)curr + curr->size + sizeof(Block)){
        curr = merge(curr);
    }

    //check whether it can be merged with the prev block
    if( curr->prevFree && (void *) curr == (void *)curr->prevFree + curr->prevFree->size + sizeof(Block)){
        curr = merge(curr->prevFree);
    }

    //if(VERBOSE) printList();
}

//@Function:    merge the block and next block, remove the next block from free list
//@Para:        ptr: the position of the pointer
//@Return:      merged block pointer
Block * merge(Block *ptr){
    //if(VERBOSE) printf("merge two at %p, %p, size %ld, %ld \n",ptr,ptr->nextFree,ptr->size,ptr->nextFree->size);
    ptr->size += sizeof(Block) + ptr->nextFree->size;
    ds_free_size += ptr->nextFree->size + sizeof(Block);
    removeFree(ptr->nextFree);
    return ptr;
}

//@Function:    get the data segment size
//@Para:        void
//@Return:      data segment size
unsigned long get_data_segment_size(){
    return ds_size;
}

//@Function:    get the data segment free space size
//@Para:        void
//@Return:      data data segment free space size
unsigned long get_data_segment_free_space_size(){
    return ds_free_size;
}

//@Function:    For debug purpose, print the free list in order
//@Para:        void
//@Return:      void
void printList(){
    Block * curr = freeHead;
    printf("-------------Free List------------\n");
    while(curr){
        printf("address: %p, size: %lu\n",curr,curr->size);
        curr = curr->nextFree;
    }
    printf("------------------------------------\n\n");
}