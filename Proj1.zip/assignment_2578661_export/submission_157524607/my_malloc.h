#include<stdio.h>
typedef struct block{
    size_t size;
    struct block * nextFree;
    struct block * prevFree;
} Block;

void * ff_malloc(size_t size);
void ff_free(void *ptr);
void * bf_malloc(size_t size);
void bf_free(void *ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void * myMalloc(Block * blk, size_t size);
void * extendHeap(size_t size);
void split(Block *ptr, size_t size);
void addFree(Block * blk);
void removeFree(Block *blk);
void myFree(void *ptr);
Block * merge(Block *ptr);
void printList();