#include "my_malloc.h"

#include <assert.h>
#include <stdlib.h>
#include <unistd.h>

void *ff_malloc(size_t size) {
  if (g_block_list_head) {
    header_t *p = g_block_list_head;

    while (p) {
      if (p->size >= size) {
        return insert_block(p, size);
      }
      p = p->next;
    }
  }
  return allocate_new_block(size);
}

void ff_free(void *f) { _free(f); }

void *bf_malloc(size_t size) {
  if (g_block_list_head) {
    header_t *p = g_block_list_head;
    header_t *target = NULL;

    while (p) {
      if (p->size == size) {
        return insert_block(p, size);
      }
      else if (p->size > size && (!target || p->size < target->size)) {
        target = p;
      }
      p = p->next;
    }

    if (target) {
      return insert_block(target, size);
    }
  }
  return allocate_new_block(size);
}

void bf_free(void *f) { _free(f); }

/*---------------------------*/
/*  Performance Functions    */
/*---------------------------*/
unsigned long get_data_segment_size() { return g_data_segment_size; }
unsigned long get_data_segment_free_space_size() { return g_free_segment_size; }

/*---------------------------*/
/*    Helper Functions       */
/*---------------------------*/
void print_error(const char *msg) {
  perror(msg);
  exit(EXIT_FAILURE);
}

void initialize_header(header_t *header, size_t size) {
  header->size = size;
  header->prev = header->next = NULL;
}

void *allocate_new_block(size_t size) {
  header_t *head = sbrk(BLOCK_SIZE(size));
  g_data_segment_size += BLOCK_SIZE(size);

  if ((void *)head == (void *)-1) {
    print_error("sbrk failed.\n");
  }

  initialize_header(head, size);

  return (char *)head + HEADER_SIZE;
}

void *insert_block(header_t *p, size_t size) {
  header_t *new_block_head = (header_t *)((char *)p + p->size - size);
  g_free_segment_size -= BLOCK_SIZE(size);

  if (p->size < BLOCK_SIZE(size)) {
    remove_free_block(p);
    return (char *)p + HEADER_SIZE;
  }
  initialize_header(new_block_head, size);
  p->size -= BLOCK_SIZE(size);

  return (char *)new_block_head + HEADER_SIZE;
}

void insert_free_block(header_t *p, header_t *new_block_head) {
  // insert to front
  if (new_block_head < p) {
    add_front(new_block_head, p);
  }
  // insert to tail
  else if (!p->next) {
    add_back(p, new_block_head);
  }
  // insert in between p and p->next
  else {
    // coalesce p, new_block_head, and p->next to p
    if (check_continuity(p, new_block_head) &&
        check_continuity(new_block_head, p->next)) {
      p->size += BLOCK_SIZE(new_block_head->size) + BLOCK_SIZE(p->next->size);
      p->next = p->next->next;
      if (p->next) {
        p->next->prev = p;
      }
      else {
        g_block_list_tail = p;
      }
    }
    // simply insert in between p and p->next, no coalesce
    else if (!check_continuity(p, new_block_head) &&
             !check_continuity(new_block_head, p->next)) {
      new_block_head->next = p->next;
      p->next->prev = new_block_head;
      new_block_head->prev = p;
      p->next = new_block_head;
    }
    else if (!check_continuity(p, new_block_head)) {
      add_front(new_block_head, p->next);
    }
    else {
      add_back(p, new_block_head);
    }
  }
}

// add h1 to the front of h2, coalesce if possible
void add_front(header_t *h1, header_t *h2) {
  h1->next = h2;
  h1->prev = h2->prev;
  if (h1->prev) h1->prev->next = h1;
  if (check_continuity(h1, h2)) {
    h1->next = h2->next;
    h1->size += BLOCK_SIZE(h2->size);
  }
  if (h1->next) {
    h1->next->prev = h1;
  }
  else {
    g_block_list_tail = h1;
  }
  if (h2 == g_block_list_head) {
    g_block_list_head = h1;
  }
}

// add h2 to the next of h1, coalesce if possible
void add_back(header_t *h1, header_t *h2) {
  if (check_continuity(h1, h2)) {
    h1->size += BLOCK_SIZE(h2->size);
  }
  else {
    h2->prev = h1;
    h2->next = h1->next;
    h1->next = h2;
    if (h2->next) {
      h2->next->prev = h2;
    }
    else {
      g_block_list_tail = h2;
    }
  }
}

int check_continuity(header_t *h1, header_t *h2) {
  return ((char *)h1 + BLOCK_SIZE(h1->size) == (char *)h2);
}

void remove_free_block(header_t *p) {
  if (!p->prev && !p->next) {
    g_block_list_head = g_block_list_tail = NULL;
  }
  else if (!p->prev) {
    p->next->prev = NULL;
    g_block_list_head = p->next;
  }
  else if (!p->next) {
    p->prev->next = NULL;
    g_block_list_tail = p->prev;
  }
  else {
    p->prev->next = p->next;
    p->next->prev = p->prev;
  }
}

void _free(header_t *f) {
  header_t *new_block_head = (header_t *)((char *)f - HEADER_SIZE);
  g_free_segment_size += BLOCK_SIZE(new_block_head->size);

  // free list is empty
  if (!g_block_list_head) {
    g_block_list_head = g_block_list_tail = new_block_head;
    return;
  }

  header_t *p = g_block_list_head;

  // check whether f is valid and find the place to insert the free block
  while (p) {
    if (p->next && new_block_head >= p->next) {
      p = p->next;
      continue;
    }

    header_t *end_of_block =
        (header_t *)((char *)new_block_head + BLOCK_SIZE(new_block_head->size));
    if ((!p->next && end_of_block > (header_t *)PROGRAM_BREAK) ||
        (p->next && end_of_block > p->next)) {
      print_error("Returned pointer is invalid!\n");
    }
    else {
      insert_free_block(p, new_block_head);
      return;
    }
  }

  print_error("Returned pointer is invalid!\n");
}

void print_free_list() {
  header_t *p = g_block_list_head;
  while (p) {
    printf("%p: size=%ld, prev=%p, next=%p\n", (void *)p, p->size, (void *)p->prev,
           (void *)p->next);
    p = p->next;
  }
}
