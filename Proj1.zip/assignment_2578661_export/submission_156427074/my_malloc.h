#ifndef MY_MALLOC_HEADER
#define MY_MALLOC_HEADER

#include <stdio.h>

#define PROGRAM_BREAK sbrk(0)
#define HEADER_SIZE sizeof(header_t)
#define BLOCK_SIZE(size) size + HEADER_SIZE

typedef struct header {
  size_t size;
  struct header *prev;
  struct header *next;
} header_t;

// Global Variables
header_t *g_block_list_head = NULL;
header_t *g_block_list_tail = NULL;
unsigned long g_data_segment_size = 0;
unsigned long g_free_segment_size = 0;

// First-fit malloc and free
void *ff_malloc(size_t size);
void ff_free(void *f);

// Best-fit malloc and free
void *bf_malloc(size_t size);
void bf_free(void *f);

// functions needed for measuring performance
unsigned long get_data_segment_size();             // in bytes
unsigned long get_data_segment_free_space_size();  // in bytes

/* Helper Functions */
void print_error(const char *msg);
void initialize_header(header_t *header, size_t size);
void *allocate_new_block(size_t size);
void *insert_block(header_t *p, size_t size);
void insert_free_block(header_t *p, header_t *new_block_head);
void remove_free_block(header_t *p);
void _free(header_t *f);
void print_free_list();
int check_continuity(header_t *h1, header_t *h2);
void add_front(header_t *h1, header_t *h2);
void add_back(header_t *h1, header_t *h2);
#endif
