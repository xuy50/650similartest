#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include "my_malloc.h"

Blk *free_head = NULL;
Blk *start = NULL;
Blk *free_tail = NULL;

unsigned long get_data_segment_size() {  return (unsigned long)((char *)sbrk(0) - (char *)start); }

unsigned long get_data_segment_free_space_size() {
  Blk *current = free_head;
  unsigned long free_size = 0;
  while (current != NULL) {
    free_size += current->size + BLK_SIZE;
    current = current->next;
  }
  return free_size;
}

void *ff_malloc(size_t size) {
  if (start== NULL) {
    start=(Blk *)sbrk(0);
  }
  Blk *current = free_head;
  while (current!= NULL && current->size< size) {
        current=current->next;
  }
  if (current != NULL){
    split(size,current);
  }
  else{
    Blk * nb = sbrk(BLK_SIZE + size);
    nb->next = NULL;
    nb->prev = NULL;
    nb->size = size;
    return (void *)((char *) nb + BLK_SIZE);
  }
   return (void *)((char *)current + BLK_SIZE);

}

void * bf_malloc(size_t size){
    if (start== NULL) {
    start=(Blk *)sbrk(0);
    }
    if (free_head == NULL){
      Blk * nb = sbrk(BLK_SIZE + size);
      nb->next = NULL;
      nb->prev = NULL;
      nb->size = size;
      return (void *)((char *) nb + BLK_SIZE);
    }
    Blk *current = free_head;
    Blk *ans = NULL;
    int min_diff=INT_MAX;
    int diff=0;
    while (current!= NULL) {
      if (current->size< size){
        current=current->next;
      }
      else if (current->size == size){
        removeFreeBlk(current);
        return (void *)((char *)current + BLK_SIZE);
      }
      else{
        diff = current->size - size;
        if (diff<min_diff){
          min_diff=diff;
          ans=current;
        }
        current = current->next;
      }
    }
    if (min_diff == INT_MAX){
      Blk * nb = sbrk(BLK_SIZE + size);
      nb->next = NULL;
      nb->prev = NULL;
      nb->size = size;
      return (void *)((char *) nb + BLK_SIZE);
    }
    split(size, ans);
    return (void *)((char *) ans + BLK_SIZE);
    
}


void removeFreeBlk(Blk * BlkToRemove) {
    if (BlkToRemove==NULL){
      return;
    }
    if (BlkToRemove != NULL && BlkToRemove->next == NULL && BlkToRemove->prev == NULL) {
      free_head = NULL;
      free_tail = NULL;
    }

    // if the block removed is the first block
    else if (free_head == BlkToRemove) {
      free_head = BlkToRemove->next;
      BlkToRemove->next=NULL;
      BlkToRemove->prev = NULL;
    }
    // if the block removed is the last block
    else if (free_tail == BlkToRemove){
      free_tail = BlkToRemove->prev;
      BlkToRemove->prev = NULL;
      free_tail->next=NULL;
    }
    // if the block removed is in the middle
    else {
      BlkToRemove->prev->next = BlkToRemove->next;
      BlkToRemove->next->prev = BlkToRemove->prev;
      BlkToRemove->next=NULL;
      BlkToRemove->prev = NULL;
    }
}

void split(size_t size, Blk * BlkToSplit) {
    if ( BlkToSplit != NULL && BlkToSplit->size > size + BLK_SIZE){
        Blk * secondBlk = (Blk *)((char *)BlkToSplit + size + BLK_SIZE);
        secondBlk->prev = NULL;
        secondBlk->next = NULL;
        secondBlk->size = BlkToSplit->size - size - BLK_SIZE;
        BlkToSplit->size = size;
        removeFreeBlk(BlkToSplit);
        addFreeBlk(secondBlk);
    }
    else{
        removeFreeBlk(BlkToSplit);
}
}


void ff_free(void * ptr) {
    Blk * BlktoFree = (Blk *)((char *)ptr - BLK_SIZE);
    addFreeBlk(BlktoFree);
    merge(BlktoFree);
}

void bf_free(void * ptr) {
    Blk * BlktoFree = (Blk *)((char *)ptr - BLK_SIZE);
    addFreeBlk(BlktoFree);
    merge(BlktoFree);
}

void addFreeBlk(Blk * BlkToAdd){
  if (free_head == NULL) {
    free_head = BlkToAdd;
    free_tail = BlkToAdd;
  }
  else if (BlkToAdd < free_head) {
    BlkToAdd->next=free_head;
    free_head->prev = BlkToAdd;
    free_head = BlkToAdd;
  }
  else {
    Blk *current = free_head;
    while (current != NULL) {
      if (current < BlkToAdd) {
        if (current->next > BlkToAdd) {
          BlkToAdd->prev = current;
          BlkToAdd->next = current->next;
          BlkToAdd->prev->next->prev = BlkToAdd;
          BlkToAdd->prev->next = BlkToAdd;
          break;
        }
        else if (current->next== NULL) {
          free_tail->next = BlkToAdd;
          BlkToAdd->prev = free_tail;
          free_tail = BlkToAdd;
          break;
        }
        else{
        current = current->next;
        }
      }
    }
  }

}

void merge(Blk * block) {
      if (block->prev != NULL && block == (Blk *)((char *)block->prev + block->prev->size + BLK_SIZE)) {
        block->prev->size = block->prev->size + block->size+ BLK_SIZE;
        block->prev->next = block->next;
        if (block!= free_tail) {
          block->next->prev = block->prev;
        }
        else{
          free_tail = block->prev;
        }
        block = block->prev;
    }
      if (block->next != NULL && block->next == (Blk *)((char *)block + block ->size + BLK_SIZE)) {
        block->size = block->size + block->next->size + BLK_SIZE;
        block->next = block->next->next;
       if (block->next== NULL) {
          free_tail = block;
        }
        else {
          block->next->prev = block;
        }
      }
}


