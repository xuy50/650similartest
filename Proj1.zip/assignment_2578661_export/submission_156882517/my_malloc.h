#include <unistd.h>

// Block strcut
typedef struct MyBlk {
  size_t size;
  struct MyBlk * prev;
  struct MyBlk * next;
}Blk;

#define BLK_SIZE sizeof(Blk)

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// Best fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

void addFreeBlk(Blk * BlkToAdd);
void removeFreeBlk(Blk * BlkToRemove);
void split(size_t size, Blk * BlkToSplit);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void merge(Blk * block);
