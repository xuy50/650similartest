# include <stdio.h>
# include <stdlib.h>


 unsigned long get_data_segment_size(); //in bytes
 unsigned long get_data_segment_free_space_size(); //in byte

// Struct to store the metadata of each block
struct free_meta {
    size_t size;
    struct free_meta *next;
};

typedef struct free_meta free_meta_t;

// Fit malloc
void * fit_malloc(size_t size, size_t type);

// Fit free
void fit_free(void *ptr);

// First Fit malloc
void * ff_malloc(size_t size);

// First Fit free
void ff_free(void *ptr);

// Best Fit malloc
void * bf_malloc(size_t size);

// Best Fit free
void bf_free(void *ptr);

// Add to the free list in the order of ascending address and merge adjacent free blocks if possible
void addToList(free_meta_t *curr);

// Remove from the free list
void removeFromList(free_meta_t *curr);

// Find fist fit block
void * findFirstFit(size_t size);

// Find best fit block
void * findBestFit(size_t size);

// Find fit
void * findFit(size_t size, size_t type);

// Merge adjacent free blocks
void merge(free_meta_t *curr);

// Merge free block from the front
void mergeFront(free_meta_t *curr);

// Merge free block from the back
void mergeBack(free_meta_t *curr);




