# include "my_malloc.h"
#include <unistd.h>

# define metaSize sizeof(free_meta_t)

// Global variables for the free list
free_meta_t *head;
free_meta_t *tail;

// Heap start var
void * heapStart  = NULL;

unsigned long data_segment = 0;
unsigned long free_space = 0;

 unsigned long get_data_segment_size(){
    return data_segment;

 } //in bytes
 unsigned long get_data_segment_free_space_size(){
    // Iterate through the list to get the total free space
    free_space = 0;
    free_meta_t *curr = head;
    while (curr != NULL){
        free_space += curr->size;
        curr = curr->next;
    }
    return free_space;
 }
  //in byte


// Fit malloc
void * fit_malloc(size_t size, size_t type){
    // Initialize head and tail of the list before open heap, use only once
    if (head == NULL){
        heapStart = sbrk(metaSize);
        // If sbrk fails, return NULL
        if(heapStart == (void *)(-1)){
            return NULL;
        }
        head = (free_meta_t *)heapStart;
        data_segment += metaSize;
        head->size = 0;
        head->next = NULL;
        tail = head;
    }

    // Try to find a free block that is large enough, return block ptr if found, else return NULL
    free_meta_t *curr = NULL;
    // If type = 0, use first fit
    if(type == 0){
        curr = findFirstFit(size);
    }
    // If type = 1, use best fit
    else if(type == 1){
        curr = findBestFit(size);
    }
    // If there is no such block, allocate more memory
    if (curr == NULL){
        curr = sbrk(size + metaSize);
        // printf("sbrk");
        if(curr == (void *)(-1)){
            return NULL;
        }
        data_segment += (size + metaSize);
        curr->size = size;
        curr->next = NULL;
    }
    void * returnPtr = (void *) ((char *)curr + metaSize);// casting
    return returnPtr;
}

// First Fit malloc
void * ff_malloc(size_t size){
    void * ptr = fit_malloc(size, 0);
    return ptr;
}

// Best Fit malloc
void * bf_malloc(size_t size){
    void * ptr = fit_malloc(size, 1);
    return ptr;
}

// Fit free
void fit_free(void *ptr){
    // Free the block
    if (ptr == NULL){
        return;
    }
    free_meta_t *curr = (free_meta_t *)((char *)ptr - metaSize);// casting
    // Add freed block to the list
    addToList(curr);
    // Merge adjacent free blocks when feasible
    // No need to check if the list is empty because the list is not empty when the block is freed
    merge(curr);
    return;
}

// Remove from the free list
void removeFromList(free_meta_t *curr){
    // If the list is empty
    if (head == heapStart){/////!!!!!!DEBUG change from NULL to heapStart
        return;
    }
    // If the block is the head
    if (curr == head){
        head = head->next;
        // If the list is empty after removing the head, set tail to the head
        if (head == NULL){
            head = heapStart;/////!!!!!!DEBUG change from NULL to heapStart
            tail = head;
        }
        return;
    }
    // If the block is the tail
    // Have at least two blocks in the list here
    else if (curr == tail){
        free_meta_t *prev = head;
        // Find the previous free block
        while (prev->next != curr){
            prev = prev->next;
        }
        prev->next = NULL;
        tail = prev;
        return;
    }

    // If the block is in the middle
    // Have at least three blocks in the list here
    else{
        free_meta_t *prev = head;
        // Find the previous free block
        while (prev->next != curr){
            prev = prev->next;
        }
        prev->next = curr->next;
        return;
    }
}


// Find fit
void * findFit(size_t size, size_t type){
    free_meta_t *curr = head;
    // If type = 0, use first fit
    if(type == 0){
        while (curr != NULL && curr->size < size){
            curr = curr->next;
            // printf("findfit type 0");
        }
    }
    // If type = 1, use best fit
    else if(type == 1){
        free_meta_t *best = NULL;
        while (curr != NULL){
            if (curr->size == size){
                best = curr;
                break;
            }
            else if (curr->size > size && (best == NULL || curr->size < best->size)){
                best = curr;
            }
            curr = curr->next;
        }
        curr = best;
    }
    // If there is block that is large enough
    if (curr != NULL){
        // Allocate the block
        removeFromList(curr);
        curr->next = NULL;
        size_t currBlkSize = curr->size;
        size_t remainSize = currBlkSize - size;
        // Allocate requested size and create a new free block if remaining space is large enough
        if (remainSize > metaSize){
            //free_meta_t *newBlk = (free_meta_t *)((char *)curr + size + metaSize);// casting
            free_meta_t *newBlk = (free_meta_t *)((char *)curr + size +metaSize);// casting without adding metaSize
            newBlk->next = NULL;
            newBlk->size = remainSize - metaSize;
            addToList(newBlk); 
            // size of the "free list" = (actual usable free space + space occupied by metadata) of the blocks in free list
            // free_space += (newBlk->size - currBlkSize);///////////DEBUG : comment out 
            // Allocate requested size
            curr->size = size;
            return curr;
        }
        // remaning space is not enough to create a new free block
        else {
            // Allocate the whole block
            curr->size = currBlkSize;
            // free_space -= currBlkSize;/////////DEBUG : comment out
            return curr;
        }
    }
    // No free block is large enough
    return curr;
}


// Find fist fit block
void * findFirstFit(size_t size){
    return findFit(size, 0);
}

// Find best fit block
void * findBestFit(size_t size){
    return findFit(size, 1);
}

// First Fit free
void ff_free(void *ptr){
    fit_free(ptr);
}

// Best Fit free
void bf_free(void *ptr){
    fit_free(ptr);
}

// Add to the free list in the order of ascending address
void addToList(free_meta_t *curr){
    // If the list is empty
    if (head == heapStart){/////////////DEBUG: Changed from head == NULL
        head = curr;
        tail = curr;
        curr->next = NULL;
        return;
    }
    // If adress of current block is smaller than the head
    // There is at least one block in the list
    else if (curr < head){
        curr->next = head;
        head = curr;
        return;
    }

    //If address of current block is larger than the tail
    // There is at least one block in the list
    else if (curr > tail){
        tail->next = curr;
        tail = curr;
        curr->next = NULL;
        return;
    }

    // If address of current block is in the middle
    // There is at least two blocks in the list
    else {
        free_meta_t *prev = head;
        // Find the previous free block
        while (prev->next < curr && prev->next != NULL){
            prev = prev->next;
        }
        curr->next = prev->next;
        prev->next = curr;
        return;
    }
}

// Merge free block from the front
void mergeFront(free_meta_t *curr){
    {
    free_meta_t *prev = head;
    // Find the previous free block
    while (prev->next != curr && prev->next != NULL){
        prev = prev->next;
    }
    size_t prevBlkSize = prev->size + metaSize;
    // If previous block is adjacent to current block, merge them
    if((free_meta_t *)((char *)prev + prevBlkSize) == curr){
        prev->size += curr->size + metaSize;
        prev->next = curr->next;
    }
    }
}

// Merge free block from the back
void mergeBack(free_meta_t *curr){
    size_t currBlkSize = curr->size + metaSize;
    
    // If the next free block is adjacent to current block, merge them
    if((free_meta_t *)((char *)(curr) + currBlkSize) == curr->next){
        curr->size += curr->next->size + metaSize;
        if(curr->next != tail){
            curr->next = curr->next->next;  
        }
        else {
            curr->next = NULL;
            tail = curr;
        }
        
    }
}

// Merge adjacent free blocks around the current block
void merge(free_meta_t * curr){
    // if there is free block after the current block
    if (curr->next != NULL){
        mergeBack(curr);
    }

    // if there is free block before the current block
    if (curr != head){
        mergeFront(curr);
    }
    
}
