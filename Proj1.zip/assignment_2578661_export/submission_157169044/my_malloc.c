#include "my_malloc.h"
#include <stdlib.h>
#include <stdint.h>

freeBlock_t *head = NULL;
size_t metaDataSize = sizeof(freeBlock_t);
size_t countHeapSize = 0;
size_t countFreeSize = 0;

void* ff_find_block(size_t size){
    freeBlock_t *curr = head;
    while(curr!= NULL){
        if(curr->size >= size){
            return curr;
        }
        curr = curr->next;
    }
    return curr;
}

void updateBlock(size_t size, freeBlock_t *curr){
    size_t newSize = curr->size - metaDataSize - size;
    //printf("Current addr is: %p, the curr size is %ld and input size is: %ld\n", (void*)curr, curr->size, size);
    //printf("The new block size would be: %ld\n", newSize);
    if(curr->size > metaDataSize + size){
        freeBlock_t *newCurr = (freeBlock_t *)((uint8_t *)curr + metaDataSize + size);
        newCurr->size = curr->size - metaDataSize - size;
        //curr->prev->next = newCurr;
        //curr->next->prev = newCurr;
        //newCurr->prev = curr;
        //newCurr->next = curr->next;
        //printf("The newCurr addr is: %p, the size is: %ld\n", (void*)newCurr, newCurr->size);
        curr->size = size;
        //curr->next = newCurr;
        addBlock(newCurr);
    }
    countFreeSize -= (size + metaDataSize);
    deleteBlock(curr);
    /*
    printf("After the update, the new free list is:\n");
    printBlock();
    printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    */
}

void addBlock(freeBlock_t *blockToAdd){
    //printf("Into AddBlock Function!\n");
    freeBlock_t *curr = head;
    if(curr == NULL){
        head = blockToAdd;
        //printf("Head value is: %ld, head addr is: %p\n", blockToAdd->size, (void*)head);
        return;
    }
    while(curr != NULL){
        //printf("Into AddBlock Function!\n");
        //ls
        //printf("Head value is: %ld, head addr is: %p\n", blockToAdd->size, (void*)head);
        void *addrCurr = (void*) curr;
        void *addrToAdd = (void*) blockToAdd;
        if(addrCurr > addrToAdd && curr->prev == NULL){
            head = blockToAdd;
            blockToAdd->prev = NULL;
            blockToAdd->next = curr;
            curr->prev = blockToAdd;
            //printf("Now Head value is: %ld, head addr is: %p\n", head->size, (void*)head);
            return;
        }else if(addrCurr < addrToAdd && curr->next == NULL){
            curr->next = blockToAdd;
            blockToAdd->prev = curr;
            blockToAdd->next = NULL;
            //printf("Now Head value is: %ld, head addr is: %p\n", head->size, (void*)head);
            return;
        }else if(addrCurr < addrToAdd && addrToAdd < (void*)curr->next){
            blockToAdd->prev = curr;
            blockToAdd->next = curr->next;
            blockToAdd->next->prev = blockToAdd;
            curr->next = blockToAdd;
            //printf("Now Head value is: %ld, head addr is: %p\n", head->size, (void*)head);
            return;
        }
        curr = curr->next;
    }
}

void deleteBlock(freeBlock_t *blockToDelete){
    //if(blockToDelete->prev == NULL && blockToDelete->next == NULL){
    if(blockToDelete->prev == NULL && blockToDelete->next == NULL){    
        blockToDelete->prev = NULL;
        blockToDelete->next = NULL;
        head = NULL;
    }else if(blockToDelete->prev == NULL){
        head = blockToDelete->next;
        blockToDelete->next->prev = NULL;
        blockToDelete->next = NULL;
    }else if(blockToDelete->next == NULL){
        blockToDelete->prev->next = NULL;
        blockToDelete->prev = NULL;
    }else{
        blockToDelete->prev->next = blockToDelete->next;
        blockToDelete->next->prev = blockToDelete->prev;
        blockToDelete->prev = NULL;
        blockToDelete->next = NULL;
    }
}

// First fit malloc & free
void *ff_malloc(size_t size){
    //freeBlock_t *addr = NULL;
    if(size == 0){
        return NULL;
    }
    //printBlock();
    // Find the appropriate location
    void *addr = ff_find_block(size);
    
    if(addr != NULL){
        //printf("Find the addr, it is: %p\n", addr);
        freeBlock_t *freeBlock = (freeBlock_t*) addr;
        // If find the same size, replace it, then delete the whole free block from the freelist
        if(freeBlock->size == size){
            deleteBlock(freeBlock);
            /*
            printf("After delete the block, the new free list is:\n");
            printBlock();
            printf("******************************************\n");
            */
            countFreeSize -= (size + metaDataSize);
            return (void*)(addr + metaDataSize);
        }
        // If find the place larger than required, then update the block
        //printf("Find larger memory! Should split the block!\n");
        if(freeBlock->size > size){
            updateBlock(size, freeBlock);
            return (void*)(addr + metaDataSize);
        }
    }
    // If there is no appropriate location, allocate new place for data
    // For size, it should be dataSize + metaDataSize
    void *newAddr = sbrk(size + metaDataSize);
    if(newAddr == (void*)(-1)){
        return NULL;
    }
    // If use the server, the 
    freeBlock_t *newBlock = (freeBlock_t *)newAddr;
    countHeapSize += size + metaDataSize;
    //countAllocated += size + metaDataSize;
    newBlock->size = size;
    newBlock->prev = NULL;
    newBlock->next = NULL;
    //printf("No current free block! The new Block's size is: %ld and the addr is: %p\n", newBlock->size, (void*)newAddr);
    
    return (void*)((char*)newAddr + metaDataSize);
}

// Have some problems

void checkAndMerge(freeBlock_t *curr){
    void* addrCurr = (void*) curr;
    if(curr->next != NULL){
        void* addrCurrNext = (void*) curr->next;
        if(addrCurr + metaDataSize + curr->size == addrCurrNext){
            //printf("Satisfy Merge Back!\n");
            //size_t currSize = (size_t) (addrCurrNext - addrCurr);
            curr->size = curr->size + metaDataSize + curr->next->size;
            deleteBlock(curr->next);
            /*
            if(curr->next->next != NULL){
                curr->next->next->prev = curr;
            }
            curr->next = curr->next->next;
            */
        }
    }
    if(curr->prev != NULL){
        void* addrCurrPrev = (void*) curr->prev;
        if(addrCurrPrev + metaDataSize + curr->prev->size == addrCurr){
            //printf("Satisfy Merge Front!\n");
            curr->prev->size = curr->prev->size + metaDataSize + curr->size;
            deleteBlock(curr);
            /*
            curr->prev->next = curr->next;
            if(curr->next != NULL){
                curr->next->prev = curr->prev;
            }
            curr = curr->prev;
            */
        }
    }
    // freeBlock_t *curr = head;
    // //printf("Begin cheching!\n");
    // while(curr != NULL && curr->next != NULL){
    //     //printf("Iterate to merge the free space!\n");
        
    //     if((curr + metaDataSize + curr->size) == curr->next){
    //         freeBlock_t *toMerge = curr->next;
    //         //newCurr->prev = curr->prev;
    //         //newCurr->next = curr->next->next;
    //         //newCurr->size = curr->size + metaDataSize + curr->next->size;
    //         //addBlock(newCurr);
    //         //printf("In Merge: Delete!\n");
    //         //deleteBlock(curr);
    //         curr->next = curr->next->next;
    //         curr->size = curr->size + metaDataSize + toMerge->size;
    //         deleteBlock(curr->next);

    //         //printf("In Merge: Add!\n");
            
    //         //curr = newCurr;
    //     }
    //     curr = curr->next;
    // }
}

void ff_free(void *ptr){
    if(ptr == NULL){
        return;
    }
    freeBlock_t *curr = (freeBlock_t*)(ptr - metaDataSize);
    //printf("In Free!\n");
    addBlock(curr);
    countFreeSize += curr->size + metaDataSize;
    checkAndMerge(curr);
    //printBlock();
}



// Malloc performance study
unsigned long get_data_segment_size(){
    return countHeapSize;
}

unsigned long get_data_segment_free_space_size(){
    //return countFreeSize;
    
    unsigned long ans = 0;
    freeBlock_t *cur = head;
    while(cur != NULL){
        ans = ans + cur->size + metaDataSize;
        cur = cur->next;
    }
    return ans;  
    
}

void printBlock(){
    printf("\n");
    printf("Begin print the block ******************\n");    

    freeBlock_t *curr = head;
    if(head == NULL){
        printf("Attention! Head is NULL!\n");
    }else{
        printf("Head value is: %ld, head addr is: %p\n", head->size, (void*)head);
        while(curr){
            printf("The current free block size: %ld, the addr of free block is: %p\n", curr->size, (void*) curr);
            curr = curr->next;
        }
    }
    printf("\n");

}

void* bf_find_block(size_t size){
    if(size == 0){
        return NULL;
    }
    if(head == NULL){
        return NULL;
    }
    freeBlock_t *curr = head;
    size_t smallestLarger = curr->size;
    if(smallestLarger == size){
        return (void*)curr;
    }
    freeBlock_t *record = head;
    while(curr != NULL){
        if(curr->size >= size){
            if(curr->size == size){
                return (void*)curr;
            }
            if(smallestLarger < size){
                smallestLarger = curr->size;
                continue;
            }
            if(smallestLarger > size){
                if(curr->size < smallestLarger){
                    smallestLarger = curr->size;
                    record = curr;
                }
            }
        }
        curr = curr->next;
    }
    if(smallestLarger > size){
        return (void*)record;
    }
    return NULL;
}

void *bf_malloc(size_t size){
        //freeBlock_t *addr = NULL;
    if(size == 0){
        return NULL;
    }
    //printBlock();
    // Find the appropriate location
    void *addr = bf_find_block(size);
    
    if(addr != NULL){
        //printf("Find the addr, it is: %p\n", addr);
        freeBlock_t *freeBlock = (freeBlock_t*) addr;
        // If find the same size, replace it, then delete the whole free block from the freelist
        if(freeBlock->size == size){
            deleteBlock(freeBlock);
            countFreeSize -= (size + metaDataSize);
            return (void*)(addr + metaDataSize);
        }
        // If find the place larger than required, then update the block
        //printf("Find larger memory! Should split the block!\n");
        if(freeBlock->size > size){
            updateBlock(size, freeBlock);
            return (void*)(addr + metaDataSize);
        }
    }
    // If there is no appropriate location, allocate new place for data
    // For size, it should be dataSize + metaDataSize
    void *newAddr = sbrk(size + metaDataSize);
    if(newAddr == (void*)(-1)){
        return NULL;
    }
    freeBlock_t *newBlock = (freeBlock_t *)newAddr;
    countHeapSize += size + metaDataSize;
    //countAllocated += size + metaDataSize;
    newBlock->size = size;
    newBlock->prev = NULL;
    newBlock->next = NULL;
    //printf("No current free block! The new Block's size is: %ld and the addr is: %p\n", newBlock->size, (void*)newAddr);
    
    return (void*)newAddr + metaDataSize;
}
void bf_free(void *ptr){
    ff_free(ptr);
}


