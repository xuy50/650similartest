#ifndef __MY_MALLOC_H__
#define __MY_MALLOC_H__

#include <stdio.h>
#include <unistd.h>


struct _freeBlock_t{
    size_t size;
    struct _freeBlock_t *prev;
    struct _freeBlock_t *next;
};

typedef struct _freeBlock_t freeBlock_t;

void* ff_find_block(size_t size);
void updateBlock(size_t size, freeBlock_t *curr);
void addBlock(freeBlock_t *blockToAdd);
void deleteBlock(freeBlock_t *blockToDelete);

// First fit malloc & free
void *ff_malloc(size_t size);
void checkAndMerge();
void ff_free(void *ptr);

// Best fit malloc & free
void *bf_find(size_t size);
void *bf_malloc(size_t size);
void bf_free(void *ptr);

// Malloc performance study
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in bytes

void printBlock();

#endif