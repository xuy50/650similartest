//
//  my_malloc.c
//  650_hw1
//
//  Created by 徐金言 on 1/22/23.
//

#include "my_malloc.h"

size_t data_segment_size = 0; //total data segment size
size_t free_data_size= 0;     //current free data size in total data
block * head = NULL;          //initialize the head of the list recording free block sizes

void *ff_malloc(size_t size){
    return allocate_space(size,0);
}
void *bf_malloc(size_t size){
    return allocate_space(size,1);
}

//use mode to determine to do first-fit or best-fit
block * find_helper(size_t size,int mode){
  if(mode==0){return find_ff_helper(size);}
  if(mode==1){return find_bf_helper(size);}
}

//fisrt-fit, traverse the free-block list and find the first block whose size >=requested size
block* find_ff_helper(size_t size){
    if(head==NULL){return NULL;}
    block * ff_block=head;
    for(;ff_block!=NULL;ff_block=ff_block->next){
        if(ff_block->size>=size){return ff_block;}
    }
    return NULL;
}

//best-fit
block * find_bf_helper(size_t size){
   if(head==NULL){return NULL;}
    size_t min_size=head->size;   //set the initialized min value as head size
    block * bf_block=head;
    block * min_fit_block=NULL;
    for(;bf_block!=NULL;bf_block=bf_block->next){
            if(bf_block->size==size){return bf_block;}
            //if current block size equal to request, best, directly return
            if(bf_block->size>size && (min_fit_block==NULL || bf_block->size<min_size)){
            //update the best fit block to be the one > requested size and < recorded satisfied smallest block
            min_size=bf_block->size;
            min_fit_block=bf_block;
        }
    }
    return min_fit_block;
}


/*
 This allocate_space is suitable for both bf and ff.
 Firstly, use the helper function to choose the block need to allocated to user acordding current mode.
 My block setting use size to record the redundent size of this block which can be allocated for user,
 exclude the size of one metadata of itself.
 a. If there is one exiseted block whose size >= requested size, then use this block
    There is two choices for this situation.
    When the block size >=the requested size+one meta data size, means after giving the requested size  to user, there is redundent space (>=one meta data), allowing further split the block
    Otherwise, after giving the requested size, that the remaining free space in this block is too small to keep track of, so just allocate all of this block
 b. No existed block satisfied, use sbrk to creat one new and allocate.
 */
void * allocate_space(size_t size,int mode){
block * ff_block = find_helper(size,mode);
size_t increment=size+sizeof(block);
  if (ff_block!=NULL){//use existed block
      if (ff_block->size>=increment ){
          //When the block size >=the requested size+one meta data size, split the block

        block *extra = (block *)((void *)ff_block + size+sizeof(block));
        free_data_size-= size + sizeof (block);
   
            extra->size = ff_block->size-sizeof(block)-size;

            extra->pre=ff_block->pre;
            extra->next=ff_block->next;
            if(extra->next!=NULL){
                extra->next->pre=extra;
            }
            if(extra->pre!=NULL){
                extra->pre->next=extra;
            }else{
                head=extra;}
            ff_block->size=size;

      }
          else{ //size<ff_block->size<increment, allocate this to user and not split
            reomve_free_block(ff_block);
            free_data_size-= ff_block->size + sizeof (block);
          }
      }
      else{ //increase the heap, total data_segment_size increased by requested size+one metadata
          data_segment_size+=increment;
          ff_block=sbrk(increment);
          ff_block->size=size;
      }
    //initialize the allocated block and return
       ff_block->pre=NULL;
       ff_block->next=NULL;
       return (void *)ff_block+sizeof(block);
}


void ff_free(void *ptr){
    free_block(ptr);
}

void bf_free(void *ptr){
    free_block(ptr);
}
//When freeing one block, it is firstly inserted to the free list and then merge with adjuncate blocks
void free_block(void *ptr){
    if(ptr==NULL){return;}
    block * addBlock = (block *)((void *)ptr - sizeof(block));
      free_data_size+= addBlock->size +sizeof(block);
      insert_free(addBlock);
      block * b1=addBlock;
    //see i
       if(addBlock->pre){ b1=merge_free_blocks(addBlock->pre,addBlock);}
       if(b1->next){merge_free_blocks(b1,b1->next);}
}
//when allocating, remove the block from the current-free list, pay attention to head and tailer
void reomve_free_block(block * cur){
   if(cur!=head){
        if(cur->next!=NULL){
            cur->next->pre=cur->pre;
        }
        if(cur->pre!=NULL){
            cur->pre->next=cur->next;
        }
     }
    else{head=cur->next;
      if(cur->next!=NULL){
        cur->next->pre=NULL;}
    }
}

//When freeing, add the freed block to the current-free list
void insert_free(block * addblock){
    if(head==NULL){
           head = addblock;
           return;
       }
           block * cur = head;
           while(cur!=NULL){
               if (cur==head && addblock < cur){
                   //insert to be head
                 addblock->pre = NULL;
                 head = addblock;
                 addblock->next = cur;
                 cur->pre = addblock;
                 return;
               }
               if (cur < addblock&&(cur->next > addblock ||cur->next==NULL)){
                   //insert after the addblock
                   addblock->next = cur->next;
                   if(cur->next!=NULL){cur->next->pre = addblock;}
                   cur->next = addblock;
                   addblock->pre = cur;

                   //block->next->pre = block;
                   return;
               }
             cur = cur->next;
           }
}
//merge two adjuncate blocks if the previous one location plus prev-size plus one metadata is equal to current block location
block * merge_free_blocks(block * pre, block * cur){
   
       if((void *)pre+pre->size+sizeof(block)==cur){
           //If merge, then
             pre->next=cur->next;
             if(cur->next!=NULL){
                 cur->next->pre=pre;}
           //increase the prev block size with the second size plus one metadata size(for the second one)
             pre->size+=sizeof(block)+cur->size;
           //cur is removed and intialise to be null
             cur->pre=NULL;
             cur->next=NULL;
             return pre;
         }
         return cur;
     }


unsigned long get_data_segment_size(){
    return (unsigned long)data_segment_size;
}
unsigned long get_data_segment_free_space_size(){
    return (unsigned long)free_data_size;
}


