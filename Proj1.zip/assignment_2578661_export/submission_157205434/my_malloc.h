//
//  my_malloc.h
//  650_hw1
//
//  Created by 徐金言 on 1/22/23.
//

#ifndef my_malloc_h
#define my_malloc_h
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
struct block_struct{
    struct block_struct * pre;
    struct block_struct * next;
    size_t size;
};
typedef struct block_struct block;


void *ff_malloc(size_t size);
void *bf_malloc(size_t size);
block * find_helper(size_t size,int mode);
block* find_ff_helper(size_t size);
block* find_bf_helper(size_t size);
void * allocate_space(size_t size,int mode);

void ff_free(void *ptr);
void bf_free(void *ptr);
void free_block(void *ptr);
void reomve_free_block(block * cur);
void insert_free(block * addblock);
block * merge_free_blocks(block * pre, block * cur);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


#endif /* my_malloc_h */
