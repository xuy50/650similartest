/**
**@author Yu Wu(yw479)
**@date 2023-01-28
**23spring ECE650 project1
*/

#ifndef MY_MALLOC_H
#define MY_MALLOC_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// linked list nodes that keep track of the allocated/freed blocks
struct _block_data {
  size_t size;
  struct _block_data * next;
  struct _block_data * prev;
};
typedef struct _block_data block_data;

// the head and tail of the linked list
block_data * head;
block_data * tail;
// the allocated size
size_t alloc_size;

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

block_data * request_mem(size_t size);  // request new memory, when there is no qualified free block

block_data * find_best(block_data * h, size_t size);  // find the best match in the list

void merge(block_data * cur_ptr);  // when free, merge the continuous blocks
void split(block_data * cur_ptr, size_t req_size);  // when malloc, split the large block

void add_blk(block_data * blk);  // add the freed block to the tail of the linked list
void add_blk_ascending(block_data * blk);  // add the block in the ascending order
void delete_blk(block_data * blk); 

unsigned long get_data_segment_size();

unsigned long get_data_segment_free_space_size();

#endif
