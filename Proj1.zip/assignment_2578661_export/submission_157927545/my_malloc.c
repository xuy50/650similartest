/**
**@author Yu Wu(yw479)
**@date 2023-01-28
**23spring ECE650 project1
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "my_malloc.h"

// request new mem from the heap
block_data * request_mem(size_t size) {
  block_data * new_b = sbrk(size + sizeof(block_data)); // allocate new mem
  new_b->size = size;
  new_b->next = NULL;
  new_b->prev = NULL;
  return new_b;
}

// when free
// add the new block in ascending order
void add_blk_ascending(block_data * blk) {
  block_data * cur = head;
  int found = 0;
  while (cur != NULL) {
    if (cur->size > blk->size) {
      found = 1;
      if (cur == head) {
        head->prev = blk;
        blk->next = head;
        head = blk;
      } else {
        blk->prev = cur->prev;
        blk->next = cur;
        cur->prev->next = blk;
        cur->prev = blk;
      }
      break;
    }
    cur = cur->next;
  }
  if (found == 0 && cur == NULL) {
    tail->next = blk;
    blk->prev = tail;
    tail = blk;
  }
}

// when free
// add the new block to the tail of the freed block list in address ascending
// order
void add_blk(block_data * blk) {
  // the linked list is empty
  if (head == NULL) {
    head = blk;
    tail = head;
  } else {
    block_data * cur = head;
    while (cur != NULL) {
      if (cur < blk && cur->next > blk) {
        blk->prev = cur;
        blk->next = cur->next;
        cur->next->prev = blk;
        cur->next = blk;
        break;
      }
      if (cur > blk && cur == head) {
        blk->prev = NULL;
        blk->next = head;
        head->prev = blk;
        head = blk;
        break;
      }
      if (cur < blk && cur == tail) {
        blk->next = NULL;
        blk->prev = tail;
        tail->next = blk;
        tail = blk;
        break;
      }
      cur = cur->next;
    }
  }
}

// when malloc
// delete the block from the list
void delete_blk(block_data * blk) {
  if (head == blk) {
    if (head != tail) { // if the block is not the only block in the list
      blk->next->prev = NULL;
      head = blk->next;
      blk->next = NULL;
    } else {
      head = NULL;
      blk->prev = NULL;
      blk->next = NULL;
    }
  } else if (tail == blk) {
    if (tail != head) {
      blk->prev->next = NULL;
      tail = blk->prev;
      blk->prev = NULL;
    } else {
      tail = NULL;
      blk->prev = NULL;
      blk->next = NULL;
    }
  } else {
    blk->prev->next = blk->next;
    blk->next->prev = blk->prev;
    blk->prev = NULL;
    blk->next = NULL;
  }
}

// return the best match block pointer
block_data * find_best(block_data * h, size_t size) {
  block_data * cur = head;
  block_data * best = NULL; // the best match
  block_data * ff_b = NULL; // first founded available free block

  // traverse the whole list, find the smallest available size
  while (cur != NULL) {
    if (cur->size >= size) {
      if (ff_b == NULL) {
        ff_b = cur;
        best = cur; // initialize the best
      } else {
        if (cur->size < best->size) {
          best = cur; // update the best
        }
      }
    }
    cur = cur->next;
  }
  if (ff_b == NULL) { // no qualified block found
    return NULL;
  } else {
    return best;
  }
}

// when free, merge the next block to the current block
void merge(block_data * cur_ptr) {
  size_t m_size = cur_ptr->size + sizeof(block_data) + cur_ptr->next->size;
  // if the next block is tail
  if (cur_ptr->next->next == NULL) {
    cur_ptr->next->prev = NULL;
    cur_ptr->next = NULL;
    tail = cur_ptr;
    cur_ptr->size = m_size;
  } else {
    cur_ptr->next->next->prev = cur_ptr;
    cur_ptr->next = cur_ptr->next->next;
    cur_ptr->next->next = NULL;
    cur_ptr->next->prev = NULL;
    cur_ptr->size = m_size;
  }
}

// when malloc, split the large block
void split(block_data * cur_ptr, size_t req_size) {
	/*
	size_t next_size = cur_ptr->size - req_size - sizeof(block_data);
  block_data *next_b =
      (block_data *)((void *)cur_ptr + sizeof(block_data) +
                     req_size); // the start address of the next block
  next_b->size = next_size;
  // printf("next_b: %p, cur_b: %p\n", next_b, cur_ptr);
	next_b->next = cur_ptr->next;
  next_b->prev = cur_ptr;
	
	cur_ptr->next = next_b;
  if (cur_ptr->next == tail) {
    tail = next_b;
  } else {
    cur_ptr->next->prev = next_b;
  }

  cur_ptr->size = req_size;
	*/
}


void * ff_malloc(size_t size) {
  if (size == 0) {
    return NULL;
  }
  // the free list is empty
  if (head == NULL) {
    // printf("ff malloc with no head.\n");
    block_data * ptr = request_mem(size); // the start address of a block
    alloc_size += size + sizeof(block_data);
    return (void *)ptr + sizeof(block_data); // the real address to allocate
  }
  // the free list is not empty
  else {
    // printf("ff malloc with head.\n");
    int found = 0;
    block_data * cur = head;
    while (cur != NULL) {
      if (cur->size >= size) {
        found = 1;
        if (cur->size - size - sizeof(block_data) > 0) {
          split(cur, size);
        }
        void * ptr = (void *)cur + sizeof(block_data);
        delete_blk(cur);
				alloc_size += size + sizeof(block_data);
        return ptr;
      }
      cur = cur->next;
    }
    // no available block in free list found
    if (cur == NULL && found == 0) {
      block_data * ptr = request_mem(size);
      alloc_size += size + sizeof(block_data);
      return (void *)ptr + sizeof(block_data);
    }
  }
}

// when free add the block to the list
void ff_free(void *ptr) {
  if (ptr != NULL) {
    // printf("ff free.\n");
    block_data * free_block_ptr =
        (block_data *)(ptr - sizeof(block_data)); // a pointer points to the
                                                  // freed mem (with block info)
    if (head == NULL) {
      head = free_block_ptr;
      tail = head;
    } else {
      add_blk(free_block_ptr);
      if (free_block_ptr->next != NULL) {
        if (((void *)free_block_ptr + sizeof(block_data) +
             free_block_ptr->size) == (void *)free_block_ptr->next) {
          merge(free_block_ptr);
        }
      }
      if (free_block_ptr->prev != NULL) {
        if (((void *)free_block_ptr->prev + sizeof(block_data) +
             free_block_ptr->prev->size) == (void *)free_block_ptr) {
          merge(free_block_ptr->prev);
        }
      }
    }
    alloc_size -= (free_block_ptr->size + sizeof(block_data));
  } else {
    return;
  }
}

void * bf_malloc(size_t size) {
  if (size == 0) {
    return NULL;
  }
  // the free list is empty
  if (head == NULL) {
    block_data * ptr = request_mem(size);
    alloc_size += size + sizeof(block_data);
    return (void *)ptr + sizeof(block_data); // the real allocation address
  }
  // the free list is not empty
  else {
    block_data * best = find_best(head, size);
    if (best != NULL) {
      if (best->size - size - sizeof(block_data) > 0) {
        split(best, size);
      }
			void * ptr = (void *)best + sizeof(block_data);
      delete_blk(best);
			alloc_size += size + sizeof(block_data);
      return ptr;
    } else {
      block_data * ptr = request_mem(size);
      alloc_size += size + sizeof(block_data);
      return (void *)ptr + sizeof(block_data);
    }
  }
}

void bf_free(void *ptr) {
  if (ptr != NULL) {
    // printf("ff free.\n");
    block_data * free_block_ptr =
        (block_data *)(ptr - sizeof(block_data)); // a pointer points to the
                                                  // freed mem (with block info)
    if (head == NULL) {
      head = free_block_ptr;
      tail = head;
    } else {
      add_blk(free_block_ptr);
      if (free_block_ptr->next != NULL) {
        if (((void *)free_block_ptr + sizeof(block_data) +
             free_block_ptr->size) == (void *)free_block_ptr->next) {
          merge(free_block_ptr);
        }
      }
      if (free_block_ptr->prev != NULL) {
        if (((void *)free_block_ptr->prev + sizeof(block_data) +
             free_block_ptr->prev->size) == (void *)free_block_ptr) {
          merge(free_block_ptr->prev);
        }
      }
    }
    alloc_size -= (free_block_ptr->size + sizeof(block_data));
  } else {
    return;
  }
}

unsigned long get_data_segment_size() { return (unsigned long)alloc_size; }

unsigned long get_data_segment_free_space_size() {
  unsigned long res = 0;
  block_data * cur = head;
  while (cur != NULL) {
    res += cur->size + sizeof(block_data);
    cur = cur->next;
  }
  return res;
}
