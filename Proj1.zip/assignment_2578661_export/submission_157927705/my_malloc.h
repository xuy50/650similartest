#include<stdio.h> 
#include<stdlib.h>
#ifndef my_malloc_h
#define my_malloc_h
struct block{
   size_t size;
   struct block* prev;
   struct block* next;
}; 
typedef struct block Block;
void* ff_malloc(size_t size);
void  ff_free(void*ptr);
void* bf_malloc(size_t size);
void bf_free(void* ptr);
unsigned long get_data_segment_size();
void removeBlock(Block*ptr);
unsigned long get_data_segment_free_space_size();
int get_brk_time();
int get_head_null();
void printFree();
void printFront();
int get_alloc_null();
#endif
