#include<stdlib.h> 
#include<stdio.h>
#include "my_malloc.h"
#include <unistd.h> 
Block* head_block=NULL; 
Block*last_block=NULL; 
Block*mid_block=NULL;
unsigned long block_count=0;
unsigned long data_size=0;
unsigned long free_size=0; 
int repeat=0;
Block* search_free_block(size_t size,int is_ff){
	if(size<0){
	 return NULL;
	}
	if(is_ff){
	   Block*start_ptr=head_block;
	   while(start_ptr!=NULL){
	   	 if(start_ptr->size>=size){
	   	 	return start_ptr;
		 }else{
		 	if(start_ptr->next!=NULL){
		 		if(start_ptr->next->size<size){
		 			start_ptr=start_ptr->next->next;
				}else{
					return start_ptr->next;
				}
			}else{
				break;
			}
		 }
	   }
	   return NULL;
	}
	int mini_size=2147483647;
	int exist=0;
	Block*start_ptr=head_block;
	Block*p2=start_ptr; 
	while(start_ptr!=NULL){
		if(start_ptr->size>=size){
			exist+=1;
			int dif=start_ptr->size-size;
			if(dif<=mini_size){
				mini_size=dif;
			p2=start_ptr;
				if(dif==0){
					break;
				}else{
				  start_ptr=start_ptr->next;	
				}
			}else{
				start_ptr=start_ptr->next;
			}
		}else{
			if(start_ptr->next!=NULL){
				if(start_ptr->next->size<size){
					start_ptr=start_ptr->next->next;
				}else{
					start_ptr=start_ptr->next;
				}
			}else{
				break;
			}
		}
	}
	if(exist==0){
	return NULL;
	}
	return p2;
}
void merge_two_block(Block*p1,Block*p2){
	 if(p1==NULL||p2==NULL){
	 	return;
	 }
	 if((void*)p1+p1->size+sizeof(Block)==(void*)p2){
	    p1->size+=p2->size+sizeof(Block);
	    removeBlock(p2);
     }	
}
void merge_next_block(Block* freed_block){
  if(freed_block==NULL){
  	return;
  }
  merge_two_block(freed_block,freed_block->next);
  merge_two_block(freed_block->prev,freed_block);
}
void* createBlock(size_t size){
  if(size<=0){
  	return NULL;
  }
  	Block* new_block=(Block*)sbrk(size+sizeof(Block));
  	data_size+=size+sizeof(Block);
  	new_block->size=size;
  	new_block->prev=NULL;
  	new_block->next=NULL;
  	return (void*)new_block+sizeof(Block);
}
void removeBlock(Block* bptr){
	Block* btr=bptr;
	int cnt=0;
	block_count-=1;
	if(mid_block!=NULL){
		mid_block=mid_block->prev;
	}
	if(head_block==NULL){
		head_block=NULL;
		last_block=NULL;
	}else if(head_block->next==NULL){
		head_block=head_block->next;
		last_block=NULL;
	}else{
	  if(btr->next==NULL){
		btr=btr->prev;
		btr->next=NULL;
		last_block=btr;
	  }else if(btr->prev==NULL){
		head_block=head_block->next;
		head_block->prev=NULL;
	  }else{
		btr->prev->next=btr->next;
		btr->next->prev=btr->prev;
	  }	
	}
}
void add_merge(Block*ptr,int merge_yes){
 if(ptr==NULL){
  return;
 }
 block_count+=1;
 int answer=0;
 if(block_count==5000&&mid_block==NULL){
 	mid_block=ptr;
 }
 if(head_block==NULL){
 	head_block=ptr;
 	head_block->next=NULL;
	head_block->prev=NULL; 
	last_block=head_block;
 }else if(ptr>last_block){
 	ptr->prev=last_block;
 	ptr->next=NULL;
 	last_block->next=ptr;
 	last_block=last_block->next;
 }else if(ptr<head_block){                                                          
 //	printf("helloge\n");
 	head_block->prev=ptr;
    ptr->next=head_block;
    ptr->prev=NULL;
    head_block=ptr;
    last_block=head_block->next;
 }else{
 	Block*S=head_block;
 	if(block_count>5000&&mid_block!=NULL&&answer==0){
 			if(mid_block->next!=NULL){
 				if(ptr>mid_block->next){
 					 S=mid_block->next;
 			         answer+=1;
				 }
			 }
	}
 	while(S->next!=NULL&&ptr>S->next){
 		int sat=0;
 		if(block_count>5000&&mid_block!=NULL&&answer==0){
 			if(mid_block->next!=NULL){
 				if(ptr>mid_block->next){
 					 S=mid_block->next;
 			         answer+=1;
 			         sat+=1;
				 }
			 }
		 }
 	   if(S->next->next!=NULL&&sat==0){
 			if(ptr>S->next->next){
 				     if(S->next->next->next!=NULL){
 				    	if(ptr>S->next->next->next){
 				    		S=S->next->next->next;
						 }else{
						 	S=S->next->next;
						 }
					 }else{
					 	S=S->next->next;
					 }
			}else{
				S=S->next;
			}
	   }else if(sat==0){
			S=S->next;
	   }
	}
	if(S->next==NULL){
		if(head_block->next==NULL){
			ptr->prev=head_block;
			ptr->next=NULL;
			head_block->next=ptr;
			last_block=ptr;
		}else{
			ptr->prev=S;
			ptr->next=NULL;
			S->next=ptr;
			last_block=ptr;
		}
	}else{
	   ptr->next=S->next;
	   ptr->prev=S;
	   S->next->prev=ptr;
	   S->next=ptr;
	}
 }
 if(merge_yes){
   merge_next_block(ptr);
 }
}
void* splitBlock(Block* bptr, size_t size){
	Block* s_block=(Block*)((void*)bptr+size+sizeof(Block));
	s_block->size=bptr->size-size-sizeof(Block);
	s_block->next=NULL;
	s_block->prev=NULL;
	removeBlock(bptr);
    add_merge(s_block,0);
	bptr->size=size;
	return (void*)bptr+sizeof(Block);
}
void* ff_malloc(size_t size){
  if(size<0){
  	return NULL;
  }
  if(head_block==NULL){
    return createBlock(size);
  }
    Block*block_ptr=search_free_block(size,1);
    if(block_ptr==NULL){
      return createBlock(size);
	}
	if(block_ptr->size>=size){
  		if(block_ptr->size>size+sizeof(Block)){
  			 free_size-=size+sizeof(Block);
  		   	return splitBlock(block_ptr,size);
	    }else if(block_ptr->size>=size){
	    	 free_size-=size+sizeof(Block);
	    	removeBlock(block_ptr);
	    	return (void*)block_ptr+sizeof(Block);
		}
	}
  return NULL;
}
void ff_free(void* ptr){
	if(ptr==NULL){
	  return;
	}
    Block* freed_block=(Block*)((void*)ptr-sizeof(Block));
    free_size+=freed_block->size+sizeof(Block);
    add_merge(freed_block,1);
	return; 
}
void* bf_malloc(size_t size){
	if(size<0){
	  return NULL;
	}
	if(head_block==NULL){
     return createBlock(size);
	}
    Block*p2=search_free_block(size,0);
    if(p2==NULL){
       return createBlock(size);
	}
	if(p2->size>size+sizeof(Block)){
		 free_size-=size+sizeof(Block);
  		 return splitBlock(p2,size);
	}else{
		 free_size-=size+sizeof(Block);
	     removeBlock(p2);
	     return (void*)p2+sizeof(Block);
	 }	   
	return NULL;
}
void bf_free(void*ptr){
  if(ptr==NULL){
    return;
  }
  ff_free(ptr);
}
unsigned long get_data_segment_size(){
  return data_size;
}
unsigned long get_data_segment_free_space_size(){
  return free_size;
}
