#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

struct space{
  size_t sz;
  struct space* nxt;
  struct space*prev;
};

typedef struct space SpaceBlock;

SpaceBlock* first_free=NULL;

size_t all_space=0;
size_t free_space=0;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte




