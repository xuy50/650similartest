#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "my_malloc.h"



void print(){
  printf("\n");
  SpaceBlock* cur=first_free;
  while(cur){
    printf("%ld  ",cur->sz);
    cur=cur->nxt;
  }
  printf("\n");
}

void *new_block(size_t size){
  all_space+=sizeof(SpaceBlock)+size;
  SpaceBlock* new_sb=sbrk(sizeof(SpaceBlock)+size);
  new_sb->sz=size;
  new_sb->nxt=NULL;
  new_sb->prev=NULL;
  return (void *)new_sb+sizeof(SpaceBlock);
}

void removes(SpaceBlock* cur){
  if (cur==first_free){
    first_free=first_free->nxt;
    if(first_free){first_free->prev=NULL;}
  }
  if(cur->prev){
    cur->prev->nxt=cur->nxt;}
  if(cur->nxt){
    cur->nxt->prev=cur->prev;}
  cur->prev=NULL;
  cur->nxt=NULL;
  return;
}
void *old_block(SpaceBlock* cur,size_t size){  
  if (cur->sz<=size+sizeof(SpaceBlock)){//not sure
    free_space-=cur->sz+sizeof(SpaceBlock);
    removes(cur);
    return (void*)cur+sizeof(SpaceBlock);
  }
  else{
    free_space-=size+sizeof(SpaceBlock);
    SpaceBlock* cur_used=(void*)cur+cur->sz-size;
    cur_used->nxt=NULL;
    cur_used->prev=NULL;
    cur_used->sz=size;
    cur->sz-=size+sizeof(SpaceBlock);
    return (void*)cur_used+sizeof(SpaceBlock);
  }
}

void freee(void *ptr){
  //in address order
  //old_space also need modification
  SpaceBlock* sb=ptr-sizeof(SpaceBlock);
  free_space+=sb->sz+sizeof(SpaceBlock);
  if(first_free==NULL){
    first_free=sb;
    return;
  }
  SpaceBlock* cur=first_free;
  SpaceBlock* l=NULL;
  SpaceBlock* r=NULL;
  while(cur){
    if(cur>sb){
      r=cur;
      break;
    }
    if(cur->nxt==NULL){
      l=cur;
    }
    cur=cur->nxt;
  }

  if(r){
    l=r->prev;
    if((void*)sb+sb->sz+sizeof(SpaceBlock)==r){
      sb->sz+=sizeof(SpaceBlock)+r->sz;
      //sb replace r_space
      sb->prev=r->prev;
      sb->nxt=r->nxt;
      if(r->nxt){r->nxt->prev=sb;}
      if(r->prev){r->prev->nxt=sb;}
      if(first_free==r){first_free=sb;}
      return;
    }
  }
  if(l && (void*)l+l->sz+sizeof(SpaceBlock)==sb){
    l->sz+=sizeof(SpaceBlock)+sb->sz;
    return;
  }

  if(first_free==r){first_free=sb;}
  sb->nxt=r;
  sb->prev=l;
  if(l){l->nxt=sb;}
  if(r){r->prev=sb;}
  return;
}

//First Fit malloc/free
void *ff_malloc(size_t size){
  SpaceBlock* cur=first_free;
  while(cur){
    if(cur->sz>=size){
      return old_block(cur,size);
    }
    cur=cur->nxt;
  }
  return new_block(size);
}

void ff_free(void *ptr){
  freee(ptr);
}

//Best Fit malloc/free
void *bf_malloc(size_t size){
  SpaceBlock* good_space=NULL;
  SpaceBlock* cur=first_free;
  if(!first_free){
    return new_block(size);
  }
  while(cur){
    if(cur->sz==size){return old_block(cur,size);}
    if(cur->sz>size){
      if (good_space==NULL||good_space->sz>cur->sz){good_space=cur;}
    }
    cur=cur->nxt;
  }
  if(good_space){
    return old_block(good_space,size);
  }
  return new_block(size);
}

void bf_free(void *ptr){
  freee(ptr);
}

unsigned long get_data_segment_size(){
  return all_space;
  }
unsigned long get_data_segment_free_space_size(){
  return free_space;
}


