#include "my_malloc.h"

unsigned long segment_size = 0;
unsigned long free_segment_size = 0;


/*
    only split free regions if the remain length can hold the meta header
    remove curr, and add extra free space (new block) to the list
    Otherwise, simply remove curr
*/
void split(memBlock * curr, size_t size){
    if (curr->size > HEADER_SIZE + size){ // can hold meta and size
        memBlock * newBlock = (memBlock *)((void *)curr + HEADER_SIZE + size); // move to extra
        if (curr->prev != NULL) {
            curr->prev->next = newBlock;
        } else {
            head = newBlock;
            head->prev = NULL;
        }
        if (curr->next != NULL){
            curr->next->prev = newBlock;
        } 
        newBlock->next = curr->next;
        newBlock->prev = curr->prev;
        newBlock->size = curr->size - HEADER_SIZE - size;
        // remove and renew curr
        curr->size = size;
        curr->prev = NULL;
        curr->next = NULL;
        free_segment_size = free_segment_size - size - HEADER_SIZE; // delete free segmentation
    } else {
        removeBlock(curr); // cannot hold, remove
    }
}

/*
    remove block, and improve free segmentation
*/
void removeBlock(memBlock *curr){ 
    if (curr->prev != NULL){
        curr->prev->next = curr->next;
    } else { // curr at head
        head = curr->next;
    }
    if (curr->next != NULL){ // curr not at end, update next
        curr->next->prev = curr->prev;
    } 
    curr->next = NULL;
    curr->prev = NULL;
    free_segment_size = free_segment_size - curr->size - HEADER_SIZE;
}

/*
    normalized malloc function for first fit and best fit
    if not find the fit_address, sbrk
    if find the block, split and update it
*/
void *real_malloc(memBlock* fit_addr, size_t size){
    if (fit_addr == NULL){
        memBlock * newBlock = (memBlock *) sbrk(HEADER_SIZE + size);
        if (newBlock == (void *)-1) {
           return NULL;
        } 
        newBlock->prev = NULL;
        newBlock->next = NULL;
        newBlock->size = size;
        segment_size = segment_size + HEADER_SIZE + size; // improve the total segment size
        return (void *)newBlock + HEADER_SIZE;
    }else{
        split(fit_addr, size);
        return (void *)fit_addr + HEADER_SIZE;
    }
}


/*
    insert the new free block into the free list, improve the free segmentation
*/
void insertBlock(memBlock *newBlock){
    if (head == NULL){ // empty
        head = newBlock;
    } else if (newBlock < head) { // before head node
        head->prev = newBlock;
        newBlock->next = head;
        newBlock->prev = NULL;
        head = newBlock;
    }  else { // after curr
        memBlock * curr = head;
        while (curr->next != NULL && curr->next < newBlock){ // after curr
            curr = curr->next;
        }
        if (curr->next == NULL) { // after tail
            newBlock->prev = curr;
            newBlock->next = NULL;
            curr->next = newBlock;
        } else {
            curr->next->prev = newBlock;
            newBlock->next = curr->next;
            curr->next = newBlock;
            newBlock->prev = curr;
        }     
    }
    free_segment_size = free_segment_size + newBlock->size + HEADER_SIZE;
    mergeBlocks(newBlock);
}

/*
    merge the curr block with the previous one and the next one
*/
void mergeBlocks(memBlock * curr){
    curr = mergeTwoBlocks(curr->prev, curr);
    curr = mergeTwoBlocks(curr, curr->next);
}

/*
    @desc merge two blocks
    @param first block and second block
    @return second if cannot merge, first if merged
*/
memBlock * mergeTwoBlocks(memBlock * first, memBlock * second){
    if (first == NULL) {
        return second;
    }
    if (second == NULL) {
        return first;
    }
    if (((void *)first + first->size + HEADER_SIZE) != (void *)second){
        return second;
    }
    first->size = first->size + second->size + HEADER_SIZE;
    if (second->next != NULL) {
        second->next->prev = first;
    }
    first->next = second->next;
    return first;
}

/*
    find the first fit address that is the first enough region to hold
*/
memBlock *get_ff_addr(size_t size){
    memBlock * curr = head;
    memBlock * fit_addr = NULL;
    while (curr != NULL){
        if (curr->size >= size){
            fit_addr = curr;
            break;
        }
        curr = curr->next;
    }
    return fit_addr;
}
       
/*
    allocate the first fit region
 */
void *ff_malloc(size_t size){
    memBlock * ff_addr = get_ff_addr(size);
    return real_malloc(ff_addr, size);
}

/*
    free function for first fit
*/
void ff_free(void *ptr){
    insertBlock((memBlock *) (ptr - HEADER_SIZE));
}

/*
    find best fit address, has the smallest num of bytes greater than or equal to the required
*/
memBlock *get_bf_addr(size_t size){
    memBlock * curr = head;
    memBlock * fit_addr = NULL;
    while (curr != NULL) {
        if (curr->size > size) {
            if (fit_addr == NULL || (curr->size < fit_addr->size)) {
                fit_addr = curr;
            }
        }
        if (curr->size == size) {
            fit_addr = curr;
            break;
        }
        curr = curr->next;
  }
    return fit_addr;
}

/*
    allocate the best fit region
*/
void *bf_malloc(size_t size){
    memBlock * bf_addr = get_bf_addr(size);
    return real_malloc(bf_addr, size);
}

/*
    free function for best fit
*/
void bf_free(void *ptr){
    insertBlock((memBlock *) (ptr - HEADER_SIZE));
}


unsigned long get_data_segment_size() {
  return segment_size;
}

unsigned long get_data_segment_free_space_size() {
   return free_segment_size;
}
