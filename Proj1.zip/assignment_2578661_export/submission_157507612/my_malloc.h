#ifndef __MALLOC_H__
#define __MALLOC_H__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 

#define HEADER_SIZE sizeof (memBlock)

typedef struct memBlock_t{
    size_t size;
    struct memBlock_t * prev;
    struct memBlock_t * next;
} memBlock;

memBlock * head = NULL;

// first fit
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// best fit
void *bf_malloc(size_t size);
void bf_free(void *ptr);

// for malloc
void split(memBlock * curr, size_t size);
void removeBlock(memBlock *curr);
void *real_malloc(memBlock* fit_addr, size_t size);
memBlock *get_ff_addr(size_t size);
memBlock *get_bf_addr(size_t size);

// for free
void insertBlock(memBlock *newBlock);
void mergeBlocks(memBlock * curr);
memBlock * mergeTwoBlocks(memBlock * first, memBlock * second);

// for performance
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


#endif