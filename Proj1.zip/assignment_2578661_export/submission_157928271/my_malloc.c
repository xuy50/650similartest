#include "my_malloc.h"


unsigned long get_data_segment_size() {
  return total_space;
}

unsigned long get_data_segment_free_space_size() {
  return free_space;
}
//
void add_func(Block * ptr) {
  Block * node = head;
  if (head ==NULL){
  ptr->next=NULL;
  ptr->prev=NULL;
  head=ptr;
  tail=ptr;
  return;
  }
  
  if (ptr < head){ //add before head ,no need consider tail
  ptr->prev = NULL;
  ptr->next = head;
  ptr->next->prev = ptr;
  head = ptr;
  return;
  }
    
  while ((node->next != NULL) ) {
    if (ptr < node->next && ptr>node){
    ptr->prev = node;
    ptr->next = node->next;
    node->next = ptr;
    ptr->next->prev = ptr;
    return;
    
    }
    node = node->next;  
  }
  ptr->prev = node;
  ptr->next = node->next;
  node->next = ptr;
  tail = ptr;
  return;

}

void delete_func(Block * ptr) {
  if (head==NULL) return;
  if ((head == tail) && (tail == ptr)) {
    head = NULL;
    tail =NULL;
    return;
  }
  if (tail == ptr) {
    tail = ptr->prev;
    tail->next = NULL;
    return;
  }
  if (head == ptr) {
    head = ptr->next;
    head->prev = NULL;
    return;
  }
  
    ptr->prev->next = ptr->next;
    ptr->next->prev = ptr->prev;
    return;
}
void merge (Block * ptr){
if (head ==NULL) return;
if (head==tail && tail ==ptr ) return;
void * expect_next=(ptr ==tail)? NULL:(void *)ptr + ptr->size + sizeof(Block) ;
void * expect_cur= (ptr==head)? NULL :(void *)ptr->prev + ptr->prev->size + sizeof(Block);
if ((ptr!=tail) && (expect_next== (void *)ptr->next)) {
    ptr->size = ptr->next->size + sizeof(Block) + ptr->size;
    delete_func(ptr->next);
  }
  if ((ptr!=head) &&(expect_cur == (void *)ptr)) {
    ptr->prev->size= ptr->size +sizeof(Block) + ptr->prev->size;
    delete_func(ptr);
  }
}
//////
void * alloc_mem(size_t size){


Block * node = sbrk(size + sizeof(Block));
node->size = size;
total_space = total_space+ size + sizeof(Block);
Block * res =(Block *)((char *)node + sizeof(Block));
return (res ==NULL)? NULL:res;

}
////

void * ff_malloc(size_t size) {
  //case 1 empty free list
  if (head == NULL){
  Block * ans =alloc_mem(size);
  return (ans ==NULL)? NULL:ans;
  
  }
  //case 2 freelist not empty
  Block * cur = head;
    while (cur != NULL) {//iterate from head to tail
      if (size <=cur->size) {
        
        if (cur->size < size + sizeof(Block)*2){
        delete_func(cur);
        free_space = free_space-cur->size - sizeof(Block);
        
        }
        else{
        split(size, cur);
        }
        //return (void *)node + sizeof(Block);
        Block * res =(Block *)((char *)cur + sizeof(Block));
        return (res ==NULL)? NULL:res;
        
      }
      cur = cur->next;
    }
    
  //case 3 cannot find block large enough
  //get a block by sbrk
  Block * ans =alloc_mem(size);
  return (ans ==NULL)? NULL:ans;

}

void * split(size_t size, Block * p) {
  
    Block * node = (void *)((void *)p + sizeof(Block) + size);
    node->size = p->size - size - sizeof(Block);
  p->size = size;
    delete_func(p);
    add_func(node);
    free_space -= (size + sizeof(Block));
}




void ff_free(void * ptr) {
  Block * t=(Block *)((char *)ptr - sizeof(Block));
  
  free_space += t->size + sizeof(Block);
  add_func(t);
  merge(t);

  
}

void * bf_malloc(size_t size) {
  
  Block * best_blk = NULL;
  int find_best=0;
  Block * cur = head;
  while (cur != NULL) {
  if (cur->size == size) {
      best_blk = cur;
      find_best=1;
      break;
      }
    if (size<cur->size ) {
      
      if (best_blk == NULL ) {
        best_blk = cur;
        find_best=1;
      }
      else if (best_blk->size>cur->size){
        best_blk = cur;
        find_best=1;
      
      }
    }
    
    cur = cur->next;
  }
  if (find_best==1) {
    //return reuse_block(size, best_blk);
    if (best_blk->size < size + sizeof(Block)*2){
        delete_func(best_blk);
        free_space -= (best_blk->size + sizeof(Block));
        
        }
        else{
        split(size, best_blk);
        }
        Block * res =(Block * )((char *)best_blk + sizeof(Block));
        return (res ==NULL)? NULL:res;
        //return (void *)best_blk + sizeof(Block);
  }
  else {
    
  Block * ans =alloc_mem(size);
  return (ans ==NULL)? NULL:ans;
  }
}

void bf_free(void * ptr) {
  Block * t= (Block *)((char *)ptr - sizeof(Block));
  
  free_space =free_space+ sizeof(Block)+t->size;
  add_func(t);
  merge(t);

}

