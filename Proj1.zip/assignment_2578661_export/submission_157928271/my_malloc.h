#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//data size
unsigned long get_data_segment_size();             
unsigned long get_data_segment_free_space_size();  

//metadata block
struct block {
  size_t size;
  
  struct block * next;
  struct block * prev;
};
typedef struct block Block;

//helper functions
void add_func(Block * p);
void delete_func(Block * p);
void * split(size_t size, Block * p);
void merge (Block * p);

//malloc and free
void * ff_malloc(size_t size);
void * bf_malloc(size_t size);
void ff_free(void * ptr);
void bf_free(void * ptr);

Block * head = NULL;
Block * tail = NULL;
size_t total_space = 0;
size_t free_space = 0;
