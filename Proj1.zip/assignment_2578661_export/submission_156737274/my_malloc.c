#include "my_malloc.h"
#include <stdio.h>
#include <stdbool.h>

#define METADATA_SZ sizeof(metadata_t)

void* heap_bottom = NULL;
unsigned long free_space_total = 0;
unsigned int list_size = 0;

// static head & tail of free list for easier implementation
metadata_t head;
metadata_t tail;

metadata_t head = {
    .prev = &tail,
    .next = &tail,
    .sz = 0
};

metadata_t tail = {
    .prev = &head,
    .next = &head,
    .sz = 0
};

unsigned long get_data_segment_size() {
    return (unsigned long)(sbrk(0) - heap_bottom);
}

unsigned long get_data_segment_free_space_size() {
    return free_space_total;
}

// add curr before next
void add_before_next_to_list(metadata_t* curr, metadata_t* next) {
    metadata_t* prev = next->prev;
    curr->next = next;
    curr->prev = prev;
    prev->next = curr;
    next->prev = curr;
    list_size++;    
}

// delete curr from list
void delete_from_list(metadata_t* curr) {
    metadata_t* prev = curr->prev;
    metadata_t* next = curr->next;
    prev->next = next;
    next->prev = prev;
    curr->next = NULL;
    curr->prev = NULL;
    list_size--;
}

// internal debugging to see if list is broken
bool check_list() {
    metadata_t* curr = &head;
    for (int i = 0; i < list_size + 1; ++i) {
        curr = curr->next;
    }
    return curr == &tail;
}

void* ff_malloc(size_t size) {
    if (size <= 0) {
        return NULL;
    }
    metadata_t* curr = head.next;
    while (curr != &tail) {
        if (curr->sz >= size) {
            break;
        }
        curr = curr->next;
    }
    // find from free list
    if (curr != &tail) {
        // split and allocate memory
        if (curr->sz - size <= METADATA_SZ) {
            free_space_total -= curr->sz; // remain memory will never be allocated anyway; do not change curr->sz either
            delete_from_list(curr);
            return (void*)(curr + 1);
        }
        else {
            free_space_total -= size + METADATA_SZ;
            metadata_t* fragment = (void*)(curr + 1) + size;
            fragment->sz = curr->sz - size - METADATA_SZ;
            curr->sz = size; // change curr->sz here as its boundry changes
            add_before_next_to_list(fragment, curr->next);
            delete_from_list(curr);
            return (void*)(curr + 1);
        }
    }
    // allocate new memory
    else {
        curr = (metadata_t*)sbrk(size + METADATA_SZ);
        if (!heap_bottom) {
            heap_bottom = curr;
        }
        if (curr == (void*)-1) {
            perror("sbrk() failed!\n");
            return NULL;
        }
        curr->sz = size;
        curr->prev = NULL;
        curr->next = NULL;
        return (void*)(curr + 1);
    }
    return NULL;
}

void ff_free(void* ptr) {
    if (!ptr) {
        return;
    }
    metadata_t* curr = (metadata_t*)ptr - 1; // point to metadata
    metadata_t* next = head.next;
    while (next != &tail && next <= curr) {
        next = next->next;
    }
    add_before_next_to_list(curr, next);
    free_space_total += curr->sz;
    // check if freed block can be combined into prev
    if (curr->prev != &head && (unsigned int)((void*)curr - (void*)(curr->prev)) == curr->prev->sz + METADATA_SZ) {
        curr->prev->sz += curr->sz + METADATA_SZ;
        metadata_t* prev = curr->prev;
        delete_from_list(curr);
        curr = prev;
        free_space_total += METADATA_SZ;
    }
    // check if freed block can be combined into next
    if (curr->next != &tail && (unsigned int)((void*)(curr->next) - (void*)curr) == curr->sz + METADATA_SZ) {
        curr->sz += curr->next->sz + METADATA_SZ;
        delete_from_list(curr->next);
        free_space_total += METADATA_SZ;
    }
}

void* bf_malloc(size_t size) {
    if (size <= 0) {
        return NULL;
    }
    metadata_t* curr = head.next;
    metadata_t* ans = NULL;
    // find the best fit
    while (curr != &tail) {
        if (curr->sz >= size) {
            if (!ans || curr->sz < ans->sz) {
                ans = curr;
            }
            if (ans->sz == size) {
                break;
            }
        }
        curr = curr->next;
    }
    curr = ans;
    if (curr) {
        // split and allocate the memory
        if (curr->sz - size <= METADATA_SZ) {
            free_space_total -= curr->sz; // remain memory will never be allocated anyway
            delete_from_list(curr);
            return (void*)(curr + 1);
        }
        else {
            free_space_total -= size + METADATA_SZ;
            metadata_t* fragment = (void*)(curr + 1) + size;
            fragment->sz = curr->sz - size - METADATA_SZ;
            curr->sz = size;
            add_before_next_to_list(fragment, curr->next);
            delete_from_list(curr);
            return (void*)(curr + 1);
        }
    }
    else {
        curr = (metadata_t*)sbrk(size + METADATA_SZ);
        if (!heap_bottom) {
            heap_bottom = curr;
        }
        if (curr == (void*)-1) {
            perror("sbrk() failed!\n");
            return NULL;
        }
        curr->sz = size;
        curr->prev = NULL;
        curr->next = NULL;
        return (void*)(curr + 1);
    }
    return NULL;
}

void bf_free(void* ptr) {
    ff_free(ptr);
}