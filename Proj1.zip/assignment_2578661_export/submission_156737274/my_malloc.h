#ifndef _MY_MALLOC_H_
#define _MY_MALLOC_H_

#include <stddef.h>
#include <unistd.h>

// First Fit malloc/free
void* ff_malloc(size_t size);
void ff_free(void* ptr);

//Best Fit malloc/free
void* bf_malloc(size_t size);
void bf_free(void* ptr);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

typedef struct metadata {
    struct metadata* prev;
    struct metadata* next;
    unsigned int sz;
} metadata_t;

#endif