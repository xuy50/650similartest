#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <limits.h>

struct Node{
  size_t size;//free space not include meta info
  struct Node* next;
  struct Node* prev;
  int isFree;//1 free;0 occupied
};
typedef struct Node Node;
//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);  
unsigned long get_data_segment_size();//in bytes
unsigned long get_data_segment_free_space_size();//in byte
