
#include "my_malloc.h"
unsigned long data_segment_size = 0;
unsigned long free_segment_size = 0;
Node* head = NULL;
Node* tail = NULL;
int isFirst = 1;
void * startOfAll = NULL;
size_t nodeSize = sizeof(Node);

void  printMyList(void);
unsigned long get_data_segment_size(){
  return data_segment_size;
}

unsigned long get_data_segment_free_space_size(){
  return free_segment_size;
}



void addToList(Node * newNode){

  assert(newNode);
  if(head == NULL){
    head = newNode;
    tail = newNode;
  }
  else if(newNode < head){
    head->prev = newNode;
    newNode->next = head;
    head = newNode;
  }
  else if(newNode > tail){
    tail->next = newNode;
    newNode->prev = tail;
    tail = newNode;
  }
  else{
    Node * back = head;
    while(back < newNode){
      back = back->next;
    }
    Node * front = back->prev;
    assert(front < newNode);
    //begin inserting
    newNode->prev = front;
    newNode->next = back;
    front->next = newNode;
    back->prev = newNode;
  }

}

void *ff_malloc(size_t size){//Given a size, allocate a block that have enough space, and give back to user a pointer to that block
  //printf("ff_mallocing for a block of size %lu\n",size);
  //printMyList();
   //first, we want to know if there is a proper block in our free list because if there is, then we don't need to ask sbrk() for more space!
 //-->for the first part, we need to do the following"
  //1. Firstly, traverse the free list.
  //2.For each node, we examine if its size is large enough for the required size.
  //2.1 If the current node is suitable, then we need to do:
  //2.1.1 Remove this node from our 'free linkedlist'.
  //2.1.2 Examine if it's much larger than the required size by at least the size of a Node, if so, we need to split, and insert the splitted free space node into the list
  //3.If we didn't find such a node,we sbrk() and return that pointer to user.

  //if not, then we have to use sbrk() to allocate a new block and give it to user

  //Note: During the above process, make sure to give the correct value to size, next, prev, isFrEE and also be cautious when doing pointer arithmetic.


   
  Node* cur = head;
  while(cur != NULL){
    if(cur->size >= size){//found that suitable node, we will give it to user, so remove it now
      assert(free_segment_size >= cur->size);
      free_segment_size -= cur->size;
      assert(cur->isFree == 1);
      cur->isFree = 0;
      if(cur == head && head == tail){
        head = NULL;
        tail = NULL;
      }
      else if(cur == head){
        head->next->prev = NULL;
        head = cur->next;
      }
      else if(cur == tail){
        tail->prev->next = NULL;
        tail = cur->prev;
      }
      else{//it's a 'middle' node
        cur->prev->next = cur->next;
        cur->next->prev = cur->prev;
      }
      cur->prev = NULL;              
      cur->next = NULL;
       
      if(cur->size > size + nodeSize){//But! There is extra space, so we make that extra space a new Node and add to proper position of freelist

       
        Node * newNode = (Node *)((size_t)cur + nodeSize + size);
        newNode->size = cur->size - size - nodeSize;
        newNode->prev = NULL;
        newNode->next = NULL;
        newNode->isFree = 1;
        free_segment_size += newNode->size;
 
        addToList(newNode);
        
          cur->size = size;
      }
      //  printf("Reused! Will give block starting at address %p to user\n",cur);
      //printMyList();
      return cur + 1;
    }//end of high if
    cur = cur->next;
  }//end of while
  
  Node* newBlock = NULL;
  newBlock = sbrk(size + nodeSize);
  assert(newBlock != -1);//sbrk must succeed
  
  if(isFirst == 1){
    startOfAll = newBlock;
    isFirst = 0;
    }
 
  newBlock->size = size;
  newBlock->prev = NULL;
  newBlock->next = NULL;
  newBlock->isFree = 0;
  //printf("The addr using a void * + sizeof(Node) is:%p , and the addr using a Node * + 1 is: %p\n",newBlock+nodeSize,test+1);
  data_segment_size += (unsigned long)size +(unsigned long)nodeSize;
  //printf("sbrk()! Will give block starting at address %p to user\n",newBlock);
  //printf("current data_segment_size is: %lu",data_segment_size);
  return newBlock + 1; 
  
                             
}


void printMyList(void){
  /*  
  Node * cur = head;
  printf("Printing the list:\n");
  printf("Nodesize is : %lu\n",nodeSize);
  printf("Head : %p tail: %p\n",head,tail);
  while(cur != NULL){
    printf(" [addr:%p, size:%lu] --> \n",cur,cur->size);
    assert(cur->isFree == 1);
    cur = cur->next;
    }
  printf("\n\n");
  */
}

void ff_free(void * ptr){
 
  //1. Check if next adjacent block is free (is in the free list)
  //1.1 If so,remove next adjacent block from freelist && expand cur->size
  //1.2 If not, do nothing

  if(ptr == NULL){
    fprintf(stdout,"You are freeing a NULL pointer!");
    return;
  }
  // printf("ff_freeing address %p, which is a block of user-size %lu\n",ptr,((Node*)(ptr-nodeSize))->size);
  //printMyList();
 
  Node * curBlock = (Node *)((size_t)ptr - nodeSize);//ptr points to the usable space, and curBlock points to the very beginning of the block.


  assert(curBlock->prev == NULL);      
  assert(curBlock->next == NULL);
  assert(curBlock->isFree == 0);


  if(!head){
    head = curBlock;
    tail = curBlock;
    curBlock->isFree = 1;
    free_segment_size += curBlock->size;
    return;
  }
  Node * nextBlock = (Node *)((size_t)curBlock + (curBlock->size) + nodeSize);
 
  // void * currentBoundary = (void *)((unsigned long)startOfAll + data_segment_size);
  //  printf("cur bound:%p, sbrk(0):%p\n",currentBoundary,sbrk(0));
  // void * realBoundary = sbrk(0);
  //fprintf(stdout, "caculated boundary addr: %lu, sbrk(0) addr: %lu\n",(unsigned long)currentBoundary,(unsigned long)realBoundary);
  //  assert((size_t)currentBoundary == (size_t)realBoundary);
  // printf("currentlty the right boundary is at %p, and nextBlock is at %p\n",currentBoundary,nextBlock);
  //printf("2 variables %p, %d",nextBlock,nextBlock->isFree);
  //printf("3 variables:%p,%p,%d",nextBlock,currentBoundary,nextBlock->isFree);
  //printf("something!\n");
  if(nextBlock != NULL && (unsigned long)nextBlock < ((unsigned long)(sbrk(0) - startOfAll)) && nextBlock->isFree == 1 && nextBlock->size !=0 ){//in this case, there is block after the curBlock,check if it is free.
    curBlock->size += nextBlock->size + nodeSize; 
    nextBlock->isFree = 0;
    if(nextBlock == head && head == tail){
      assert(nextBlock->prev ==NULL && nextBlock->next == NULL);
      head = NULL;
      tail = NULL;
    }
    else if(nextBlock == head){
        head->next->prev = NULL;
        head = head->next;
    }
    else if(nextBlock == tail){
        tail->prev->next = NULL;
        tail = tail->prev;
    }
    else{//it's a 'middle' node
      nextBlock->prev->next = nextBlock->next;
      nextBlock->next->prev = nextBlock->prev;
    }
    nextBlock->prev = NULL; 
    nextBlock->next = NULL; 
  }
   //2.Add this newly freed block to tail of list and set boolean to true
  curBlock->isFree = 1;
  free_segment_size += curBlock->size;
 
 
  addToList(curBlock);
  //3.traver the entire freeList
  //3.1 If cur node has an adjacent free block,expand cur->size,remove the tailNode in list.
  //3.2 If not, continue traversing to next node in list
  /*
  Node * temp = head;
  assert(head != NULL);
  
  while(temp != NULL){
    Node * nextBlk = (Node *)((size_t)temp + nodeSize + temp->size);
    if(nextBlk && (unsigned long)nextBlk < (unsigned long)(sbrk(0) - startOfAll) && nextBlk->isFree == 1 && nextBlk->size != 0){
      //printf("Merging in second round!\n");
      //printf("Specifically, address starting at %p (size : %lu )is merging with its right neighbout at %p (size : %lu)\n ",temp,temp->size,nextBlk,nextBlk->size);
      temp->size += nextBlk->size + nodeSize;
      /*  
      tail->prev->next = NULL;
      tail = tail->prev;
      
      nextBlk->isFree = 0;
      nextBlk->prev = NULL;
      assert(nextBlk->next == NULL);
      free_segment_size += nodeSize + nextBlk->size;
      break;
      
      assert(nextBlk == temp->next);
      if(nextBlk == tail){
        tail = temp;
        temp->next = NULL;
      }
      else{
        temp->next = nextBlk->next;
        temp->next->prev = temp;
      }
      nextBlk->prev = NULL;
      nextBlk->next = NULL;
    }
    temp = temp->next;
  }
  */
  Node * f = curBlock->prev;
  if(f && (size_t)f + f->size + nodeSize == (size_t)curBlock){
    f->size += nodeSize + curBlock->size;
    curBlock->isFree = 0;
    free_segment_size += nodeSize;

    if(curBlock->next){
      f->next = curBlock->next;
      curBlock->next->prev =f;
    }else{
      tail = f;
      f->next = NULL;
    }
    curBlock->prev =NULL;
    curBlock->next =NULL;

  }




  
  //printf("After this ff_free, the list is:\n");
  //printMyList();
}



void *bf_malloc(size_t size){
   
  Node* cur = head;
  Node * best = NULL;
  size_t diff = INT_MAX;


  while(cur != NULL){
    if(cur->size >= size && (cur->size - size) < diff){
      best = cur;
      diff = cur->size - size;
      if(diff ==0){//it's already the best fit!
        break;
      }
    }
    cur = cur->next;
  }

  if(best != NULL){
    cur = best;
    assert(free_segment_size >= cur->size);
    free_segment_size -= cur->size;
    assert(cur->isFree == 1);
    cur->isFree = 0;
    if(cur == head && head == tail){
        head = NULL;
        tail = NULL;
    }
    else if(cur == head){
      head->next->prev = NULL;
      head = cur->next;
    }
    else if(cur == tail){
      tail->prev->next = NULL;
      tail = cur->prev;
    }
    else{//it's a 'middle' node
      cur->prev->next = cur->next;
      cur->next->prev = cur->prev;
    }
    cur->prev = NULL;              
    cur->next = NULL;   
    if(cur->size > size + nodeSize){//But! There is extra space, so we make that extra space a new Node and add to proper position of freelist
   
        Node * newNode = (Node *)((size_t)cur + nodeSize + size);
        newNode->size = cur->size - size - nodeSize;
        newNode->prev = NULL;
        newNode->next = NULL;
        newNode->isFree = 1;
        free_segment_size += newNode->size;
 
        addToList(newNode);
        
        cur->size = size;
      }
      //  printf("Reused! Will give block starting at address %p to user\n",cur);
      //printMyList();
      return cur + 1;
    }//end of high if
   
  Node* newBlock = NULL;
  newBlock = sbrk(size + nodeSize);
  assert(newBlock != -1);//sbrk must succeed
  
  if(isFirst == 1){
    startOfAll = newBlock;
    isFirst = 0;
    }
 
  newBlock->size = size;
  newBlock->prev = NULL;
  newBlock->next = NULL;
  newBlock->isFree = 0;
  //printf("The addr using a void * + sizeof(Node) is:%p , and the addr using a Node * + 1 is: %p\n",newBlock+nodeSize,test+1);
  data_segment_size += (unsigned long)size +(unsigned long)nodeSize;
  //printf("sbrk()! Will give block starting at address %p to user\n",newBlock);
  //printf("current data_segment_size is: %lu",data_segment_size);
  return newBlock + 1; 
  
                             
}
  
  
 


void bf_free(void * ptr){
  ff_free(ptr);
}

 
 
 
 
