#include "my_malloc.h"

#include "assert.h"

Node * nodeHead = NULL;
unsigned long data_segment_size = 0;
unsigned long data_segment_free_space_size = 0;

#define SIZEOFNODE sizeof(Node)

void updateNode(Node * ptr, Node * prev, Node * next, size_t size) {
  ptr->prev = prev;
  ptr->next = next;
  ptr->size = size;
}

Node * splitNode(Node * ptr, size_t size) {
  Node * newNode = (Node *)((void *)ptr + SIZEOFNODE + size);
  updateNode(newNode, ptr->prev, ptr->next, ptr->size - size - SIZEOFNODE);
  if (ptr->next) {
    ptr->next->prev = newNode;
  }
  if (ptr->prev) {
    ptr->prev->next = newNode;
  }
  else {
    nodeHead = newNode;
  }
  updateNode(ptr, NULL, NULL, size);
  return newNode;
}

void removeNode(Node * ptr) {
  if (ptr->next && ptr->prev) {
    ptr->next->prev = ptr->prev;
    ptr->prev->next = ptr->next;
    updateNode(ptr, NULL, NULL, ptr->size);
  }
  else if (ptr->next && !ptr->prev) {
    nodeHead = ptr->next;
    nodeHead->prev = NULL;
    ptr->next = NULL;
  }
  else if (!ptr->next && ptr->prev) {
    ptr->prev->next = NULL;
    ptr->prev = NULL;
  }
  else {
    nodeHead = NULL;
  }
}

Node * createSpace(size_t size) {
  void * tempNewNode = sbrk(size + SIZEOFNODE);
  assert(tempNewNode != (void *)-1);
  Node * newNode = tempNewNode;
  updateNode(newNode, NULL, NULL, size);
  data_segment_size += size + SIZEOFNODE;
  return newNode;
}

void checkNodeSize(Node * cur, size_t size) {
  if (cur->size > (size + SIZEOFNODE)) {
    splitNode(cur, size);
  }
  else {
    removeNode(cur);
  }
}

void * ff_malloc(size_t size) {
  Node * ptr = nodeHead;
  while (ptr != NULL) {
    if (ptr->size >= size) {
      checkNodeSize(ptr, size);
      return (void *)ptr + SIZEOFNODE;
    }
    ptr = ptr->next;
  }
  Node * newNode = createSpace(size);
  return (void *)newNode + SIZEOFNODE;
}

void * bf_malloc(size_t size) {
  Node * cur = nodeHead;
  Node * bestNode = NULL;
  while (cur != NULL) {
    if (cur->size == size) {
      bestNode = cur;
      break;
    }
    else if (cur->size > size) {
      if ((!bestNode) || (bestNode && bestNode->size > cur->size)) {
        bestNode = cur;
      }
    }
    cur = cur->next;
  }
  if (bestNode != NULL) {
    checkNodeSize(bestNode, size);
    return (void *)bestNode + SIZEOFNODE;
  }
  Node * newNode = createSpace(size);
  return (void *)newNode + SIZEOFNODE;
}

void myMerge(Node * cur) {
  if (cur->next && (void *)cur + cur->size + SIZEOFNODE == cur->next) {
    cur->size += cur->next->size + SIZEOFNODE;
    removeNode(cur->next);
  }
  if (cur->prev && ((void *)cur->prev + SIZEOFNODE + cur->prev->size == cur)) {
    cur->prev->size += cur->size + SIZEOFNODE;
    removeNode(cur);
  }
}

void myInsert(Node * cur) {
  Node * finder = nodeHead;
  Node * finderPrev = NULL;
  if (nodeHead == NULL) {
    updateNode(cur, NULL, NULL, cur->size);
    nodeHead = cur;
  }
  else if (nodeHead > cur) {
    updateNode(cur, NULL, nodeHead, cur->size);
    nodeHead->prev = cur;
    nodeHead = cur;
  }
  else {
    while (finder != NULL) {
      if (finder > cur)
        break;
      finderPrev = finder;
      finder = finder->next;
    }
    if (finder != NULL) {
      updateNode(cur, finderPrev, finder, cur->size);
      finderPrev->next = cur;
      finder->prev = cur;
    }
    else {
      updateNode(cur, finderPrev, NULL, cur->size);
      finderPrev->next = cur;
    }
  }
}

void myFree(void * ptr) {
  if (ptr == NULL)
    return;
  Node * cur = (Node *)((void *)ptr - SIZEOFNODE);
  myInsert(cur);
  myMerge(cur);
}

void ff_free(void * ptr) {
  myFree(ptr);
}

void bf_free(void * ptr) {
  myFree(ptr);
}

unsigned long get_data_segment_size() {
  return data_segment_size;
}

unsigned long get_data_segment_free_space_size() {
  Node * cur = nodeHead;
  while (cur) {
    data_segment_free_space_size += cur->size + SIZEOFNODE;
    cur = cur->next;
  }
  return data_segment_free_space_size;
}
