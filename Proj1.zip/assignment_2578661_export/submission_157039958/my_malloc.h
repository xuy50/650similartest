#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct _Node {
  size_t size;
  struct _Node * next;
  struct _Node * prev;
} typedef Node;

//First Fit
void * ff_malloc(size_t size);
void ff_free(void * pointer);

//Best Fit
void * bf_malloc(size_t size);
void bf_free(void * pointer);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
