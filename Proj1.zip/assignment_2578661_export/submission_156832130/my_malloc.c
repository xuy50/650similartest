#include "my_malloc.h"
#include <assert.h>
#include <stdio.h>

// Initialize the system and set the start address of the process.
void sys_init() {
  startposition = sbrk(sizeof(memtag));
  memtag * mt = startposition;
  mt->size = 0;
  mt->previous = mt;
  mt->next = mt;
  datasize = sizeof(memtag);
}

// Modify the information in metadata before allocating the address
void * init_addr(size_t size, void * addr) {
  void * ptr = addr + sizeof(memtag);
  memtag * mt = addr;
  mt->size = size;
  mt->next = NULL;
  mt->previous = NULL;
  return ptr;
}

void * ff_malloc(size_t size) {
  if (startposition == NULL) {
    sys_init();
  }
  memtag * mt = startposition;
  mt = mt->next;
  // Loop to find the first free memory block.
  while (mt != startposition) {
    if (mt->size >= size) {
      return split_and_use(size, mt);
    }
    mt = mt->next;
  }
  return gen_mem(size);
}

void ff_free(void * ptr) {
  free_mem(ptr);
}

void * bf_malloc(size_t size) {
  if (startposition == NULL) {
    sys_init();
  }
  memtag * mt = startposition;
  mt = mt->next;
  memtag * bf = mt;
  // Loop to find the best fit memory block.
  while (mt != startposition) {
    if (mt->size >= size) {
      bf = (bf->size < size || mt->size < bf->size) ? mt : bf;
      if (mt->size == size) {
        break;
      }
    }
    mt = mt->next;
  }
  if (bf->size >= size) {
    return split_and_use(size, bf);
  }
  return gen_mem(size);
}

void bf_free(void * ptr) {
  free_mem(ptr);
}

// Split a single memory into two parts and assign the first part. 
void * split_and_use(size_t size, memtag * mt) {
  if (mt->size - size >= sizeof(memtag) + 1) {
    memtag * newmt = (void *)(mt + 1) + size;
    newmt->size = mt->size - size - sizeof(memtag);
    newmt->next = mt->next;
    newmt->previous = mt->previous;
    mt->next->previous = newmt;
    mt->previous->next = newmt;
    freesize -= size + sizeof(memtag);
    return init_addr(size, mt);
  } else { // This memory cannot be split into two parts, so keep it as a whole and remove it from the free list.
    mt->next->previous = mt->previous;
    mt->previous->next = mt->next;
    freesize -= mt->size + sizeof(memtag);
    return init_addr(mt->size, mt);
  }
}

// Free the memory and add it to the free list.
void free_mem(void * ptr) {
  ptr -= sizeof(memtag);
  memtag * freedmt = ptr;
  memtag * mt = startposition;
  mt = mt->next;
  while (mt->next != startposition && (void *)(mt->next) < ptr) {
    mt = mt->next;
  }
  // Add the freed memory to the free list.
  freedmt->next = mt->next;
  freedmt->previous = mt;
  mt->next = freedmt;
  freedmt->next->previous = freedmt;
  freesize += freedmt->size + sizeof(memtag);
  merge_mem(freedmt);
  merge_mem(mt);
}

// Ask for new memory by calling sbrk() and return it.
void * gen_mem(size_t size) {
  void * newmem = sbrk(size + sizeof(memtag));
  datasize += size + sizeof(memtag);
  return init_addr(size, newmem);
}

// Merge two free memroy if they are continuous.
void merge_mem(memtag * mt) {
  if (mt == startposition || mt->next == startposition) {
    return;
  }
  if ((void *)(mt + 1) + mt->size == (void *)(mt->next)) {
    mt->size = mt->size + mt->next->size + sizeof(memtag);
    mt->next->next->previous = mt;
    mt->next = mt->next->next;
  }
}

unsigned long get_data_segment_size() {
  return datasize;
}

unsigned long get_data_segment_free_space_size() {
  return freesize;
}