#ifndef _MY_MALLOC_C
#define _MY_MALLOC_C

#include <unistd.h>

typedef struct mem_tag {
  size_t size;
  struct mem_tag * next;
  struct mem_tag * previous;
} memtag;

memtag * startposition = NULL;

unsigned long freesize = 0;

unsigned long datasize = 0;

void * ff_malloc(size_t size);

void ff_free(void * ptr);

void * bf_malloc(size_t size);

void bf_free(void * ptr);

void sys_init();

void * init_addr(size_t size, void * addr);

void * ff_malloc(size_t size);

void free_mem(void * ptr);

void * split_and_use(size_t size, memtag * mt);

void merge_mem(memtag * mt);

void * gen_mem(size_t size);

unsigned long get_data_segment_size();

unsigned long get_data_segment_free_space_size();

#endif