#include <stdlib.h>

// First Fit malloc/free
// size is the size of payload
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// Best Fit malloc/free
// size is the size of payload
void *bf_malloc(size_t size);
void bf_free(void *ptr);

typedef struct Meta_tag Meta;
// meta data of the block
struct Meta_tag {
    // payload size
    size_t size;
    int free; // 1 indicates its a free block, 0 not a free block, for debugging -1 means no longer a valid block
    Meta * prev_block; // prev_block can be deleted, if we use macro function to calculate address
    Meta * next_block; 
    Meta * prev_free; // valid only if this block is a free block 
    Meta * next_free; // valid only if this block is a free block 
};

#define META_SIZE sizeof(Meta)

typedef Meta* (*search_t) (size_t size);
// mymalloc allocate a memory of desired size using free block searching
// function findFree
void *mymalloc(size_t size, search_t findFree);
// myfree free a memory pointed by ptr
void myfree(void *ptr);
// Find the first free block that can hold a payload of given size
// If such block doesn't exist return NULL
Meta * findFirst(size_t size);
// Find the best free block that can hold a payload of given size
// If such block doesn't exist return NULL
Meta * findBest(size_t size);



// function merge this block with previous block. constraints previous
// block exist and is not free. 
void mergePrev(Meta * block);
// Allocate block of desired size in the free block. i.e. make
// the start of the free block the allocated block. The rest unoccupied
// region a new free block. (Corner case. if the rest region is not large
// enough for storing meta data for free block. Give all space to the
// allocated block)
void splitFree(Meta *free_block, size_t size);
// The function adds a block  that's not in the free list to the free list
void addFree(Meta *block);
// The function removes this free_block from the free list
void rmFree(Meta *free_block);
// request enough memory at the top of the data segment to load payload of indicated
// size. If there are some free spaces at the top, extend those free space until payload
// can fit in. return pointer to the allocated block.
Meta *requestMemory(size_t size);

// return size of entire heap memory (including meta data) in bytes
unsigned long get_data_segment_size();
// return the totall size of all free_spaces (including meta data) in bytes
unsigned long get_data_segment_free_space_size();

// iterator_t type specify how to go from one block to the other
typedef Meta* (*iterator_t) (Meta*);
// get the total size of all blocks (including Meta data) in the iterable
unsigned long get_size(Meta *begin, iterator_t next);
// iterator for the list of all blocks
Meta *get_next_block(Meta *block);
// iterator for the list of all free_blocks
Meta *get_next_free_block(Meta *free_block);
