#include "my_malloc.h"
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <stdint.h>
Meta * head_free = NULL; // the head free block, (can at any place of the data segement) doubly linked list
Meta * head = NULL; // head of all blocks, the list of all blocks are ordered in decreasing address, doubly linked


// This function is for debugging. It prints all meta information of a block
void printMeta(Meta *block) {
    printf("block = %p, size = %lu, free = %d, next_block = %p, prev_block = %p, next_free = %p, prev_free = %p\n",
            block, block->size, block->free, block->next_block, block->prev_block, block->next_free, block->prev_free);
}


// This function is for debugging. It prints all blocks in the list of all blocks
void printAllBlocks() {
    printf("The list of all blocks\n");
    Meta *block = head;
    size_t index = 0;
    while (block != NULL) {
        printf("%lu ", index);
        printMeta(block); 
        block = block->next_block;
        index++;
    }
    printf("\n");
}

// This function is for debugging. It prints all blocks in the list of all blocks
void printAllFreeBlocks() {
    printf("The list of all free blocks\n");
    Meta *block = head_free;
    size_t index = 0;
    while (block != NULL) {
        printf("%lu ", index);
        printMeta(block); 
        block = block->next_free;
        index++;
    }
    printf("\n");
}

// This is function for debug
// inorder track if the block is in order with respect
// to next block and previous block in order of address
// i.e. prev_block > block > next_block
void inorder(Meta *block) {
    if (block == NULL) {
        return; 
    }
    if (block->prev_block != NULL) {
        assert(block->prev_block > block); 
    } 
    if (block->next_block != NULL) {
        assert(block->next_block < block); 
    }
}

// This function checks if the pointer does points to a valid block
// return the position of the block in the list
// if not in the list return -1
long inlist(Meta * block) {
    Meta * b = head;
    long index = 0;
    while (b != NULL) {
         if (b == block) {
            return index;          
         }
         b = b->next_block;
         index++;
    } 
    return -1;
}

// This function checks if the pointer does points to a free block
// return the position of the block in the free list
// if not in the free list return -1
long infreelist(Meta * block) {
    Meta * b = head_free;
    long index = 0;
    while (b != NULL) {
         if (b == block) {
            return index;          
         }
         b = b->next_free;
         index++;
    } 
    return -1;
}
size_t numblocks() {
    const Meta * block = head;
    size_t num = 0;
    while (block != NULL) {
        num++;
        assert(block != block->next_block);
        block = block->next_block; 
    }
    return num;
}

size_t numfreeblocks() {
    const Meta * block = head_free;
    size_t num = 0;
    while (block != NULL) {
        num++;
        assert(block != block->next_free);
        block = block->next_free; 
    }
    return num;
}

// check for continuity of addresses, return the
// index of the first block that violates continuity. 
// if no such block return -1
long iscontinous() {
    Meta *block = head;
    Meta *prev = NULL;
    while (block != NULL) {
        prev = block;
        block = block->next_block;
    }
    long index = 0;
    while (prev != NULL) {
        if (prev->prev_block != NULL && (char*)prev + META_SIZE + prev->size != (char *) prev->prev_block) {
            return index; 
        }
        prev = prev->prev_block; 
        index++;
    }
    return -1;
}

// check if all elements in the free list is free
// return the index of the element that's not free
// if all free return -1
long allfree() {
    Meta *block = head_free;
    long index = 0;
    while (block != NULL) {
        if (block->free != 1) {
            return index; 
        }
        block = block->next_free;
        index++; 
    }
    return -1;
}

// This function checks if all blocks are inorder
void allinorder() {
    Meta * block = head;
    while (block != NULL) {
        if (block->next_block != NULL) {
            assert(block > block->next_block);
        }
        block = block->next_block;
    }
}

void * ff_malloc(size_t size) {
    return mymalloc(size, findFirst);
}

void * bf_malloc(size_t size) {
    return mymalloc(size, findBest);
}

void *mymalloc(size_t size, search_t findFree) {
    // return the pointer to the first fit block
    Meta * block = findFree(size);
    if (block == NULL) { // if no fitting block
        // request more memory at the top to load the required size.
        block = requestMemory(size);
        if (block == NULL) {
            return block; 
        }
    } else {
        assert(block->free == 1); // ensure the block returned is free
        // change the first part of the block to be allocated
        // rest new free block.
        splitFree(block, size);
    }
    // the returned pointer start at the payload
    return block + 1;
}

// This function add a block to the list of all blocks. The function takes in three argument
// the block previous to this block, the block, and the next block
void addBlock(Meta *pBlock, Meta *block, Meta *nBlock) {
    block->prev_block = pBlock;
    block->next_block = nBlock;
    if (pBlock != NULL) {
        pBlock->next_block = block; 
    } else {
        head = block; 
    }
    if (nBlock != NULL) {
        nBlock->prev_block = block;
    }
}

// This function test if this block and the previous block is adjacent in address
int isadjacent(Meta *this, Meta *prev) {
    return (Meta *) ((char *)(this+1)+this->size) == prev; 
}

// TODO: I could change the data structure for free list to Red-Black tree. Just need
// to change addFree and rmFree implmentation


// request enough memory at the top of the data segment to load payload of indicated
// size. If there are some free spaces at the top, extend those free space until payload
// can fit in. return pointer to the allocated block.
Meta *requestMemory(size_t size) {
    Meta *block;
    void *ptr;
    // if the head_block is free, merge the head 
    // with the newly allocated space 
    // remove it from the free list
    /*
    if (head != NULL && head->free) {
        block = head; 
        rmFree(block);
        ptr = sbrk(size- head->size);
        if (ptr == (void *) -1) {
            return NULL; 
        }
    } else {
    */
        // block start after the old top of data segment
        block = sbrk(size+ META_SIZE); 
        if (block == (void*) -1) {
            return NULL; 
        }
        // Since the block is at the top, there's no previous block
        // the next block should be the original head block
        addBlock(NULL, block, head);
        block->free = 0; // The block has been allocated
    /*}*/
    // Make this new memory the required data block
    block->size = size;
    return block;
}

// Allocate block of desired size in the free block. i.e. make
// the start of the free block the allocated block. The rest unoccupied
// region a new free block (Corner case. if the rest region is not large
// enough for storing meta data for free block. Give all space to the
// allocated block) The size is payload size.
void splitFree(Meta *free_block, size_t size) {
    // This block is no longer free so we need to remove it from the free list
    rmFree(free_block); // TODO: must allocate the correct size.
    // since no new block has been created, next_block don't have to be updated
    size_t rest_space = free_block->size - size; // calulate the remaining space if we split space
    // if the rest of free space is large enough to store Meta data
    if (rest_space > META_SIZE) { // TODO: change to > just Meta data is useless
        // create the free block
        // change the size to allocated block
        free_block->size = size;
        // The meta data of the new free block is
        // the free_block moved by its size bytes
        Meta *new_free = (Meta *)((char *)(free_block+1) + size); //casting to char is to ensure moving by bytes
        new_free->size = rest_space - META_SIZE;
        // because the new_free is part of the original free_block, it has higher address.
        // so free_block is the next after the new_free. It's original previous, is now the previous
        // of new_free
        addBlock(free_block->prev_block, new_free, free_block);
        // A new block is created we make it a free block
        addFree(new_free); 
    }
}

void addFree(Meta * block) {
    // first turn the block to a free block
    block->free = 1; 
    // connect the block to the current head
    block->next_free = head_free;
    block->prev_free = NULL;
    // The list is none empty 
    if (head_free != NULL) {
        // update the head of the free list
        head_free->prev_free = block;
    }
    head_free = block;
}

void rmFree(Meta *free_block) {
    // first turn the block to be not free
    free_block->free = 0;
    if (free_block->prev_free != NULL) {
        // update the previous free block
        free_block->prev_free->next_free = free_block->next_free; 
    } else { // if it's the head, update head of free blocks
        head_free = free_block->next_free; 
    } 
    if (free_block->next_free != NULL) {
        // update the next free block
        free_block->next_free->prev_free = free_block->prev_free;
    }
}

Meta * findFirst(size_t size) {
    Meta * block = head_free;
    while (block != NULL) {
        if (block->size >= size) {
            return block; 
        } 
        block = block->next_free;
    }
    return NULL;
}


// Find the best free block that can hold a payload of given size
// If such block doesn't exist return NULL
Meta * findBest(size_t size) {
    Meta *block = head_free;
    size_t minFitSize = SIZE_MAX; // the minimum size start with infinity
    Meta *bestBlock = NULL;
    while (block != NULL)  {
        if (block->size == size) {
            return block; 
        }
        if (block->size > size && block->size < minFitSize) { // update if this block is qualified and better
            minFitSize = block->size;
            bestBlock = block; 
        } 
        block = block->next_free;
    }
    return bestBlock;
}

void ff_free(void *ptr) {
    myfree(ptr);
}

void bf_free(void *ptr) {
    myfree(ptr);
}

void myfree(void *ptr) {
    if (ptr == NULL) { // free a NULL pointer do nothing
        return;
    }
    // move from payload to meta data
    Meta * block = (Meta *) ptr -1;
    if (block->free) {
        return; // really, double freeing is problematic. But we will do nothing 
    }
    // add this block to the free list
    addFree(block);
    // determine if the previous block is free
    if (block->prev_block != NULL && block->prev_block->free && isadjacent(block, block->prev_block)) {
        // try merge with the previous block
        // remove previous block from the free list
        rmFree(block->prev_block);
        mergePrev(block);
    }
    // if the next block is free, merge with this block
    if (block->next_block != NULL && block->next_block->free && isadjacent(block->next_block, block)) {
        // remove this block from the free list
        rmFree(block);
        mergePrev(block->next_block); 
    }
}

void mergePrev(Meta * block) {
    // the block extends to this block
    block->size += META_SIZE + block->prev_block->size;
    if (block->prev_block->prev_block != NULL) {
        block->prev_block->prev_block->next_block = block; 
    } else {
        head = block; 
    }
    block->prev_block = block->prev_block->prev_block;
}


// TODO: Check free list. If a free block is double listed in free list
// get the total size of all blocks (including Meta data) in the iterable
unsigned long get_size(Meta *begin, iterator_t next) {
    size_t total = 0;
    Meta *block = begin;
    while (block != NULL) {
        total += block->size+META_SIZE; 
        block = next(block); // go to the next block
    }  
    return total;
}

// return the pointer to the next block
Meta *get_next_block(Meta *block) {
    return block->next_block;
}

// return the pointer to the next free block, given a pointer to free block
Meta *get_next_free_block(Meta *free_block) {
    return free_block->next_free;
}

// return the totall size of all blocks (including meta data) in bytes
unsigned long get_data_segment_size() {
    return get_size(head, get_next_block);
}

// return the totall size of all free_spaces (including meta data) in bytes
unsigned long get_data_segment_free_space_size() {
    return get_size(head_free, get_next_free_block);
}
