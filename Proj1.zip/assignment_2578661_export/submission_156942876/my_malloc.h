#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Block {
  size_t size;
  struct Block * prev_block;
  struct Block * next_block;
} Block_t;

// Helper Functions
Block_t * search_existing_block(size_t size);
Block_t * search_min_block(size_t size);
void append_new_block(Block_t * ori_block, Block_t * new_block);
void remove_existing_block(Block_t * block);
void * allocate_new_block(size_t size);
void * use_existing_block(Block_t * block, size_t size);
void combine_right_block(Block_t * block);
void combine_left_block(Block_t * block);
void free(void * ptr);

// First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

// Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
