#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "assert.h"

#define BLOCK_T_SIZE sizeof(Block_t)

// Track the head and tail of linked list of free blocks
Block_t * head_block = NULL;
Block_t * tail_block = NULL;

// Track the data segment spaces
size_t seg_size = 0;
size_t seg_free_space_size = 0;

Block_t * search_existing_block(size_t size) {
  Block_t * cur_block = head_block;
  while (cur_block != NULL) {
    if (cur_block->size >= size) {
      return cur_block;
    }
    cur_block = cur_block->next_block;
  }
  return cur_block;
}

Block_t * search_min_block(size_t size) {
  Block_t * min_block = NULL;
  Block_t * cur_block = head_block;
  while (cur_block != NULL) {
    if (cur_block->size >= size) {
      if (min_block == NULL || cur_block->size < min_block->size) {
        min_block = cur_block;
      }
      // Early stopping if there is a perfect match
      if (cur_block->size == size) {
        return cur_block;
      }
    }
    cur_block = cur_block->next_block;
  }
  return min_block;
}

void append_new_block(Block_t * ori_block, Block_t * new_block) {
  if (head_block == NULL && tail_block == NULL) {
    new_block->prev_block = NULL;
    new_block->next_block = NULL;
    head_block = new_block;
    tail_block = new_block;
  }
  else if (ori_block == tail_block) {
    new_block->next_block = NULL;
    new_block->prev_block = tail_block;
    tail_block->next_block = new_block;
    tail_block = new_block;
  }
  else {
    new_block->prev_block = ori_block;
    new_block->next_block = ori_block->next_block;
    ori_block->next_block = new_block;
    new_block->next_block->prev_block = new_block;
  }
}

void remove_existing_block(Block_t * block) {
  if (head_block == block && tail_block == block) {
    head_block = NULL;
    tail_block = NULL;
  }
  else if (head_block == block) {
    head_block = block->next_block;
    head_block->prev_block = NULL;
  }
  else if (tail_block == block) {
    tail_block = block->prev_block;
    tail_block->next_block = NULL;
  }
  else {
    block->next_block->prev_block = block->prev_block;
    block->prev_block->next_block = block->next_block;
  }
  block->prev_block = NULL;
  block->next_block = NULL;
}

void * allocate_new_block(size_t size) {
  Block_t * new_block = sbrk(size + BLOCK_T_SIZE);
  // When sbrk returns an error, i.e. (void *) -1, return NULL
  if ((void *)new_block == (void *)-1) {
    return NULL;
  }
  new_block->size = size;
  new_block->prev_block = NULL;
  new_block->next_block = NULL;
  seg_size += (size + BLOCK_T_SIZE);
  return (char *)new_block + BLOCK_T_SIZE;
}

void * use_existing_block(Block_t * block, size_t size) {
  if (block->size >= size + BLOCK_T_SIZE) {
    Block_t * new_block = (Block_t *)((char *)block + size + BLOCK_T_SIZE);
    new_block->size = block->size - size - BLOCK_T_SIZE;
    block->size = size;
    append_new_block(block, new_block);
    remove_existing_block(block);
    seg_free_space_size -= (size + BLOCK_T_SIZE);
  }
  else {
    remove_existing_block(block);
    seg_free_space_size -= (block->size + BLOCK_T_SIZE);
  }
  return (char *)block + BLOCK_T_SIZE;
}

// If possible, merge with the right free block into a single free block
void combine_right_block(Block_t * block) {
  if (block->next_block != NULL &&
      (char *)block + block->size + BLOCK_T_SIZE == (char *)block->next_block) {
    block->size += (block->next_block->size + BLOCK_T_SIZE);
    remove_existing_block(block->next_block);
  }
}

// If possible, merge with the left free block into a single free block
void combine_left_block(Block_t * block) {
  if (block->prev_block != NULL &&
      (char *)block == (char *)block->prev_block + block->prev_block->size + BLOCK_T_SIZE) {
    block->prev_block->size += (block->size + BLOCK_T_SIZE);
    remove_existing_block(block);
  }
}

void free(void * ptr) {
  if (ptr == NULL) {
    return;
  }
  Block_t * freed_block = (Block_t *)((char *)ptr - BLOCK_T_SIZE);
  seg_free_space_size += (freed_block->size + BLOCK_T_SIZE);
  if (head_block == NULL && tail_block == NULL) {
    freed_block->prev_block = NULL;
    freed_block->next_block = NULL;
    head_block = freed_block;
    tail_block = freed_block;
  }
  else if (freed_block < head_block) {
    freed_block->prev_block = NULL;
    freed_block->next_block = head_block;
    head_block->prev_block = freed_block;
    head_block = freed_block;
    combine_right_block(freed_block);
  }
  else if (freed_block > tail_block) {
    freed_block->next_block = NULL;
    freed_block->prev_block = tail_block;
    tail_block->next_block = freed_block;
    tail_block = freed_block;
    combine_left_block(freed_block);
  }
  else {
    Block_t * cur_block = head_block;
    while (freed_block > cur_block) {
      cur_block = cur_block->next_block;
    }
    append_new_block(cur_block->prev_block, freed_block);
    combine_right_block(freed_block);
    combine_left_block(freed_block);
  }
}

void * ff_malloc(size_t size) {
  Block_t * malloc_block = search_existing_block(size);
  if (malloc_block == NULL) {
    return allocate_new_block(size);
  }
  else {
    return use_existing_block(malloc_block, size);
  }
}

void ff_free(void * ptr) {
  free(ptr);
}

void * bf_malloc(size_t size) {
  Block_t * min_block = search_min_block(size);
  if (min_block == NULL) {
    return allocate_new_block(size);
  }
  else {
    return use_existing_block(min_block, size);
  }
}

void bf_free(void * ptr) {
  free(ptr);
}

unsigned long get_data_segment_size() {
  return seg_size;
}

unsigned long get_data_segment_free_space_size() {
  return seg_free_space_size;
}
