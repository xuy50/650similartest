#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include<limits.h>
#include<assert.h>

// data structure tracked free blocks
struct block_t{
    size_t size;
    struct block_t * next;
};
typedef struct block_t block;

// first fit malloc/free function
void * ff_malloc(size_t size);
void ff_free(void *ptr);

// best fit malloc/free function
void * bf_malloc(size_t size);
void bf_free(void *ptr);

// functions used for capturing fragmentation
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

// helper functions
void splitFreeBlock(block * pre, block * curr, size_t size);
void removeBlock(block * pre, block * b);
void addBlock(block * pre, block * b);
void addnewBlock(block * b);
void * requestSpace(size_t size);
void printFreeList();
block * findPreptr(block * b);
void mergeRight(block * b);
