#include "my_malloc.h"

/* Initialize head of the linkedlist of free blocks, used memory and free memory in heap. */
block * head = NULL;
unsigned long used_segment = 0;
unsigned long free_segment = 0;

/* Reduce a free block to a smaller one and update free-block linked list. */
void splitFreeBlock(block * pre, block * curr, size_t size){
    block * new = (block *)((char *)curr + size + sizeof(block));
    new->size = curr->size - size - sizeof(block);
    // printf("current address: %p,current block size :%zu,new block address:%p, new block size:%zu, current block 
    // address + size + metasize: %p\n", curr,curr->size,new,new->size,curr+sizeof(block)+size);
    removeBlock(pre, curr);
    curr->size = size;
    addBlock(pre, new);
}

/* Remove block b from the free-block linked list. block * pre points at the previous item */
void removeBlock(block * pre, block * b){
    free_segment = free_segment - b->size - sizeof(block);
    if (head == b){
        head = b->next;
        b->next = NULL;
    }else{
        pre->next = b->next;
        b->next = NULL;
    }
}

/* Add block b to the free-block linked list. */
void addBlock(block * pre, block * b){
    free_segment = free_segment + b->size + sizeof(block);
    if(pre == NULL){
        head = b;
        b->next = NULL;
    }else{
        b->next = pre->next;
        pre->next = b;
    }
}

/* Add block b to the free-block linked list in the relative position in the heap and merge adjacent free blocks. */
void addnewBlock(block * b){
    free_segment = free_segment + b->size + sizeof(block);
    if(head == NULL){
        head = b;
        b->next = NULL;
    }else{
        if (b < head){
            b->next = head;
            head = b;
            mergeRight(b);
            return;
        }
        block * curr = head;
        block * prev = head;
        while (curr->next != NULL && b > curr->next ){
            prev = curr;
            curr = curr->next;
            assert(curr == prev->next);
        }
        b->next = curr->next;
        curr->next = b;
        if(curr->next == NULL){
            mergeRight(prev);
        }else{
            mergeRight(prev);
            mergeRight(prev);
        }
    }
}

/* Request new space when there is not enough space for allocation. */
void * requestSpace(size_t size){
  block * newBlock = sbrk(size + sizeof(block));
    if(newBlock != (void *) - 1){
        newBlock->size = size;
        used_segment =  used_segment + size + sizeof(block);
        //printf("new allocated space--curr address: %p, size: %zu, new space address + size + sizeof(meta):%p\n",
        //newBlock, size,(char*) newBlock+size+sizeof(block));
        return (char*)newBlock + sizeof(block);
    }else{
        return NULL;
    }
}

/* Merge b and b->next */
void mergeRight(block * b){
    if((char*)b + b->size + sizeof(block) == (char*)b->next){
            b->size +=  b->next->size + sizeof(block); 
            block * temp = b->next->next;        
            b->next->next = NULL;
            b->next = temp;
    }
}

/* First fit malloc function */
void * ff_malloc(size_t size){     
    block * curr = head;
    block * preptr = NULL;
    while(curr != NULL){
        if (curr->size > size + sizeof(block)){
            splitFreeBlock(preptr, curr, size);
            return (char *)curr + sizeof(block); 
        }else if(curr->size >= size && curr->size <= (size + sizeof(block))){
            removeBlock(preptr, curr);
            return (char *)curr + sizeof(block); 
        }
        preptr = curr;
        curr = curr->next;
    }
    return requestSpace(size);
}

/* First fit free function */
void ff_free(void * ptr) {
    if(ptr == NULL){
    return;
    }
    block * newFreed = (block *)((char *)ptr - sizeof(block));
    addnewBlock(newFreed);  
}

/* Best fit malloc function */
void * bf_malloc(size_t size){
    block * curr = head;
    size_t minSize = INT_MAX; 
    void * bf = NULL;
    void * preptr = NULL;
    while(curr != NULL){
        if (curr->size > size + sizeof(block)){
            if(curr->size < minSize){      // upate best fit free block
                minSize = curr->size;
                bf = curr;
            }
        }else if(curr->size >= size && curr->size < size + sizeof(block)){
            removeBlock(preptr, curr);
            return (char *)curr + sizeof(block); 
        }
        preptr = curr;
        curr = curr->next;
    }
    if (minSize == INT_MAX){
        return requestSpace(size);
    }else{
        block * prebf = findPreptr(bf);
        splitFreeBlock(prebf, bf, size);
        return (char *)bf + sizeof(block); 
    }
}

/* Find the previous block of b */
block * findPreptr(block * b){
    if (b == head){
        return NULL;
    }
    block * curr = head;
    while(curr->next != NULL){
        if(curr->next == b){
            return curr;
        }
        curr = curr->next;
    }
}

/* Best fit free function */
void bf_free(void * ptr){
    ff_free(ptr);
}

/* functions used for getting the whole allocation size */
unsigned long get_data_segment_size(){
    return used_segment;
}

/* functions used for getting free segment size */
unsigned long get_data_segment_free_space_size(){
    return free_segment;
}
                                    
/* print free-block linkedlist */
void printFreeList(){
    block * curr = head;
    while(curr != NULL){
        printf("curr address : %p, curr size:%ld\n",curr, curr->size);
        curr = curr->next;
    }
}
