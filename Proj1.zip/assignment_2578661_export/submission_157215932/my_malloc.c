#include "my_malloc.h"

block_t * head = NULL;

void init() {
  void * temp = NULL;
  temp = sbrk(sizeof(block_t));
  // get a head block which contains only info, no data
  if (temp != (void *)-1) {
    // want it to be a dummy head;
    head = temp;
    head->size = sizeof(block_t);
    head->pre = NULL;
    head->next = NULL;
  }
  // what to do if fails?????
}

void remove_block(block_t * curr) {
  curr->pre->next = curr->next;
  if (curr->next != NULL) {
    curr->next->pre = curr->pre;
  }
  curr->pre = NULL;
  curr->next = NULL;
}

void deal_remain(block_t * curr, size_t size) {
  size_t remain_free = curr->size - (size + sizeof(block_t));
  // need to confirm!!!!!!!
  // if remain still has enough free space to add to free link list
  if (remain_free > sizeof(block_t)) {
    // remain metadata
    block_t * remain = (block_t *)((char *)curr + (size + sizeof(block_t)));
    remain->size = remain_free;
    // add to free list
    remain->next = curr->next;
    remain->pre = curr->pre;

    curr->pre->next = remain;
    // maybe reduce this by adding dummy tail???
    if (curr->next != NULL) {
      curr->next->pre = remain;
    }
    curr->size = size + sizeof(block_t);
    curr->pre = NULL;
    curr->next = NULL;
  }
  // ==
  else {
    // can abstract!!!!!!
    remove_block(curr);
  }
  // else do not keep track of the remaining free space!
}

block_t * sbrk_space(size_t size) {
  block_t * ptr = sbrk(size + sizeof(block_t));
  if (ptr == (void *)(-1)) {
    return NULL;
  }

  // new space, allocated
  ((block_t *)ptr)->size = size + sizeof(block_t);
  ((block_t *)ptr)->pre = NULL;
  ((block_t *)ptr)->next = NULL;

  return ptr;
}

void * ff_malloc(size_t size) {
  if (head == NULL) {
    init();
  }
  block_t * curr = head->next;
  // whether we can find a
  int find = 0;
  void * ptr = NULL;
  while (curr != NULL) {
    // find the first fit free block
    if (curr->size >= size + sizeof(block_t)) {
      if (curr->size > size + sizeof(block_t)) {
        deal_remain(curr, size);
      }
      else {
        remove_block(curr);
      }
      ptr = curr;
      find = 1;
      break;
    }
    curr = curr->next;
  }

  // cannot find fit, sbrk new space
  if (!find) {
    ptr = sbrk_space(size);
  }

  return (void *)((char *)ptr + (sizeof(block_t)));
}

void remove_metadata(block_t * b) {
  b->pre = NULL;
  b->next = NULL;
}

void ff_free(void * ptr) {
  if (ptr == NULL) {
    return;
  }
  block_t * block_addr = (block_t *)((char *)ptr - sizeof(block_t));

  // get next block
  block_t * block_next = (block_t *)((char *)block_addr + block_addr->size);

  // get pre free block
  block_t * block_pre_free = head;

  while (block_pre_free->next != NULL) {
    if (block_pre_free < block_addr && block_pre_free->next > block_addr) {
      break;
    }
    block_pre_free = block_pre_free->next;
  }

  // if next not the top of the heap??? and is free
  int nf = (block_next != sbrk(0)) && (block_next->pre != NULL);
  // if pre free block is not the head and is adjacent
  int pf = (block_pre_free != head) &&
           (((block_t *)((char *)block_pre_free + block_pre_free->size)) == block_addr);

  // pre and next are both free
  if (nf && pf) {
    // pre block need to expand
    block_pre_free->size += block_addr->size + block_next->size;
    block_pre_free->next = block_next->next;

    if (block_pre_free->next != NULL) {
      block_pre_free->next->pre = block_pre_free;
    }
    // other 2 blocks need to remove metadata
    remove_metadata(block_addr);
    remove_metadata(block_next);
    /*
    block_addr->pre = NULL;
    block_addr->next = NULL;
    block_next->pre = NULL;
    block_next->next = NULL;
    */
  }
  // next is free
  else if (nf) {
    // curr block nees to expand
    block_addr->size += block_next->size;
    block_addr->next = block_next->next;
    block_addr->pre = block_next->pre;
    block_next->pre->next = block_addr;
    if (block_next->next != NULL) {
      block_next->next->pre = block_addr;
    }
    // remove metadata
    remove_metadata(block_next);
    /*
    block_next->pre = NULL;
    block_next->next = NULL;
    */
  }
  // pre is free
  else if (pf) {
    // pre block needs to expand
    block_pre_free->size += block_addr->size;
  }
  // none is free
  else {
    // change curr
    block_addr->pre = block_pre_free;
    block_addr->next = block_pre_free->next;
    // change pre
    if (block_pre_free->next != NULL) {
      block_pre_free->next->pre = block_addr;
    }
    block_pre_free->next = block_addr;
  }
}

void * bf_malloc(size_t size) {
  if (head == NULL) {
    init();
  }
  block_t * curr = head->next;
  // whether we can find a best fit block
  void * ptr = NULL;
  size_t min_diff = SIZE_MAX;
  void * min_diff_p = NULL;
  while (curr != NULL) {
    // find the best fit free block
    if (curr->size >= size + sizeof(block_t)) {
      if (curr->size - (size + sizeof(block_t)) < min_diff) {
        min_diff = curr->size - (size + sizeof(block_t));
        min_diff_p = curr;
      }
      if (min_diff == 0) {
        break;
      }
    }
    curr = curr->next;
  }

  // assign free block
  if (min_diff_p != NULL) {
    if (min_diff != 0) {
      deal_remain(min_diff_p, size);
    }
    else {
      // can abstract!!!!!!
      remove_block(min_diff_p);
    }
    // change curr
    // curr->pre = NULL;
    // curr->next = NULL;

    ptr = min_diff_p;
  }
  // cannot find fit, sbrk new space
  else {
    ptr = sbrk_space(size);
  }

  return (void *)((char *)ptr + (sizeof(block_t)));
}

void bf_free(void * ptr) {
  ff_free(ptr);
}

// entire heap memory (in bytes)
unsigned long get_data_segment_size() {
  return (unsigned long)((char *)sbrk(0) - (char *)head);
}

// size of the "free list" = (actual
// usable free space + space occupied by metadata) of the blocks in your
// free list (in bytes)
unsigned long get_data_segment_free_space_size() {
  block_t * temp = head->next;
  unsigned long ans = 0;
  while (temp != NULL) {
    ans += temp->size;
    temp = temp->next;
    // printf("%lu\n", ans);
  }
  return ans;
}
