#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct block {
  size_t size;
  struct block * pre;
  struct block * next;
} block_t;

// First Fit malloc/free
void init();
void remove_block(block_t * curr);
void deal_remain(block_t * curr, size_t size);
block_t * sbrk_space(size_t size);
void remove_metadata(block_t * b);
void * ff_malloc(size_t size);
void ff_free(void * ptr);

// Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

// entire heap memory
unsigned long get_data_segment_size();  //in bytes

// size of the "free list" = (actual
// usable free space + space occupied by metadata) of the blocks in your
// free list
unsigned long get_data_segment_free_space_size();  //in byte
