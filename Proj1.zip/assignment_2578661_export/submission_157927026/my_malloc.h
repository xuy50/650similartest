//
// Created by taylor on 1/24/23.
//
#ifndef CLION_PRJ1_MALLOC_H
#define CLION_PRJ1_MALLOC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef long long boundary_aligner;

union node{
    struct {
        union node *next;
        size_t size;
    } n;
    boundary_aligner x;
};typedef union node Node;

//struct node{
//    struct node *next;
//    size_t size;
//}; typedef struct node Node;


void *ff_malloc(size_t size);
void ff_free(void *ptr);

static Node *get_more_memory(size_t n_bytes);

////Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//// Performance Study Report Functions
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

//#endif //PRJ1_MY_MALLOC_H
#endif //CLION_PRJ1_MALLOC_H
