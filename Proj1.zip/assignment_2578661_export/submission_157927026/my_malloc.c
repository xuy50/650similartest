#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#include "my_malloc.h"

static Node head;
static Node *head_ptr = NULL; // need this, and it's address is the start of the memory segment.
static size_t free_list_size = 1;
int first_call_to_malloc = 0;
size_t node_size = sizeof(Node);
size_t allocation_tracker = 0;

void check_condition_one(Node *current, Node *node_to_free, int *condition_match){
    //case1: node_to_free occurs between the current node and current->n.next node.
    if(node_to_free > current){
        if(node_to_free < current->n.next){
            *condition_match = 1;
        }
    }
}

void check_condition_two(Node *current, Node *node_to_free, int *condition_match){
    //case2: node_to_free occurs after the current node, and after the current->n.next node, AND the current->n.next
    // node occurs before the current node: (i.e. current->n.next wraps around to the begining of the list)
    if(current > current->n.next){
        if(node_to_free > current){
            *condition_match = 1;
        }
    }
}

void check_condition_three(Node *current, Node *node_to_free, int *condition_match){
    //case3: node_to_free occurs before the current node and the current->n.next node, and current->n.next also occurs
    // before the current node: (i.e. current->n.next wraps around to the begining of the list)
    if(current > current->n.next){
        if(node_to_free < current->n.next){
            *condition_match = 1;
        }
    }
}

void check_condition_four(Node *current, Node *node_to_free, int *condition_match){
    //case4: node_to_free occurs after the current node, and the current node is the only node on the free list.
    // Note: This also takes care of the case where there are no fee nodes; because we have an "empty" head node
    if(current == current->n.next){
        if(node_to_free > current){
            *condition_match = 1;
        }
    }
}

void check_condition_five(Node *current, Node *node_to_free, int *condition_match){
    //case5: node_to_free occurs before the current node; and the current node is the only node on the free list
    if(current == current->n.next){
        if(node_to_free < current->n.next){
            *condition_match = 1;
        }
    }
}

void check_condition_six(Node *current, Node *node_to_free, int *already_free){
    //check the case that the node supplied is already free
    if(current == node_to_free){
        *already_free = 1;
    }
}

void ff_free(void *ptr){
    Node *current = head_ptr;
    Node *node_to_free = (Node *)ptr - 1;
    int already_free = 0;    // NTF is already free

    // Position the current node pointer to the correct spot (immediately before/after the node_to_free)
    int condition_match = 0;
    int free_nodes_looked_at = 0;
    while(condition_match==0){// if any condition matches exit the loop
        //  this         and              this, are not neccesarrily the head and end nodes
        //   v                             v
        check_condition_one(current, node_to_free, &condition_match);    // [...][CUR][...][NTF][...][C>N][...]
        check_condition_two(current, node_to_free, &condition_match);    // [...][C>N][...][CUR][...][NTF][...]
        check_condition_three(current, node_to_free, &condition_match);  // [NTF][C>N][...][CUR][...][...][...]
        check_condition_four(current, node_to_free, &condition_match);   // [...][CUR][...][...][NTF][...][...]
        check_condition_five(current, node_to_free, &condition_match);   // [NTF][...][...][CUR][...][...][...]
        check_condition_six(current, node_to_free, &already_free);
        if(already_free==1){
            already_free = 2; // this line is used as a breakpoint for catching double free's during debuggins
            //printf("Node: %zu is already free.\n", (size_t) node_to_free);
            return;
        }
        if(condition_match == 0) {
            current = current->n.next;
        }
    }

    size_t free_list_size_change = 1;

    //join to upper nbr
    if(node_to_free + node_to_free->n.size == current->n.next ){
        node_to_free->n.size +=current->n.next->n.size + 1;
        node_to_free->n.next = current->n.next->n.next;
        free_list_size_change --;
    }else{
        node_to_free->n.next = current->n.next;
    }

    //join to lower nbr
    if(current + current->n.size == node_to_free){
        current->n.size += node_to_free->n.size + 1;
        current->n.next = node_to_free->n.next;
        free_list_size_change --;
    }else{
        current->n.next = node_to_free;
    }
    free_list_size += free_list_size_change;
    head_ptr = current;
}

void first_call_to_malloc_protocol_checks(){
    if(head_ptr == NULL){
        head.n.next = &head;
        head.n.size = 0;
        head_ptr = &head;
        free_list_size = 1;
    }

//    if(first_call_to_malloc==0){
//        start_of_heap = head_ptr;
//        first_call_to_malloc = 1;
//    }
}

static Node *get_more_memory(size_t n_nodes){
    Node *new_node = sbrk(n_nodes * node_size);
    allocation_tracker += n_nodes;

    if(new_node==(Node *) -1){ //if sbrk return's a -1 that indicates an error where the requested amount of memmory is not avaialble at the moment
        printf("malloc: More process memory is not available right now.\n");
        return NULL;
    }
    new_node->n.size = (n_nodes - 1);//(n_nodes - 1); //(n_nodes * node_size - node_size)/node_size; // set the size of the new node; we can't set the next node yet (it doesn't exist).
    ff_free((void *)(new_node+1));
    return head_ptr;
}

void *exact_fit_node(Node *previous, Node *current){
    previous->n.next = current->n.next; // this removes the current node from the free list, and causes the previous_current node's next to point at the free block after current
    free_list_size--;
    return (void *) (current + 1);
}

void *split_fit_node(Node *current, size_t num_new_nodes){
    Node *temp = current;
    current->n.size -= num_new_nodes;  // reduce the current node's size by the amount needed
    current += current->n.size;        // jump to the new node that was created at the tail ned
    current->n.size = (num_new_nodes-1);
    current->n.next = temp->n.next;      // set the next pointer of the newly created node.
    return (void *)(current + 1);
}

Node *remove_node_from_free_list(Node *current, Node *previous, size_t num_new_nodes){
    if(current->n.size == (num_new_nodes-1)) {
        current = exact_fit_node(previous, current);
    }else{
        current = split_fit_node(current, num_new_nodes);
    }
    head_ptr = previous;
    return current;
}

void *add_new_node(Node *previous, size_t num_new_nodes){
    Node *current = get_more_memory(num_new_nodes);
    if(current == NULL){
        return NULL;
    }
    previous = current;
    current = current->n.next;

    current = remove_node_from_free_list(current, previous, num_new_nodes); // remove the node from the free-list since we are going to use it
    return current;
}

void *ff_malloc(size_t size){
    first_call_to_malloc_protocol_checks();

    size_t num_new_nodes = (size + node_size - 1) / node_size + 1;

    Node *previous = head_ptr;
    Node *current = previous->n.next;
    while(1){
        if(current->n.size >= (num_new_nodes-1)) {
            current = remove_node_from_free_list(current, previous, num_new_nodes);
            return current;
        }
        // If we have done a complete circle around the list and not found anything, get more memory
        if(current->n.next == head_ptr) {
            break;
        }
        previous = current;
        current = current->n.next;
    }
    return add_new_node(previous, num_new_nodes);
}


/////////////////////////////////////////////////////////////////
void bf_free(void *ptr){
    ff_free(ptr);
}

void *bf_malloc(size_t size){

    first_call_to_malloc_protocol_checks();

    size_t num_new_nodes = (size + node_size - 1) / node_size + 1;

    Node *previous = head_ptr;
    Node *current = previous->n.next;

    Node *bestfit = NULL;
    size_t best_fit_distance_from_exact = INT_MAX;
    size_t size_difference = 0;
    while(1){
        if(current->n.size >= (num_new_nodes-1)){
            size_difference = current->n.size - (num_new_nodes - 1);
            if(size_difference <= best_fit_distance_from_exact){
                bestfit = current;
                best_fit_distance_from_exact = size_difference;
            }
            //if we found an exact fit use it
            if(current->n.size == (num_new_nodes-1)) {
                current = exact_fit_node(previous, current);
                head_ptr = previous;
                return current;
            }
        }

        if(current->n.next == head_ptr){ // If we have done a complete scan of the list and not found anything, get more memory
            break;
        }

        previous = current;
        current=current->n.next;
    }

    if(bestfit != NULL){
        current = bestfit;
        head_ptr = previous;
        return split_fit_node(current, num_new_nodes);
    }

    return add_new_node(previous, num_new_nodes);
}
/////////////////////////////////////////////////////////////////
unsigned long get_data_segment_size(){
    unsigned long total_allocation = (allocation_tracker + 1) * node_size; //plus one for the header
    return total_allocation;
} //in bytes

unsigned long get_data_segment_free_space_size(){
    Node *current = head_ptr;
    unsigned long num_nodes = 0;
    while(1){
        num_nodes += current->n.size + 1;
        current = current->n.next;
        if(current == head_ptr){
            break;
        }
    }
    return num_nodes * node_size;
} //in byte
//
// Created by taylor on 1/28/23.
//
