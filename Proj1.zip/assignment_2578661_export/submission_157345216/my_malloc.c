#include "my_malloc.h"

// used to define a doubly linked list node
#define LIST_NODE_T(TYPE_)\
struct\
{\
    TYPE_ * prev;   \
    TYPE_ * next;   \
}

// used to define a doubly linked list
#define LIST_BASE_T(TYPE_)\
struct\
{\
    TYPE_ * start;  \
    TYPE_ * end;    \
}

// add to the start of the linked list
#define LIST_ADD_FIRST(LINK_, BASE_, N_)\
do\
{\
    ((N_)->LINK_).prev = NULL;\
    ((N_)->LINK_).next = (BASE_).start;\
    if ((BASE_).start != NULL)\
    {\
        (((BASE_).start)->LINK_).prev = (N_);\
    }\
    (BASE_).start = (N_);\
    if ((BASE_).end == NULL)\
    {\
        (BASE_).end = (N_);\
    }\
} while (0)

// add to the end of the linked list
#define LIST_ADD_LAST(LINK_, BASE_, N_)\
do\
{\
    ((N_)->LINK_).prev = (BASE_).end;\
    ((N_)->LINK_).next = NULL;\
    if ((BASE_).end != NULL)\
    {\
        (((BASE_).end)->LINK_).next = (N_);\
    }\
    (BASE_).end = (N_);\
    if ((BASE_).start == NULL)\
    {\
        (BASE_).start = (N_);\
    }\
} while (0)

// remove node
#define LIST_REMOVE(LINK_, BASE_, N_)\
do\
{\
    if (((N_)->LINK_).prev == NULL)\
    {\
        (BASE_).start = ((N_)->LINK_).next;\
    }\
    else\
    {\
        ((((N_)->LINK_).prev)->LINK_).next = ((N_)->LINK_).next;\
    }\
    if (((N_)->LINK_).next == NULL)\
    {\
        (BASE_).end = ((N_)->LINK_).prev;\
    }\
    else\
    {\
        ((((N_)->LINK_).next)->LINK_).prev = ((N_)->LINK_).prev;\
    }\
    ((N_)->LINK_).prev = NULL;\
    ((N_)->LINK_).next = NULL;\
} while (0)

// insert node before a node
#define LIST_INSERT_BEFORE(LINK_, BASE_, NODE_, N_)\
do\
{\
    (N_)->LINK_.prev = (NODE_)->LINK_.prev;\
    (N_)->LINK_.next = (NODE_);\
    if ((NODE_)->LINK_.prev != NULL)\
    {\
        ((NODE_)->LINK_.prev)->LINK_.next = (N_);\
    }\
    else\
    {\
        (BASE_).start = (N_);\
    }\
    (NODE_)->LINK_.prev = (N_);\
} while (0)

// insert node after a node
#define LIST_INSERT_AFTER(LINK_, BASE_, NODE_, N_)\
do\
{\
    (N_)->LINK_.prev = (NODE_);\
    (N_)->LINK_.next = (NODE_)->LINK_.next;\
    if ((NODE_)->LINK_.next != NULL)\
    {\
        ((NODE_)->LINK_.next)->LINK_.prev = (N_);\
    }\
    else\
    {\
        (BASE_).end = (N_);\
    }\
    (NODE_)->LINK_.next = (N_);\
} while (0)

// get the first node 
#define LIST_GET_FIRST(BASE_)   ((BASE_).start)

// get the last node
#define LIST_GET_LAST(BASE_)    ((BASE_).end)

// get the previous node
#define LIST_GET_PREV(LINK_, N_) (((N_)->LINK_).prev)

// get the next node
#define LIST_GET_NEXT(LINK_, N_) (((N_)->LINK_).next)


/*===========================================================*/

// memory block structure
#define MEM_BLK_FLAG_IS_FREE    0x01
#define MEM_BLK_FLAG_IS_USING   0x02
typedef struct mem_block_struct mem_block_t;
struct mem_block_struct
{
    size_t                      size;           // memory block size
    char                        flag;           // memory block flag
    LIST_NODE_T(mem_block_t)    link;           // memory block pointer 
    LIST_NODE_T(mem_block_t)    link_for_free;  // free memory block pointer
};
typedef LIST_BASE_T(mem_block_t)    mem_block_lst_t;

#define MEM_BLK_MIN_SIZE        (sizeof(mem_block_t) + sizeof(void*))
/*===========================================================*/
mem_block_lst_t mem_blocks_lst = { 0 };     
mem_block_lst_t mem_free_blocks_lst = { 0 };     

// ff malloc
void*
ff_malloc(
    size_t          size
)
{
    mem_block_t*    blk;
    mem_block_t*    new_blk;

    // Align the size according to the length of the pointer (32-bit/64-bit), 
    // improve the efficiency of CPU read and write memory
    size = (size + sizeof(void*) - 1) & (~(sizeof(void*) - 1));
    // Traverse the free linked list to find a suitable memory block
    blk = LIST_GET_FIRST(mem_free_blocks_lst);
    while (blk)
    {
        if (blk->size >= size)
        {
            LIST_REMOVE(link_for_free, mem_free_blocks_lst, blk);
            goto MALLOC_END;
        }
        blk = LIST_GET_NEXT(link_for_free, blk);
    }

    //If no suitable block is found, you need to manually apply from the heap and 
    //add it to the end of the total linked list
    blk = sbrk((long)(sizeof(mem_block_t) + size));
    blk->size = size;
    LIST_ADD_LAST(link, mem_blocks_lst, blk);

//split free regions if the ideal free region is larger than requested size
MALLOC_END:
    if (blk->size > sizeof(mem_block_t) + size)
    {
        new_blk = (mem_block_t*)((char*)(blk + 1) + size);
        new_blk->size = blk->size - (sizeof(mem_block_t) + size);
        new_blk->flag = MEM_BLK_FLAG_IS_USING;
        blk->size = size;
        LIST_INSERT_AFTER(link, mem_blocks_lst, blk, new_blk);
    }

    blk->flag = MEM_BLK_FLAG_IS_USING;
    return (void*)(blk + 1);
}
// ff free
void ff_free(void * ptr)
{
    mem_block_t * blk;
    mem_block_t * prev_blk;
    mem_block_t * next_blk;
    blk = ((mem_block_t*)ptr - 1);  
    // First check whether the previous memory block is free, and if it is free, merge them
    prev_blk = LIST_GET_PREV(link, blk);
    if (prev_blk && prev_blk->flag == MEM_BLK_FLAG_IS_FREE)
    {
        prev_blk->size += blk->size + sizeof(mem_block_t);
        LIST_REMOVE(link, mem_blocks_lst, blk);
        blk = prev_blk;
    }
    // Then check whether the next memory block next to it is free, and merge them
    next_blk = LIST_GET_NEXT(link, blk);
    if (next_blk && next_blk->flag == MEM_BLK_FLAG_IS_FREE)
    {
        blk->size += next_blk->size + sizeof(mem_block_t);
        LIST_REMOVE(link, mem_blocks_lst, next_blk);
        LIST_REMOVE(link_for_free, mem_free_blocks_lst, next_blk);
    }
    // If blk is not in the free linked list, add it to the end
    if (blk->flag != MEM_BLK_FLAG_IS_FREE)
    {
        blk->flag = MEM_BLK_FLAG_IS_FREE;
        LIST_ADD_LAST(link_for_free, mem_free_blocks_lst, blk);
    }
}

//Best Fit malloc
void*
bf_malloc(size_t size)
{
    mem_block_t*    blk;
    mem_block_t*    new_blk;
    mem_block_t*    best_blk = NULL;
    size_t          best_blk_size = (size_t)0 - 1;
    size = (size + sizeof(void*) - 1) & (~(sizeof(void*) - 1));    
    blk = LIST_GET_FIRST(mem_free_blocks_lst);
    while (blk)
    {
        if (blk->size >= size && blk->size < best_blk_size)
        {
            best_blk = blk;
            best_blk_size = best_blk->size;
            if (size == best_blk_size)
                break;
        }
        blk = LIST_GET_NEXT(link_for_free, blk);
    }

    if (best_blk == NULL)
    {
        best_blk = sbrk((long)(sizeof(mem_block_t) + size));
        best_blk->size = size;
        LIST_ADD_LAST(link, mem_blocks_lst, best_blk);
    }
    else
    {
        LIST_REMOVE(link_for_free, mem_free_blocks_lst, best_blk);
    }
    //  split free regions if the ideal free region is larger than requested size
    if (best_blk->size > sizeof(mem_block_t) + size)
    {
        new_blk = (mem_block_t*)((char*)(best_blk + 1) + size);
        new_blk->size = best_blk->size - (sizeof(mem_block_t) + size);
        new_blk->flag = MEM_BLK_FLAG_IS_USING;
        best_blk->size = size;
        LIST_INSERT_AFTER(link, mem_blocks_lst, best_blk, new_blk);
    }

    best_blk->flag = MEM_BLK_FLAG_IS_USING;

    return (void*)(best_blk + 1);      
}

//Best Fit free
void bf_free(void * ptr)
{
    mem_block_t * blk;
    mem_block_t * prev_blk;
    mem_block_t * next_blk;
    blk = ((mem_block_t*)ptr - 1);  
    //merge them
    prev_blk = LIST_GET_PREV(link, blk);
    if (prev_blk && prev_blk->flag == MEM_BLK_FLAG_IS_FREE)
    {
        prev_blk->size += blk->size + sizeof(mem_block_t);
        LIST_REMOVE(link, mem_blocks_lst, blk);
        blk = prev_blk;
    }
    //merge them
    next_blk = LIST_GET_NEXT(link, blk);
    if (next_blk && next_blk->flag == MEM_BLK_FLAG_IS_FREE)
    {
        blk->size += next_blk->size + sizeof(mem_block_t);
        LIST_REMOVE(link, mem_blocks_lst, next_blk);
        LIST_REMOVE(link_for_free, mem_free_blocks_lst, next_blk);
    }
    if (blk->flag != MEM_BLK_FLAG_IS_FREE)
    {
        blk->flag = MEM_BLK_FLAG_IS_FREE;
        LIST_ADD_LAST(link_for_free, mem_free_blocks_lst, blk);
    }
}

//get data segment size
size_t get_data_segment_size()
{
    mem_block_t * first;
    mem_block_t * last;
    first = LIST_GET_FIRST(mem_blocks_lst);
    last  = LIST_GET_LAST(mem_blocks_lst);
    if (first == NULL)
    {
        return 0;
    }
    else
    {
        return (size_t)((char*)last - (char*)first) + last->size + sizeof(mem_block_t);
    }
}

// get data segment free space size
size_t get_data_segment_free_space_size()
{
    mem_block_t * blk;
    size_t        size = 0;
    //accumulate
    blk = LIST_GET_FIRST(mem_free_blocks_lst);
    while (blk)
    {
        size += blk->size + sizeof(mem_block_t);
        blk = LIST_GET_NEXT(link_for_free, blk);
    }
    return size;
}