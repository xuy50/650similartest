#ifndef MY_MALLOC_H
#define MY_MALLOC_H

#include <stdio.h>
#define __USE_XOPEN_EXTENDED   
#include <unistd.h>


void * ff_malloc(size_t  size);
void ff_free(void * ptr);
size_t get_data_segment_size();
size_t get_data_segment_free_space_size();

//Best Fit malloc/free
void* bf_malloc(size_t size);
void bf_free(void* ptr);

#endif
