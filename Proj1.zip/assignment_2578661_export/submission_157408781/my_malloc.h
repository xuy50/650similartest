#include <stdio.h>
#include <stdlib.h>

#define BLOCK_SIZE sizeof(s_block)

/* Metadata's data structure: use a doubly linked list to store
   all FREE blocks.
 */
struct block {
  size_t size;
  struct block * next;
  struct block * prev;
};

typedef struct block s_block;

void * ff_malloc(size_t size);
void ff_free(void * ptr);
void * bf_malloc(size_t size);
void bf_free(void * ptr);

s_block * increase_heap(size_t size);
s_block * find_block_ff(size_t size);
s_block * find_block_bf(size_t size);
void insert_block(s_block * new_node);
void remove_block(s_block * block);
s_block * merge_block(s_block * block);
void * my_malloc(size_t size, char mode);
void my_free(void * ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

s_block * head = NULL;

unsigned long heap = 0;
unsigned long free_space = 0;