#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

/* Increase the heap for new malloc function if no free blocks are feasable. */
s_block * increase_heap(size_t size) {
    s_block * b = sbrk(0);
    if (sbrk(BLOCK_SIZE + size) == (void*)-1) {
        return NULL;
    }
    heap += (BLOCK_SIZE + size);
    b->size = size;
    b->next = NULL;
    b->prev = NULL;
    return b;
}

/* Find the first available block. */
s_block * find_block_ff(size_t size) {
    s_block * node = head;
    while (node) {
        if (node->size >= size) return node;
        node = node->next;
    }
    return NULL;
}

/* Find the best fit blocks. */
s_block * find_block_bf(size_t size) {
  s_block * node = head;
  size_t best_size = (size_t)INFINITY;
  s_block * best_block = head;
  int find = 0;
  while (node) {
    // If we have found the node just fit the new request, return immediately.
    if (node->size == size) {
        return node;
    }
    // If we find a larger block, set find flag to true, keep searching.
    if (node->size >= size) {
      find = 1;
      // Update the best block.
      if (node->size < best_size) {
        best_size = node->size;
        best_block = node;
      }
    }
    node = node->next;
  }
  // Return NULL if not find, otherwise return best fit block.
  return find ? best_block : NULL;
}

/* Insert new node into linked list. */
void insert_block(s_block * new_node) {
    // Corner case.
    if (!head) {
        head = new_node;
        return;
    }
    s_block * cur_node = head;
    while (cur_node) {
        // Insert before head.
        if (!cur_node->prev && cur_node > new_node) {
            new_node->next = cur_node;
            cur_node->prev = new_node;
            head = new_node;
            return;
        }
        if (cur_node->next && cur_node->next > new_node) {
            cur_node->next->prev = new_node;
            new_node->next = cur_node->next;
            cur_node->next = new_node;
            new_node->prev = cur_node;
            return;
        }
        // Insert after tail.
        if (!cur_node->next) {
            cur_node->next = new_node;
            new_node->prev = cur_node;
            return;
        }
        cur_node = cur_node->next;
    }
}

/* Remove a block from the list. */
void remove_block(s_block * block) {
    // Remove the head.
    if (block == head) {
        head = head->next;
        if (!head) return;
        head->prev = NULL;
        block->next = NULL;
        block->prev = NULL;
        return;
    }
    // Remove the tail.
    if (!block->next) {
        block->prev->next = NULL;
        block->next = NULL;
        block->prev = NULL;
        return;
    }
    block->prev->next = block->next;
    block->next->prev = block->prev;
    block->next = NULL;
    block->prev = NULL;
}

/* Merge the block and its next block. */
s_block * merge_block(s_block * block) {
    s_block * temp = block->next;
    size_t inc_size = (BLOCK_SIZE + temp->size);
    remove_block(temp);
    block->size += inc_size;
    return block;
}

void * my_malloc(size_t size, char mode) {
    if (size == 0) return NULL;
    s_block * block;
    // No free list, increase the heap and allocate the space.
    if (!head) {
        block = increase_heap(size);
        if (!block) return NULL;
        return (void *)((char *)(block) + BLOCK_SIZE);
    }
    else {
        // Find FF/BF block.
        if (mode == 'F') block = find_block_ff(size);
        if (mode == 'B') block = find_block_bf(size);
        // Not found, increase the heap and allocate the space.
        if (!block) block = increase_heap(size);
        // Found the appropriate free block.
        else {
            s_block * old_node = block;
            if (block->size - size > BLOCK_SIZE) {
                // Split the block
                s_block * new_node = (s_block *)((void *)block + BLOCK_SIZE + size);
                new_node->next = NULL;
                new_node->prev = NULL;
                new_node->size = block->size - size - BLOCK_SIZE;
                insert_block(new_node);
            }
            // Update the old node's size.
            old_node->size = size;
            remove_block(old_node);
        }
    }
    return (void *)((char *)(block) + BLOCK_SIZE);
}

void my_free(void * ptr) {
    // Get the block address.
    s_block * free_block = (s_block*)((void *)(ptr) - BLOCK_SIZE);
    free_block->next = NULL;
    free_block->prev = NULL;
    // Insert the block into free list, keep the list sorted by block address.
    insert_block(free_block);
    s_block * prev = free_block->prev;
    s_block * next = free_block->next;
    // If the block's prev or next block is free, merge them.
    if (next && (void *)free_block + BLOCK_SIZE + free_block->size == next) {
        free_block = merge_block(free_block);
    }
    if (prev && (void *)prev + BLOCK_SIZE + prev->size == free_block) {
        free_block = merge_block(prev);
    }
}

void * ff_malloc(size_t size) {
    return my_malloc(size, 'F');
}

void * bf_malloc(size_t size) {
    my_malloc(size, 'B');
}

void ff_free(void * ptr) {
    my_free(ptr);
}

void bf_free(void * ptr) {
    my_free(ptr);
}

unsigned long get_data_segment_size() {
    return heap;
}

unsigned long get_data_segment_free_space_size(){
    s_block * cur = head;
    while (cur) {
        free_space += (cur->size + BLOCK_SIZE);
        cur = cur->next;
    }
    return free_space;
}