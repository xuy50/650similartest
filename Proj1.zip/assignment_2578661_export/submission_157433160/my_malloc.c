#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include "my_malloc.h"

#define META_SIZE sizeof(block)

block *head = NULL;
block *tail = NULL;

size_t free_size = 0;
size_t allocated_size = 0;

block *createBlock(size_t size)
{
    // set program breaker
    // block *new_block = sbrk(0);
    block *new_Node = sbrk(size + META_SIZE);
    if (new_Node == (void *)(-1))
    {
        return NULL;
    }
    new_Node->size = size;
    new_Node->prev = NULL;
    new_Node->next = NULL;
    return new_Node;
}

// add a free block at the end of free_block list
void add(block *freeNode)
{
    if (head == NULL && tail == NULL)
    {
        head = freeNode;
        tail = freeNode;

        head->prev = NULL;
        head->next = NULL;
        tail->prev = NULL;
        tail->next = NULL;
    }
    // add to front
    else if (freeNode < head)
    {
        // if the free block position is head
        freeNode->next = head;
        freeNode->next->prev = freeNode;
        freeNode->prev = NULL;
        head = freeNode;
    }
    // add to end
    else if (freeNode > tail)
    {
        tail->next = freeNode;
        freeNode->prev = tail;
        tail = freeNode;
    }
    else
    {
        block *curr = head->next;
        while (freeNode > curr && curr != NULL)
        {
            curr = curr->next;
        }
        freeNode->next = curr;
        curr->prev->next = freeNode;
        freeNode->prev = curr->prev;
        curr->prev = freeNode;
    }
}

void removefree(block *removeNode)
{
    if ((removeNode != head && removeNode->prev == NULL && removeNode->next == NULL) || head == NULL || tail == NULL || removeNode == NULL)
    {
        return;
    }
    // if remove the first block
    if (removeNode == head)
    {
        block *temp = head;
        if (temp->next == NULL)
        {
            head = NULL;
            tail = NULL;
            removeNode->next = NULL;
            removeNode->prev = NULL;
            return;
        }
        head = head->next;
        head->prev = NULL;

        temp->next = NULL;
        temp->prev = NULL;
        return;
    }
    // if remove the last block
    else if (tail == removeNode)
    {
        block *temp = tail;
        tail = tail->prev;
        if (tail != NULL)
        {
            tail->next = NULL;
        }

        temp->next = NULL;
        temp->prev = NULL;
        return;
    }
    // if remove from middle
    else if (removeNode->next != NULL && removeNode->prev != NULL)
    {
        removeNode->prev->next = removeNode->next;
        removeNode->next->prev = removeNode->prev;
        removeNode->prev = NULL;
        removeNode->next = NULL;
    }
}

void split(block *Node, size_t size)
{
    if (Node == NULL)
    {
        return;
    }
    if ((Node->size - size) > META_SIZE)
    {
        block *newBlock = (block *)((char *)Node + META_SIZE + size);

        newBlock->size = (Node->size - META_SIZE - size);

        // if the Node is not the tail or head of free_list,
        // set newBlock->next->prev = newBlock

        if (Node->next != NULL && Node->prev != NULL)
        {
            Node->next->prev = newBlock;
            newBlock->next = Node->next;
            Node->prev->next = newBlock;
            newBlock->prev = Node->prev;
            // Node->size = size;
            // Node->next = NULL;
            // Node->prev = NULL;
        }
        // if Node it the tail of free_list, set the tail to splited-newBlock
        else if (Node->next == NULL && Node->prev != NULL)
        {
            tail = newBlock;
            newBlock->prev = Node->prev;
            tail->next = NULL;
            Node->prev->next = newBlock;
            // Node->size = size;
            // Node->next = NULL;
            // Node->prev = NULL;
        }
        // if Node is the head of free_list
        else if (Node->next != NULL && Node->prev == NULL)
        {
            head = newBlock;
            head->prev = NULL;
            newBlock->next = Node->next;
            Node->next->prev = newBlock;
            // Node->size = size;
            // Node->next = NULL;
            // Node->prev = NULL;
        }
        // Node->next==NULL && Node->prev == NULL
        else if (Node->next == NULL && Node->prev == NULL)
        {
            head = newBlock;
            tail = newBlock;
            newBlock->next = NULL;
            newBlock->prev = NULL;
            // Node->size = size;
            // Node->next = NULL;
            // Node->prev = NULL;
        }
        // newBlock->next = Node->next;
        // newBlock->prev = Node->prev;
        Node->size = size;
        Node->next = NULL;
        Node->prev = NULL;
        // removefree(Node);

        free_size -= (size + META_SIZE);
    }
    else
    {
        removefree(Node);
        free_size -= (Node->size + META_SIZE);
    }
}

// If there are two adjacent free blocks,
// merge them and add them
void merge(block *freeNode)
{
    // if the next block is free
    //if the free list is not empty
    if (head != NULL || tail != NULL)
    {

        if (freeNode <= head)
        {
            // if freeNode address is smaller than head
            // can merge with the next free block(which is original head)
            block *f_head = (block *)((char *)freeNode + freeNode->size + META_SIZE);
            if (f_head == head)
            {
                freeNode->size += (head->size + META_SIZE);
                if (head->next != NULL)
                {
                    head->next->prev = freeNode;

                    freeNode->next = head->next;
                }
                else
                {
                    freeNode->next = NULL;
                    tail = freeNode;
                    tail->next = NULL;
                }
                head->next = NULL;
                freeNode->prev = NULL;
                head = freeNode;
            }
            else
            {
                add(freeNode);
                /*head->prev = freeNode;
                freeNode->next = head;
                head = freeNode;
                freeNode->prev = NULL;*/
            }
        }
        // if freeNode address is bigger than tail
        else if (freeNode > tail)
        {
            block *pFree = (block *)((char *)tail + tail->size + META_SIZE);
            // and can merge with the previous free block
            if (pFree == freeNode)
            {
                tail->size += (freeNode->size + META_SIZE);
            }
            else
            {
                add(freeNode);
                /*tail->next = freeNode;
                freeNode->prev = tail;
                tail = freeNode;
                freeNode->next = NULL;*/
            }
        }
        // if the node is in middle
        else
        {

            block *curr = head->next;

            while (freeNode > curr && curr->next != NULL)
            {
                curr = curr->next;
            }

            block *curr_prev = (block *)((char *)curr->prev + curr->prev->size + META_SIZE);
            //   if the freeNode can be merged with both

            if (freeNode == curr_prev && curr == (block *)((char *)freeNode + freeNode->size + META_SIZE))
            {
                // merge with previous one
                curr->prev->size += freeNode->size + META_SIZE;
                // set new address
                freeNode = curr->prev;
                // merge with next one
                freeNode->size += (curr->size + META_SIZE);
                if (curr->next != NULL)
                {
                    curr->next->prev = freeNode;
                    freeNode->next = curr->next;
                }
                else
                {
                    freeNode->next = NULL;
                    tail = freeNode;
                }
                curr->prev = NULL;
                curr->next = NULL;
            }
            // if freeNode can only merge with prev one
            else if (freeNode == curr_prev && (block *)((char *)freeNode + freeNode->size + META_SIZE) != curr)
            {
                // merge with previous one
                curr->prev->size += (freeNode->size + META_SIZE);
            }
            // if freeNode can only merge with next one
            else if (freeNode != curr_prev && (block *)((char *)freeNode + freeNode->size + META_SIZE) == curr)
            {
                // merge with next one
                freeNode->size += (curr->size + META_SIZE);
                //if the next block is not tail
                if (curr->next != NULL)
                {
                    curr->next->prev = freeNode;
                    curr->prev->next = freeNode;
                    freeNode->next = curr->next;
                    freeNode->prev = curr->prev;
                }
                else
                {
                    freeNode->next = NULL;
                    freeNode->prev = curr->prev;
                    curr->prev->next = freeNode;
                    tail = freeNode;
                }
                curr->prev = NULL;
                curr->next = NULL;
            }
            //if freeNode cannot do merge
            else if (freeNode != curr_prev && (block *)((char *)freeNode + freeNode->size + META_SIZE) != curr)
            {
                add(freeNode);
            }
        }
    }
    else
    {
        add(freeNode);
    }
}

// search first fit free block from free list
block *find_pro_free_block_ff(size_t size)
{
    block *curr = head;
    while (curr != NULL)
    {
        if (curr->size == size)
        {
            free_size -= (size + META_SIZE);
            removefree(curr);
            return curr;
        }
        else if (curr->size < size)
        {
            curr = curr->next;
            continue;
        }
        // if curr->size > size
        // need to split the block
        else
        {
            split(curr, size);
            return curr;
        }
        curr = curr->next;
    }
    return NULL;
}

void *ff_malloc(size_t size)
{
    if (size <= 0)
    {
        return NULL;
    }
    block *Node = NULL;
    // if the free list is empty
    // which means we are doing the first malloc
    if (head == NULL)
    {
        Node = createBlock(size);

        if (Node == NULL)
        {
            return NULL;
        }
        allocated_size += (Node->size + META_SIZE);
    }
    // if the free list is not empty
    else
    {
        Node = find_pro_free_block_ff(size);
        // remove the free block from free list
        if (Node == NULL)
        {
            Node = createBlock(size);
            // if sbrk function doesn't work
            if (Node == NULL)
            {
                return NULL;
            }
            allocated_size += (Node->size + META_SIZE);
        }
    }
    return (void *)Node + META_SIZE;
}

void ff_free(void *ptr)
{
    if (ptr == NULL)
    {
        return;
    }
    block *node = (block *)((char *)ptr - META_SIZE);
    if (node != NULL)
    {
        free_size += (node->size + META_SIZE);
        // add(node);
        merge(node);
    }
}

//find the most suitable block
block *find_pro_free_block_bf(size_t size)
{
    block *curr = head;
    size_t smallest_diff = ULONG_MAX;
    size_t size_diff;
    block *target = NULL;
    while (curr != NULL)
    {
        if (curr->size == size)
        {
            free_size -= (size + META_SIZE);
            removefree(curr);
            return curr;
        }
        else if (curr->size > size)
        {
            size_diff = curr->size - size;
            if (size_diff < smallest_diff)
            {
                smallest_diff = size_diff;
                target = curr;
            }
        }
        else
        {
            curr = curr->next;
            continue;
        }
        curr = curr->next;
    }
    if (target != NULL)
    {
        split(target, size);
        return target;
    }
    return NULL;
}

void *bf_malloc(size_t size)
{
    if (size <= 0)
    {
        return NULL;
    }

    block *Node = NULL;
    // if the free list is empty
    // which means we are doing the first malloc
    if (head == NULL)
    {
        Node = createBlock(size);

        if (Node == NULL)
        {
            return NULL;
        }
        allocated_size += (Node->size + META_SIZE);
    }
    // if the free list is not empty
    else
    {
        Node = find_pro_free_block_bf(size);
        // remove the free block from free list
        if (Node == NULL)
        {
            Node = createBlock(size);
            // if sbrk function doesn't work
            if (Node == NULL)
            {
                return NULL;
            }
            allocated_size += (Node->size + META_SIZE);
        }
    }
    return (void *)Node + META_SIZE;
}

//same as ff_free
void bf_free(void *ptr)
{
    if (ptr == NULL)
    {
        return;
    }
    block *node = (block *)((char *)ptr - META_SIZE);
    if (node != NULL)
    {
        free_size += (node->size + META_SIZE);
        // add(node);
        merge(node);
    }
}

unsigned long get_data_segment_size() { return allocated_size; }
unsigned long get_data_segment_free_space_size() { return free_size; }

// // for personal testing print
// void printFreeList()
// {
//     printf("************free blocks***************\n");
//     printf("allocated_size: %zu, free_size: %zu\n", allocated_size, free_size);
//     block *curr = head;
//     printf("Address of curr is %p \n", (void *)curr);
//     while (curr != NULL)
//     {
//         printf("Address of curr is %p \n", (void *)curr);
//         printf("-----------------\n");
//         if (curr == head)
//         {
//             printf("list head is: %p ,", curr);
//             printf(" block size is: %zu\n", curr->size);
//         }
//         if (curr == tail)
//         {
//             printf("list tail is: %p ,", curr);
//             printf(" block size is: %zu\n", curr->size);
//         }

//         printf("current position is: %p", curr);
//         printf(" block size is: %zu\n", curr->size);
//         printf("\n");

//         curr = curr->next;
//         printf("------------------\n");
//     }
//     printf("****************end*********************\n\n");
// }
