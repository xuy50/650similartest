
#ifndef MY_MALLOC_H
#define MY_MALLOC_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct block_t{
    size_t size;
    struct block_t *prev;
    struct block_t *next;
};
typedef struct block_t block;

void* ff_malloc(size_t size);
void ff_free(void *ptr);

void* bf_malloc(size_t size);
void bf_free(void *ptr);


//print for test cases
void printFreeList();


unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();



#endif