#include <stdio.h>
#include <stdio.h>
#include <sys/types.h>
#include<unistd.h>
struct block_tag
{
    /* data */
    size_t block_size;    
    struct block_tag* next;   
    struct block_tag* prev;
    
};
typedef struct block_tag block_t;

struct linked_block_tag{
    struct block_tag* head;
    struct block_tag* tail;
  //struct block_tag* test;
    size_t total_size;
    size_t free_size;
};
typedef struct linked_block_tag linked_blocks;
void printFreeList();
void* malloc_new_space(block_t* curr_block, size_t request_size);
void merge_block(block_t* block);
void add_block(block_t* add_block);
void remove_block(block_t* curr_block);
void *ff_malloc(size_t size);
void ff_free(void* ptr);
void * bf_malloc(size_t size);
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
