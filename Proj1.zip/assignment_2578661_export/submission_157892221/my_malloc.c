#include "my_malloc.h"
#include <stdio.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


linked_blocks my_malloc = {NULL, NULL, 0, 0};

// void add_block(block_t * block){

// }

void split_block(block_t * resuse, block_t * new_free){
  if(my_malloc.head == my_malloc.tail){
    my_malloc.head = new_free;
    my_malloc.tail = new_free;
    new_free->prev = NULL;
    new_free->next = NULL;   
    resuse->prev = NULL;
    resuse->next = NULL;
  }
  else if(resuse == my_malloc.head){   
    new_free->prev = NULL;
    resuse->next->prev = new_free;
    new_free->next = resuse->next;
    resuse->next = NULL;
    resuse->prev = NULL;
    my_malloc.head = new_free;
  }
  else if(resuse == my_malloc.tail){   
    new_free->next = NULL;
    resuse->prev->next = new_free;
    new_free->prev = resuse->prev;
    resuse->next = NULL;
    resuse->prev = NULL;
    my_malloc.tail = new_free;
  }
  else{
    resuse->prev->next = new_free;
    new_free->prev = resuse->prev;
    new_free->next = resuse->next;
    resuse->next->prev = new_free;    
    resuse->prev = NULL;
    resuse->next = NULL;
  }
}

void* malloc_new_space(block_t* curr_block, size_t request_size)
{
    curr_block = sbrk(request_size);
    if(curr_block == (block_t *)(-1))
      return NULL;
    my_malloc.total_size += request_size;
    curr_block->next = NULL;
    curr_block->prev = NULL;
    curr_block->block_size = request_size - sizeof(block_t);
    return (char*)curr_block + sizeof(block_t);
}

void merge_block(block_t* block){
  //printf("block->prev:%p", block->prev);
  if(my_malloc.head == my_malloc.tail){
    return;
  }
  if(block == my_malloc.head){
    if((char*)block + block->block_size + sizeof(block_t) == (char*)block->next){
      //block->next = block->next->next;
      block->block_size = block->block_size+ block->next->block_size + sizeof(block_t);
	    remove_block(block->next);
    }
    return;
  }
  else if(block == my_malloc.tail){
    if((char*)block->prev + block->prev->block_size + sizeof(block_t) == (char*)block){
      block->prev->block_size = block->prev->block_size + block->block_size + sizeof(block_t);
      remove_block(block);
    }
    return;
  }
  else{
    if((char*)block->prev + block->prev->block_size + sizeof(block_t) == (char*)block){  
	    if((char*)block + block->block_size + sizeof(block_t) == (char*)block->next){
	      block->block_size = block->block_size + block->next->block_size + sizeof(block_t);
	      remove_block(block->next);
	    }
      block->prev->block_size = block->prev->block_size + block->block_size + sizeof(block_t);
      remove_block(block);
    }
    else{
      if((char*)block + block->block_size + sizeof(block_t) == (char*)block->next){
        block->block_size = block->block_size + block->next->block_size + sizeof(block_t);
        remove_block(block->next);
      }
    }
 }
  return;
}

void add_block(block_t* add_block){
    size_t success_insert = 0;
    if(my_malloc.head == NULL && my_malloc.tail == NULL){
      add_block->prev = NULL;
      add_block->next = NULL;
      my_malloc.tail = add_block;
      my_malloc.head = add_block;
      success_insert = 1;
    }
    else if((char*)add_block + add_block->block_size + sizeof(block_t) <= (char*)my_malloc.head){
        add_block->prev = NULL;
        my_malloc.head->prev = add_block;
        add_block->next = my_malloc.head;
        my_malloc.head = add_block;
        success_insert = 1;
    }
    else if ((char*)add_block >= (char*)my_malloc.tail + my_malloc.tail->block_size + sizeof(block_t) && (char*) add_block + add_block->block_size + sizeof(block_t) <= (char*) sbrk(0))
    {
        add_block->prev = my_malloc.tail;
        add_block->next = NULL;
        add_block->prev->next = add_block;
        my_malloc.tail = add_block;
        success_insert = 1;
    }
    else if((char*)add_block >= (char*)my_malloc.head + my_malloc.head->block_size + sizeof(block_t)  && (char*) add_block + add_block->block_size + sizeof(block_t) <= (char*)my_malloc.tail ){
      block_t* curr = my_malloc.head;
	    curr = curr->next;
	    block_t* prev = curr->prev;
      while(curr != NULL){
        if(((char*)add_block + add_block->block_size + sizeof(block_t) <= (char*)curr) && ((char*)add_block >= (char*)prev + prev->block_size + sizeof(block_t))){
	        prev->next = add_block;
          add_block->prev = prev;
          curr->prev = add_block;
          add_block->next = curr;
          success_insert = 1;
          break;
        }
        else{
	        prev = curr;
          curr = curr->next;
        }	  
      }
    }
    merge_block(add_block);
    //printFreeList();
}

void remove_block(block_t* curr_block){
    block_t* prev = curr_block->prev;
    block_t* next = curr_block->next;
    if(my_malloc.head == NULL && my_malloc.tail == NULL){
       return;
    }
    else if(next == NULL && prev == NULL){
        my_malloc.head = NULL;
        my_malloc.tail = NULL;
    }
    else if(prev == NULL && next != NULL){
        next->prev = NULL;
        my_malloc.head = next;
    }
    else if(next == NULL && prev != NULL){
        prev->next = NULL;
        my_malloc.tail = prev;
    }
    else{
        prev->next = next;
        next->prev = prev;
    }
    curr_block->next = NULL;
    curr_block->prev = NULL;
}

void *ff_malloc(size_t size){
    block_t* block;
    size_t request_size = sizeof(block_t) + size;
         
    if(my_malloc.total_size == 0){       
        return malloc_new_space(block, request_size);
    }
    else{
      if(my_malloc.free_size < request_size){     
          return malloc_new_space(block, request_size); 
      }
      else{
        int flag_find = 0;
        block_t* address;
        block_t* curr = my_malloc.head;
        while(curr != NULL){
          if(curr->block_size >= (request_size - sizeof(block_t))){
            if(curr->block_size + sizeof(block_t) - request_size > sizeof(block_t)){
              block_t* free = (block_t*)((char*)curr+request_size);
              free->block_size = curr->block_size - request_size;
              split_block(curr, free);
              curr->block_size = size;
              my_malloc.free_size -= request_size;
              address = (block_t*)((char*)curr + sizeof(block_t));
              flag_find = 1;
              break;
            }
            else{
              remove_block(curr);
              address = (block_t*)((char*)curr + sizeof(block_t));
              my_malloc.free_size = my_malloc.free_size - (curr->block_size + sizeof(block_t));  
              flag_find = 1;
              break;
            }
          }
          curr = curr ->next;
        }
        if(flag_find == 0){
          return malloc_new_space(block, request_size);
        }
        return address;
        }
      }
    
}

void ff_free(void* ptr){
  if(!ptr){
    return;
  }
  block_t* free_block = ptr-sizeof(block_t);
  my_malloc.free_size += (free_block->block_size + sizeof(block_t));
  add_block(free_block);
}

void * bf_malloc(size_t size){
  //两种情况 1. free list里面找 2. free 里找不到， 创建
    block_t* block;
    size_t flag_find = 0;
    size_t request_size = sizeof(block_t) + size;         
    if(my_malloc.total_size == 0){       
        return malloc_new_space(block, request_size);
    }
    else{
      if(my_malloc.free_size < request_size){     
        return malloc_new_space(block, request_size); 
      }
      else{
        block_t* address = NULL;
        size_t min_size = __INT32_MAX__;
        block_t* curr = my_malloc.head;
        //if(curr == NULL){}
        while(curr != NULL){
          if(curr->block_size > size){ 
            if(curr->block_size < min_size){
              min_size = curr->block_size;
              address = curr;             
            }
            flag_find = 1;
          }
          if(curr->block_size == size){
            address = curr;
            flag_find = 1;
            break;
          }
          curr = curr ->next;           
        }
        if(flag_find == 1){
          curr = address;
        }
        else{
          return malloc_new_space(block, request_size);
        }

        if(curr->block_size + sizeof(block_t) - request_size > sizeof(block_t)){
          block_t* free = (block_t*)((char*)curr+request_size);
          free->block_size = curr->block_size - request_size;
          split_block(curr, free);
          curr->block_size = size;
          my_malloc.free_size -= request_size;
          address = (block_t*)((char*)curr + sizeof(block_t));
        }
        else{
          remove_block(curr);
          address = (block_t*)((char*)curr + sizeof(block_t));
          my_malloc.free_size = my_malloc.free_size - (curr->block_size + sizeof(block_t));  
        }
      return address;
      }
    }
}

void bf_free(void * ptr){
   ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return my_malloc.total_size;
}
unsigned long get_data_segment_free_space_size() {
  return my_malloc.free_size;
}
