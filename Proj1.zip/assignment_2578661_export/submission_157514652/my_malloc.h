#include <stdlib.h>
#include <stdio.h>

struct block_tag {
  size_t size;        // exclude sizeof(block_t)
  struct block_tag *next;
  struct block_tag *prev;
};
typedef struct block_tag block_t;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

// find the first fit free block
block_t *find_ffree_block(size_t size);
// find the best fit free block
block_t *find_bfree_block(size_t size);
// add the new block
block_t *add_new_block(size_t size);

block_t *reuse_free_block(size_t size, block_t *block);
block_t *split_block(size_t size, block_t *block);
void remove_free_block(block_t *block);
void add_free_block(block_t *block);

// free the block 
void free(void *ptr);
// merging the adjacent free block 
void merge_free_block(block_t *block);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte