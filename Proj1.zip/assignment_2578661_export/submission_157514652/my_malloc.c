#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

block_t *head = NULL;
#define BLOCK_SIZE sizeof(block_t)
size_t total_size = 0;
size_t free_size = 0;

//First Fit malloc/free
void *ff_malloc(size_t size){
    block_t *block;
    if(size <= 0) {
        return NULL;
    }
    block = find_ffree_block(size);
    // no available free block to use
    if(block == NULL) {
        block = add_new_block(size);
        if(block == NULL) {
            return NULL;
        }
    }
    // reuse free block
    else{
        block = reuse_free_block(size, block); 
    }
    return ((void *)block + BLOCK_SIZE);
}
void ff_free(void *ptr){
    free(ptr);
}

//Best Fit malloc/free
void *bf_malloc(size_t size) {
    block_t *block;
    if(size <= 0) {
        return NULL;
    }
    block = find_bfree_block(size);
    // no available free block to use
    if(block == NULL) {
        block = add_new_block(size);
        if(block == NULL) {
            return NULL;
        }
    }
    // reuse free block
    else {
        block = reuse_free_block(size, block); 
    }
    return ((void *)block + BLOCK_SIZE);
}
void bf_free(void *ptr) {
     free(ptr);
}

// find the first fit free block
block_t *find_ffree_block(size_t size) {
    block_t *curr = head;
    while(curr != NULL) {
        if(curr->size >= size) {
            return curr;
        }
        curr = curr->next;
    }
    return NULL;   
}

// find the best fit free blocls
block_t *find_bfree_block(size_t size) {
    block_t *curr = head;
    block_t *block;
    size_t min_size;
    bool find = false;
    while(curr != NULL) {
        if(curr->size == size) {
            return curr;
        }
        else if(curr->size > size) {
            if(find == false) {
                // initialization
                block = curr;
                min_size = curr->size;
                find = true;
            }
            else if(min_size > curr->size) {
                min_size = curr->size;
                block = curr;
            }
        }
        curr = curr->next;
    }
    if(find == false){
        return NULL;
    }
    else {
        return block; 
    }     
}

block_t *add_new_block(size_t size) {
    block_t *block = sbrk(size + BLOCK_SIZE);
    // sbrk fail
    if((void*)block == ((void*)(-1))){
        return NULL;
    }
    // do not include BLOCK_SIZE
    block->size = size;
    block->next = NULL;
    block->prev = NULL;
    total_size = total_size + (size + BLOCK_SIZE);
    return block;
}

block_t *reuse_free_block(size_t size, block_t *block) {
    if(block->size > (size + BLOCK_SIZE)) {
        block_t *new_b = split_block(size, block);
        free_size = free_size - (size + BLOCK_SIZE);
        return new_b;
    }
    else {
        remove_free_block(block);
        free_size = free_size - (block->size + BLOCK_SIZE);
        return block;
    }
    
}

block_t *split_block(size_t size, block_t *block) {
    // (void*) points to some data location in the storage
    // block need to convert to a pointer
    block_t *split_b = (void *)block + size + BLOCK_SIZE;
    // the new free block nees to have its own block size
    split_b->size = block->size - (size + BLOCK_SIZE);
    split_b->next = NULL;
    split_b->prev = NULL;
    block->size = size;
    remove_free_block(block);
    add_free_block(split_b);
    return block;
}

void remove_free_block(block_t *block) {
    // head
    if(head == block) {
        if(block->next == NULL) {
            head = NULL;
        }
        else{
            head = block->next;
            block->next->prev = NULL;
        }
    }
    // tail
    else if(block->next == NULL) {
        block->prev->next = NULL;
    }
    // middle
    else {
        block->next->prev = block->prev;
        block->prev->next = block->next;
    }
    block->next = NULL;
    block->prev = NULL;
}
void add_free_block(block_t *block) {
    // head
    if(head == NULL) {
        head = block;
    }
    else if(head > block) {
        block->next = head;
        head = block;
        block->next->prev = block;
    }
    // middle or tail
    else {
        block_t *curr = head;
        while(curr->next != NULL && curr->next < block) {
            curr = curr->next;
        }
        // tail
        if(curr->next == NULL) {
            curr->next = block;
            block->prev = curr;
        }
        // middle
        else{
            block->next = curr->next;
            block->prev = curr;
            curr->next = block;
            block->next->prev = block;
        }
    }
}

void free(void *ptr){
     if(ptr == NULL) {
        return;
    }
    // ptr points to the usable space
    // move left to point the beginning of the block size
    block_t *block = (void *)ptr - BLOCK_SIZE;
    add_free_block(block);
    free_size = free_size + (block->size + BLOCK_SIZE);
    merge_free_block(block);
}

void merge_free_block(block_t *block) {
    if(block->next != NULL) {
        if(((void *)block->next) == ((void *)block + block->size + BLOCK_SIZE)) {
            block->size = block->size + (block->next->size + BLOCK_SIZE);
            remove_free_block(block->next);
        }
    }
    if(block->prev != NULL) {
        if(((void *)block) == ((void *)block->prev + block->prev->size + BLOCK_SIZE)) {
            block->prev->size = block->prev->size + block->size + BLOCK_SIZE;
            remove_free_block(block);
        }
    }
}

unsigned long get_data_segment_size() {
    return total_size;
}
unsigned long get_data_segment_free_space_size() {
    return free_size;
}