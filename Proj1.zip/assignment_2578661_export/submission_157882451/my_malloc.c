#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

data_segment * freeList_head = NULL;
data_segment * freeList_tail = NULL;
size_t segment_size = 0;
size_t free_segment_size = 0;

void * ff_malloc(size_t size) {
    int malloced = 0;
    data_segment* new_curr;
    for(data_segment* curr = freeList_head; curr != NULL; curr = curr->next) {
        //keep searching until we have a block with enough space
        if(curr->size < size) {
            continue;
        }
        unlink_segment(curr);
        if (curr->size > size + sizeof(data_segment)) {
          add_split_free_segment(size, curr);
          curr->size = size;
        }       
        new_curr = shrink_current_segment(curr);
        malloced = 1;
        break;
    }
    //All the block sizes are smaller than that we want or curr is NULL.
    //We need use sbrk() to add space at the end of the heap.
    if(malloced == 0) {
        //printf("Malloc new!\n");
        data_segment * new_segment = sbrk(size + sizeof(data_segment));
        new_segment->prev = NULL;
		new_segment->next = NULL;
		new_segment->size = size;
		//adjust the segment_size
		segment_size += size + sizeof(data_segment);

        new_curr = (void*)new_segment + sizeof(data_segment);
        
    }
    return new_curr;
}

void ff_free(void * ptr) {
  data_segment * segment_to_free = (data_segment *)((char *)ptr - sizeof(data_segment));
  free_segment_size += segment_to_free->size + sizeof(data_segment);
  link_segment(segment_to_free);
  freeFrontAndBack(segment_to_free);
}

void *bf_malloc(size_t size){
    data_segment * new_curr;
    data_segment * best_segment = NULL;
    for(data_segment* curr = freeList_head; curr != NULL; curr = curr->next) {
        //keep searching until we have a block with enough space
        if(curr->size < size) {
            continue;
        }
        if(best_segment == NULL || best_segment->size > curr->size){
            best_segment = curr;
        }
        if(best_segment->size==size){
        	break;
        }
        
    }
    //All the block sizes are smaller than that we want or curr is NULL.
    //We need use sbrk() to add space at the end of the heap.
    if(best_segment == NULL) {
        
        data_segment * new_segment = sbrk(size + sizeof(data_segment));
		new_segment->prev = NULL;
		new_segment->next = NULL;
		new_segment->size = size;
		//adjust the segment_size
		segment_size += size + sizeof(data_segment);
        return (void*)new_segment + sizeof(data_segment); 
        
    } else {
        //Remove current block since it will be returned
	//Add a split block if there are more space remain in block after allocating
        unlink_segment(best_segment);
        if (best_segment->size > size + sizeof(data_segment)) {
          add_split_free_segment(size, best_segment);
          best_segment->size = size;
        }       
        //Update the curr block to the size we requested for malloc and return the address
        return shrink_current_segment(best_segment);
    } 
};


void bf_free(void * ptr) {
  return ff_free(ptr);
}

void link_segment(data_segment * splitted_segment) {
    int added = 0;
    int i = 0;
    //iterate through free list, when 
    data_segment * curr = freeList_head;
    if(freeList_head && curr >= freeList_head) {
        //for(data_segment * curr = freeList_head; curr->next != NULL; curr = curr->next) {
        while(curr->next!=NULL){
            //printf("i = %d\n",i);
            if(splitted_segment < curr->next) {
                //add splitted_segment between curr and the original curr->next
                splitted_segment->prev = curr;
                splitted_segment->next = curr->next;
                curr->next = splitted_segment;
                if(splitted_segment->next != NULL){
                    splitted_segment->next->prev = splitted_segment;
                }
                added = 1;
                break;
            }
            curr = curr->next;
            //i += 1;
        }
        if(added == 0) {
            //if this block haven't find location to add and it points to NULL, update tail points to it
            // Warning: the current tail must be connect to splitted_segment            
            splitted_segment->prev = curr;
            splitted_segment->next = curr->next;
            curr->next = splitted_segment;
            //freeList_tail = splitted_segment;
            if(!splitted_segment->next) {
                freeList_tail = splitted_segment;
            } else {
            	splitted_segment->next->prev = splitted_segment;
            }
        }  
    }
    else {
        freeList_head = splitted_segment;
        freeList_tail = splitted_segment;
        splitted_segment->prev = NULL;
        splitted_segment->next = curr;
    }

}

void * shrink_current_segment(data_segment * curr) {
    free_segment_size -= (curr->size + sizeof(data_segment));
    curr->prev = NULL;
    curr->next = NULL;

    return (void*)curr + sizeof(data_segment);
}

//add partial free segment back to the free list
void add_split_free_segment(size_t size, data_segment * curr) {
    data_segment * splitted_segment;
    splitted_segment = (data_segment *)((void*)curr + sizeof(data_segment) + size);

    //total curr size minus the size need to be occupied
    splitted_segment->size = curr->size - size - sizeof(data_segment);
    splitted_segment->prev = NULL;
    splitted_segment->next = NULL;

    //add this partial free segment back to the free linked list
    link_segment(splitted_segment);
}

void unlink_segment(data_segment * curr) {
    //curr is in the middle of the list
    if(curr->prev && curr->next) {
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
    }
    //curr is the tail;
    else if(curr->prev && curr->next == NULL) {
        freeList_tail = curr->prev;
        curr->prev->next = NULL;
        
    }
    //curr is the head;
    else if(curr->prev == NULL && curr->next) {
        freeList_head = curr->next;
        curr->next->prev = NULL;
    }
    //only curr one block in the free list
    else {
        //printf("Only!\n");
        freeList_head = NULL;
        freeList_tail = NULL;
    }
}

void freeFrontAndBack(data_segment * segment_to_free){
	if (segment_to_free->next != NULL && ((char *)segment_to_free + segment_to_free->size + sizeof(data_segment) == (char *)segment_to_free->next)) {
    	segment_to_free->size += sizeof(data_segment) + segment_to_free->next->size;
    	unlink_segment(segment_to_free->next);
	}
	if (segment_to_free->prev != NULL && ((char *)segment_to_free->prev + segment_to_free->prev->size + sizeof(data_segment) == (char *)segment_to_free)) {
		segment_to_free->prev->size += sizeof(data_segment) + segment_to_free->size;
		unlink_segment(segment_to_free);
	 }
	
}

unsigned long get_data_segment_size() {
  return segment_size;
}

unsigned long get_data_segment_free_space_size() {
  return free_segment_size;
}
