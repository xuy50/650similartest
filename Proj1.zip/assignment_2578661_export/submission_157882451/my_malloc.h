#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> //sbrk()
#include <assert.h>
#include <stdbool.h>

//use linkedlist to store data 
struct _data_segment{
    size_t size;
    bool is_free;
    struct _data_segment * prev;
    struct _data_segment * next;
};
typedef struct _data_segment data_segment;


//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//Performance
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

//Helper functions
void unlink_segment(data_segment * curr);
void add_split_free_segment(size_t size, data_segment * curr);
void link_segment(data_segment * splitted_segment);
void * shrink_current_segment(data_segment * curr);
void freeFrontAndBack(data_segment * segment_to_free);
