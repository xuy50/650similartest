#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include "my_malloc.h"

meta_block* free_head = NULL;
// Record the total memory size required for heap
unsigned long total_allocate = 0;

/*
  Function to merge the adjacent blocks, 
  the pointer past in is pointed to the previous 
  block of the newly freed block
*/
void merge_free(meta_block * curr){
    // check previos block
    if (curr->next){
        if(curr->size + META_SIZE + (char*)curr == (char*)(curr->next)){
            curr->size = curr->size + curr->next->size + META_SIZE;
            curr->next = curr->next->next;
            if(curr->next){
                curr->next->prev = curr;
            }
        }
        // if didn't merge the previous one, move to the newly freed block
        else{
            curr = curr->next;
        }
    }
    // check next block
    if(curr->next && curr->size + META_SIZE + (char*)curr == (char*)(curr->next)){
        curr->size = curr->size + curr->next->size + META_SIZE;
        curr->next = curr->next->next;
        if(curr->next){
            curr->next->prev = curr;
        }
    }
}

void *ff_malloc(size_t size){
    void * res = NULL;
    meta_block * curr = free_head;
    while (curr != NULL)
    {
        //find first usable block in free list
        if (curr -> size >= size)
        {
            // if it can be splitted
            if ( (curr->size) - size > META_SIZE)
            {
                curr->size = curr->size - size - META_SIZE;
                meta_block * new_block = (meta_block *)((char *)curr + curr->size + META_SIZE);
                new_block->size = size;
                new_block->next = NULL;
                new_block->prev = NULL;
                res = (void *)new_block->beg;
                
            } 
            // if can not be splitted
            else{
                if(free_head == curr)
                    free_head = curr->next;
                
                if(curr->next != NULL)
                    curr->next->prev = curr->prev;
                
                if(curr->prev != NULL)
                    curr->prev->next = curr->next;
                res = (void *)curr->beg;
            }
            break;
        }
        curr = curr->next;
    }
    // If did not find usable block in free list
    if(res == NULL){
        
        meta_block * new_block = sbrk(0);
        if((void*)-1 == sbrk(META_SIZE + size))
        {
            return NULL;
        }
        
        total_allocate += (unsigned long)(META_SIZE + size);
        new_block->size = size;
        new_block->prev = NULL;
        new_block->next = NULL;
        res = (void *)new_block->beg;
    }
    return res;
    
}


void ff_free(void *ptr){
    if (ptr == NULL){
        return;
    }
    meta_block * to_free = (meta_block *)((char *)ptr - META_SIZE);
    to_free->next = NULL;
    to_free->prev = NULL;
    meta_block * curr = free_head;
    meta_block * prev = NULL;
  
    // Find the place we need to insert
    while ( curr != NULL && curr < to_free )
    {
        prev = curr;
        curr = curr->next;
    }
    
    // insert the newly freed block in free list
    if(prev == NULL){
        to_free->next = free_head;
        to_free->prev = NULL;
        if(free_head){
            free_head->prev = to_free;
        }
        free_head = to_free;
    }
    else{
        to_free->next = prev->next;
        prev->next = to_free;
        to_free->prev = prev;
        if(to_free->next != NULL){
            to_free->next->prev = to_free;
        }
    }
    
    // if have previous block
    if (to_free->prev != NULL)
    {
        merge_free(to_free->prev);
    }
    // else just check from current
    else{
        merge_free(to_free);
    }
}

// find the block with optimal size, if no usable space return NULL
meta_block *find_best_fit(size_t size){
    meta_block* curr = free_head;
    meta_block* res = NULL;
    size_t waste = INT_MAX;
    while (curr != NULL)
    {
        if (curr -> size >= size){
            if(curr->size - size < waste){
                waste = curr->size - size;
                res = curr;
            }
            if(waste == 0){
                break;
            }
        }
        curr = curr->next;
    }
    return res;
}

//Best Fit malloc/free
void *bf_malloc(size_t size){
    void * res = NULL;
    meta_block * curr = find_best_fit(size);
    if (curr != NULL)
    {
        // if space can be splitted
        if ( (curr->size) - size > META_SIZE)
        {
            curr->size = curr->size - size - META_SIZE;
            meta_block * new_block = (meta_block *)((char *)curr + curr->size + META_SIZE);
            new_block->size = size;
            new_block->next = NULL;
            new_block->prev = NULL;
            res = (void *)new_block->beg;
            
        } 
        // else if space can not be splitted
        else{
            if(free_head == curr)
                free_head = curr->next;
            
            if(curr->next != NULL)
                curr->next->prev = curr->prev;
            
            if(curr->prev != NULL)
                curr->prev->next = curr->next;
            res = (void *)curr->beg;
        }
    }
    // if can not find block in free list
    else{
        meta_block * new_block = sbrk(0);
        if((void*)-1 == sbrk(META_SIZE + size))
        {
            return NULL;
        }
        
        total_allocate += (unsigned long)(META_SIZE + size);
        new_block->size = size;
        new_block->prev = NULL;
        new_block->next = NULL;
        res = (void *)new_block->beg;
    }
    return res;
}

void bf_free(void *ptr){
    if (ptr == NULL){
        return;
    }
    meta_block * to_free = (meta_block *)((char *)ptr - META_SIZE);
    to_free->next = NULL;
    to_free->prev = NULL;
    meta_block * curr = free_head;
    meta_block * prev = NULL;
  
    // Find the place we need to insert
    while ( curr != NULL && curr < to_free )
    {
        prev = curr;
        curr = curr->next;
    }
    
    // insert the newly freed block in free list
    if(prev == NULL){
        to_free->next = free_head;
        to_free->prev = NULL;
        if(free_head){
            free_head->prev = to_free;
        }
        free_head = to_free;
    }
    else{
        to_free->next = prev->next;
        prev->next = to_free;
        to_free->prev = prev;
        if(to_free->next != NULL){
            to_free->next->prev = to_free;
        }
    }
    
    // if have previous block
    if (to_free->prev != NULL)
    {
        merge_free(to_free->prev);
    }
    // else just check from current
    else{
        merge_free(to_free);
    }
}

//entire heap memory (this includes memory used to save metadata)
unsigned long get_data_segment_size(){
    return total_allocate;
}

//size of the "free list" = (actual usable free space + space occupied by metadata) of the blocks in your free list
unsigned long get_data_segment_free_space_size(){
    unsigned long total_free = 0;
    meta_block * curr = free_head;
    while(curr!=NULL){
        total_free += ((unsigned long)curr->size + META_SIZE);
        curr=curr->next;
    }
    return total_free;
}

