#ifndef __MALLOC_H__
#define __MALLOC_H__

#define META_SIZE 24

typedef struct meta_block_ meta_block;

// The block store meta information
struct meta_block_
{
    size_t size;    //8 byte
    meta_block* next;   //8 byte
    meta_block* prev;   //8 byte
    char beg[1];    //The beginning of the data block
};

void merge_free(meta_block * curr);
void *ff_malloc(size_t size);
void ff_free(void *ptr);
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
#endif