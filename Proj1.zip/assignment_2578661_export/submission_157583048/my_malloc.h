#include <unistd.h>

typedef struct block
{
    size_t size;
    int free;
    struct block *prev;
    struct block *next;
} Block;


void* ff_malloc(size_t size);
void ff_free(void * ptr);

void * bf_malloc(size_t size);
void bf_free(void * ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

void my_insert(Block *bptr);
void my_remove(Block *bptr);

void *my_malloc(size_t size, int type);
Block *getmem(size_t size);

Block * ff_search(size_t size);
Block * bf_search(size_t size);

void split(Block *bptr, size_t size);
void merge(Block *bptr);
