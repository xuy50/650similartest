#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "my_malloc.h"

Block *head = NULL;
size_t heap_start = 0;
Block *tail = NULL;
int is_first_malloc = 1;

#define BLOCKSIZE sizeof(Block)
#define BLK_P(us_p) ((Block *)((char *)us_p - BLOCKSIZE))
#define US_P(Block_ptr) ((char *)Block_ptr + BLOCKSIZE)

unsigned long get_data_segment_size()
{
    return (size_t)sbrk(0) - heap_start;
}

unsigned long get_data_segment_free_space_size()
{
    Block *curr = head;
    size_t free_space = 0;
    while (curr != NULL)
    {
        free_space += curr->size + BLOCKSIZE;
        curr = curr->next;
    }
    return free_space;
}

void *ff_malloc(size_t size)
{
    return my_malloc(size, 1);
}

void *bf_malloc(size_t size) { return my_malloc(size, 0); }

void *my_malloc(size_t size, int type)
{
    Block *Block_ptr = NULL;
    if (head == NULL)
    {
        assert(tail == NULL);
        if (is_first_malloc)
        {
            heap_start = (size_t)sbrk(0);
            is_first_malloc = 0;
        }
        Block_ptr = getmem(size);
    }
    else
    {
        switch (type)
        {
        case 0: 
            Block_ptr = bf_search(size);
            break;
        case 1: 
            Block_ptr = ff_search(size);
            break;
        }
        if (Block_ptr == NULL)
        {
            Block_ptr = getmem(size);
        }
    }
    return US_P(Block_ptr);
}

Block *getmem(size_t size)
{
    Block *new_blk = sbrk(4 * (BLOCKSIZE + size));
    if (new_blk == (void *)-1)
    {
        return NULL;
    } 
    new_blk->size = 4 * (BLOCKSIZE + size) - BLOCKSIZE;
    new_blk->next = NULL;
    new_blk->prev = tail;
    tail = new_blk;
    if (head == NULL)
    {
        head = new_blk;
    }
    split(new_blk, size);

    return new_blk;
}

void my_remove(Block *Block_ptr)
{
    if (Block_ptr == NULL)
    {
        return;
    }
    if ((Block_ptr->next == NULL) && (Block_ptr->prev == NULL))
    {
        if (head == tail)
        {
            assert(Block_ptr == head);
            head = NULL;
            tail = NULL;
        }
    } 
    else if (head == Block_ptr)
    {
        assert(Block_ptr->prev == NULL);
        head = Block_ptr->next;
        head->prev = NULL;
    }
    else if (tail == Block_ptr)
    {
        assert(Block_ptr->next == NULL);
        tail = Block_ptr->prev;
        tail->next = NULL;
    }
    else
    {
        Block_ptr->prev->next = Block_ptr->next;
        Block_ptr->next->prev = Block_ptr->prev;
    }
    Block_ptr->prev = NULL;
    Block_ptr->next = NULL;
}

Block *ff_search(size_t size)
{
    Block *curr = head;
    while (curr != NULL)
    {
        if (curr->size >= size)
        {
            split(curr, size);
            return curr;
        }
        curr = curr->next;
    }
    return curr; 
}

Block *bf_search(size_t size)
{
    Block *bf_blk = NULL;
    size_t diff = 0;
    Block *curr = head;
    while (curr != NULL)
    {
        if (curr->size < size)
        {
            curr = curr->next;
            continue;
        }
        if (curr->size == size)
        {
            my_remove(curr);
            return curr;
        }
        if (curr->size > size)
        {
            size_t temp_diff = curr->size - size;
            if ((temp_diff < diff) || (bf_blk == NULL))
            {
                if (bf_blk == NULL)
                {
                    assert(diff == 0);
                }
                diff = temp_diff;
                bf_blk = curr;
            }
        }
        curr = curr->next;
    }
    split(bf_blk, size);
    return bf_blk;
}

void split(Block *start_ptr, size_t size)
{
    if ((start_ptr == NULL) || (start_ptr->size <= size + 2 * BLOCKSIZE))
    {
        my_remove(start_ptr);
        return;
    }
    Block *split_ptr = (Block *)((char *)start_ptr + BLOCKSIZE + size);

    split_ptr->next = NULL;
    split_ptr->prev = NULL;
    split_ptr->size = start_ptr->size - size - BLOCKSIZE;
    start_ptr->size = size;
    my_remove(start_ptr);
    my_insert(split_ptr);
}

void ff_free(void *us_p)
{                           
    my_insert(BLK_P(us_p)); 
    merge(BLK_P(us_p));
}

void bf_free(void *us_p)
{
    my_insert(BLK_P(us_p));
    merge(BLK_P(us_p));
}

void my_insert(Block *Block_ptr)
{
    if (head == NULL)
    {
        assert(tail == NULL);
        head = Block_ptr;
        tail = Block_ptr;
        assert(Block_ptr->next == NULL);
        assert(Block_ptr->prev == NULL);
        return;
    }
    else if (Block_ptr < head)
    {
        head->prev = Block_ptr;
        Block_ptr->next = head;
        head = Block_ptr;
        return;
    }
    else
    {
        Block *curr = head;

        while (curr != NULL)
        {
            if (curr < Block_ptr)
            {
                if (curr->next == NULL)
                {
                    curr->next = Block_ptr;
                    Block_ptr->prev = curr;
                    assert(Block_ptr->next == NULL);
                    tail = Block_ptr;
                    return;
                }
                else if (curr->next > Block_ptr)
                {
                    Block_ptr->next = curr->next;
                    Block_ptr->prev = curr;
                    curr->next->prev = Block_ptr;
                    curr->next = Block_ptr;
                    return;
                }
                else
                {
                    curr = curr->next;
                }
            }
        } 
    }
}

void merge(Block *Block_ptr)
{
    if (Block_ptr->prev == NULL)
    {
        assert(Block_ptr == head);
    }
    else
    {
        if (Block_ptr ==
            (Block *)((char *)US_P(Block_ptr->prev) + Block_ptr->prev->size))
        {
            Block_ptr->prev->size = Block_ptr->prev->size + BLOCKSIZE + Block_ptr->size;
            Block_ptr->prev->next = Block_ptr->next;
            if (Block_ptr->next != NULL)
            {
                Block_ptr->next->prev = Block_ptr->prev;
            }
            Block_ptr->size = 0;
            if (tail == Block_ptr)
            {
                assert(Block_ptr->next == NULL);
                tail = Block_ptr->prev;
            }
            Block_ptr = Block_ptr->prev;
        }
    }

    if (Block_ptr->next == NULL)
    {
        assert(Block_ptr == tail);
    }
    else
    {
        if (Block_ptr->next == (Block *)((char *)US_P(Block_ptr) + Block_ptr->size))
        {
            Block_ptr->size = Block_ptr->size + BLOCKSIZE + Block_ptr->next->size;
            if (Block_ptr->next == tail)
            {
                assert(Block_ptr->next->next == NULL);
                tail = Block_ptr;
            }
            Block_ptr->next = Block_ptr->next->next;
            if (Block_ptr->next != NULL)
            {
                Block_ptr->next->prev = Block_ptr;
            }
        }
    }
}
