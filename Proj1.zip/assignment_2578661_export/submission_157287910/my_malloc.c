#include "my_malloc.h"
size_t entire_size = 0;
// If no available free space, creat new space by sbrk
void *creat_space(size_t size) {
  Node *meta = sbrk(meta_size);
  void *res = sbrk(size);
  entire_size += (meta_size + size);
  if (meta == (void *)-1 || res == (void *)-1) {
    return NULL;
  }
  meta->size = size;
  meta->next = NULL;
  return res;
}
// If free space available, use that space
void *use_free_space(Node *curr, size_t size) {
  Node *ptr = curr->next;
  if (ptr->size - size <= meta_size) {
    // if left space is too small to place an another meta data
    // give all the space to this malloc
    curr->next = ptr->next;
  } else {
    // give left space back to the linked list
    Node *new_ptr = (Node *)((char *)ptr + meta_size + size);
    new_ptr->size = ptr->size - size - meta_size;
    new_ptr->next = ptr->next;
    curr->next = new_ptr;

    ptr->size = size;
  }
  ptr->next = NULL;
  return (char *)ptr + meta_size;
}
// Initialize head to point to a node to avoid dealing with speciality of head
void *initial_head() {
  global_head = sbrk(meta_size);
  entire_size += meta_size;
  if (global_head == (void *)-1) {
    return NULL;
  }
  global_head->size = 0;
  global_head->next = NULL;
  return global_head;
}
// First Fit malloc
void *ff_malloc(size_t size) {
  if (size == 0) {
    return NULL;
  }
  // initialize head node
  if (global_head == NULL) {
    if (initial_head() == NULL) {
      return NULL;
    }
  }
  Node *curr = global_head;
  while (curr->next != NULL) {
    Node *ptr = curr->next;
    if (ptr->size >= size) {
      return use_free_space(curr, size);
    }
    curr = curr->next;
  }
  return creat_space(size);
}
// Free block in the middle of linked list
void free_middle_block(Node *curr, Node *last, Node *p) {
  if (curr->size != 0 && (char *)curr + meta_size + curr->size == (char *)p) {
    // merge this block with previous block
    curr->size += (p->size + meta_size);
    if ((char *)curr + meta_size + curr->size == (char *)last) {
      // merge this block with last block
      curr->size += (last->size + meta_size);
      curr->next = last->next;
    }
  } else if ((char *)p + meta_size + p->size == (char *)last) {
    // merge this block with last block
    p->size += (last->size + meta_size);
    p->next = last->next;
    curr->next = p;
  } else {
    // don't need to merge
    p->next = last;
    curr->next = p;
  }
}
// Free block in the last of linked list
void free_last_block(Node *curr, Node *p) {
  if (curr->size != 0 && (char *)curr + meta_size + curr->size == (char *)p) {
    // merge this block with previous block
    curr->size += (p->size + meta_size);
  } else {
    // don't need to merge
    p->next = NULL;
    curr->next = p;
  }
}
// First Fit free
void ff_free(void *ptr) {
  if (ptr == NULL)
    return;
  Node *p = (Node *)((char *)ptr - meta_size);
  Node *curr = global_head;
  // find previous free block to add this block in the linked list
  while (curr->next != NULL) {
    Node *last = curr->next;
    if (p >= curr && p <= last) {
      free_middle_block(curr, last, p);
      return;
    }
    curr = curr->next;
  }
  free_last_block(curr, p);
}
// Best Fit malloc
void *bf_malloc(size_t size) {
  if (size == 0) {
    return NULL;
  }
  // initialize head node
  if (global_head == NULL) {
    if (initial_head() == NULL) {
      return NULL;
    }
  }
  Node *ans = NULL; // the best block to malloc
  size_t min = 0;   // remaining space after malloc
  Node *curr = global_head;
  while (curr->next != NULL) {
    Node *ptr = curr->next;
    if (ptr->size >= size) {
      if (ptr->size == size) {
        // if block size is equal to this block, then malloc directly
        return use_free_space(curr, size);
      }
      if (ans == NULL || ptr->size - size <= min) {
        // update the block when needed
        min = ptr->size - size;
        ans = curr;
      }
    }
    curr = curr->next;
  }
  if (ans == NULL) {
    // if no useful space, create new space
    return creat_space(size);
  } else {
    return use_free_space(ans, size);
  }
}
void bf_free(void *ptr) { ff_free(ptr); }
unsigned long get_data_segment_size() { return entire_size; }
unsigned long get_data_segment_free_space_size() {
  unsigned long ans = 0;
  Node *curr = global_head;
  while (curr != NULL) {
    ans += (meta_size + curr->size);
    curr = curr->next;
  }
  return ans;
}
