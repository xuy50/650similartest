#include <stdlib.h>
#include <unistd.h>
// struct of meta data
typedef struct _Node {
  size_t size;
  struct _Node *next;
} Node;
#define meta_size sizeof(Node) // size of meta data
Node *global_head = NULL;      // head of linked list of free spaces
// First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
// Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();            // in bytes
unsigned long get_data_segment_free_space_size(); // in byte
