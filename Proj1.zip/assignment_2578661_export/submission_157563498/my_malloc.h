#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// each node in the linked list 
struct md_node {
    size_t sz;
    struct md_node * prev;
    struct md_node * next;
};
typedef struct md_node md;

#define MD_SZ sizeof(md)

// initialize variables
md * mlist = NULL;
unsigned long data_seg_sz = 0;
unsigned long data_seg_free_sz = 0;

// function prototypes
void add_to_list(md * mnode);
void remove_from_list(md * mnode);
void * get_new_mem(size_t sz);
void split_mem(md * mnode, size_t sz);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

// First Fit
void * ff_malloc(size_t sz);
void ff_free(void * ptr);
// Best Fit
void * bf_malloc(size_t sz);
void bf_free(void * ptr);