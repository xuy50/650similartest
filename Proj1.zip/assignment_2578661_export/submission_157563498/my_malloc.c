#include "my_malloc.h"


unsigned long get_data_segment_size() {
    return data_seg_sz + data_seg_free_sz;
}

unsigned long get_data_segment_free_space_size() {
    return data_seg_free_sz;
}

void * get_new_mem(size_t sz) {
    size_t data_sz = MD_SZ + sz;
    void * ptr = sbrk(data_sz);
    md * tp = ptr;
    tp->sz = sz;
    tp->prev = NULL;
    tp->next = NULL;
    data_seg_sz += data_sz;
    return (char*)ptr + MD_SZ;
}

void add_to_list(md * mnode) {
    if (mlist == NULL) {
        mlist = mnode;
        data_seg_sz -= (MD_SZ + mnode->sz);
        data_seg_free_sz += (MD_SZ + mnode->sz);
        return;
    }

    // insert the freed node to the free list
    // the address is sorted in ascending order
    md * cur = mlist;
    while (cur != NULL) {
        md * prev = cur->prev;
        if (prev != NULL && (char*)prev < (char*)mnode && (char*)mnode < (char*)cur) {
            // insert between prev and cur
            prev->next = mnode;
            cur->prev = mnode;
            mnode->prev = prev;
            mnode->next = cur;
            break;
        }
        else if (prev == NULL && (char*)mnode < (char*)cur) {
            // insert to the beginning
            cur->prev = mnode;
            mlist = mnode;
            mnode->next = cur;
            mnode->prev = NULL;
            break;
        }
        else if (cur->next == NULL) {
            // insert to the end
            cur->next = mnode;
            mnode->prev = cur;
            mnode->next = NULL;
            break;
        }
        cur = cur->next;
    }

    // need to keep track of the original mnode_sz as we update it when merging is needed
    size_t mnode_sz = mnode->sz;

    // check if need to merge with block after
    if (mnode->next != NULL && (char*)(mnode->next) == (char*)mnode + MD_SZ + mnode->sz) {
        mnode->sz += MD_SZ + mnode->next->sz;
        mnode->next = mnode->next->next;
        if (mnode->next != NULL) {
            mnode->next->prev = mnode;
        }
    }

    // check if need to merge with block front
    if (mnode->prev != NULL && (char*)(mnode->prev) + mnode->prev->sz + MD_SZ == (char*)mnode) {
        mnode->prev->sz += MD_SZ + mnode->sz;
        mnode->prev->next = mnode->next;
        if (mnode->next != NULL) {
            mnode->next->prev = mnode->prev;
        }
    }

    data_seg_sz -= MD_SZ + mnode_sz;
    data_seg_free_sz += MD_SZ + mnode_sz;
    return;
}

void remove_from_list(md * mnode) {
    if (mnode == mlist) {
        //remove head from the list
        mlist = mnode->next;
        if (mlist != NULL) {
            mlist->prev = NULL;
        }
    }
    else if (mnode->next == NULL) {
        // remove tail from the list
        mnode->prev->next = NULL;
    }
    else {
        // remove in the middle (between head and tail)
        mnode->prev->next = mnode->next;
        mnode->next->prev = mnode->prev;
    }

    // set mnode to be independent
    mnode->prev = NULL;
    mnode->next = NULL;
    data_seg_sz += (MD_SZ + mnode->sz);
    data_seg_free_sz -= (MD_SZ + mnode->sz);
}

void split_mem(md * mnode, size_t sz) {
    md * new_mnode = (md*)((char*)mnode + MD_SZ + sz);
    new_mnode->sz = mnode->sz - MD_SZ - sz;
    new_mnode->prev = mnode;
    new_mnode->next = mnode->next;
    if (mnode->next != NULL) {
        mnode->next->prev = new_mnode;
    }
    mnode->next = new_mnode;
    mnode->sz = sz;   
}

void * ff_malloc(size_t sz) {
    md * cur = mlist;
    while (cur != NULL) {
        if (cur->sz >= sz) {
            break;
        }
        cur = cur->next;
    }

    if (cur == NULL) {
        return get_new_mem(sz);
    }

    if (cur->sz > sz + MD_SZ) {
        split_mem(cur, sz);
    }

    remove_from_list(cur);
    return (char*)cur + MD_SZ;
}

void ff_free(void * ptr) {
    md * mnode = (md*)((char*)ptr - MD_SZ);
    add_to_list(mnode);
}

void * bf_malloc(size_t sz) {
    md * cur = mlist;
    md * res = NULL;
    while (cur != NULL) {
        if (cur->sz == sz) {
            res = cur;
            remove_from_list(res);
            return (char*)res + MD_SZ;
        }
        else if (cur->sz > sz && res == NULL) {
            res = cur;
        }
        else if (cur->sz > sz && res != NULL && cur->sz < res->sz) {
            res = cur;
        }
        cur = cur->next;
    }

    if (res == NULL) {
        return get_new_mem(sz);
    }

    if (res->sz > sz + MD_SZ) {
        split_mem(res, sz);
    }
    remove_from_list(res);
    return (char*)res + MD_SZ;
}

void bf_free(void * ptr) {
    md * mnode = (md*)((char*)ptr - MD_SZ);
    add_to_list(mnode);
}