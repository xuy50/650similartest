#include <stdio.h>
#include <stdlib.h>

struct _meta {
    struct _meta * prev;
    struct _meta * next;
    size_t size;
};
typedef struct _meta meta;

void * ff_malloc(size_t required_size);
void * split(meta * p, size_t required_size);
void add_block(meta * p);
void remove_block(meta * p);
void ff_free(void * p);
void merge_back(meta * freed_block);
void merge_front(meta * freed_block);
// void print_free_list();
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void * bf_malloc(size_t required_size);
void bf_free(void * p);
