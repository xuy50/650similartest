#include "my_malloc.h"

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

meta * free_head = NULL;

size_t allocated_size = 0;
//size_t freed_size = 0;

void * ff_malloc(size_t required_size) {
    if (required_size < 0) {
        return NULL;
    }
    meta * ans;
    int found_block = 0;
    
    if (free_head != NULL) {
        meta * p = free_head;
        while (p) {
            if (p->size >= required_size) {
                ans = split(p, required_size);
                // remove_block(p);
                found_block = 1;
                break;
                //return split(p, required_size);
            }
            p = p->next;
        }
    }

    if (!found_block) {
        allocated_size = allocated_size + required_size + sizeof(meta);
        meta * request_block = sbrk(required_size + sizeof(meta));
        request_block->size = required_size;
        //request_block->prev = NULL;
        request_block->prev = NULL;
        request_block->next = NULL;
        ans = (meta *)((char *)request_block + sizeof(meta));
        //printf("allocated_block: %p, size = %lu\n", request_block, request_block->size);
    }

    return ans;
}

void * split(meta * p, size_t required_size) {
    if (p->size >= required_size + sizeof(meta)) {
        meta * sub_block = (meta *)((char *)p + required_size + sizeof(meta));
        sub_block->size = p->size - required_size - sizeof(meta);
        //sub_block->prev = NULL;
        sub_block->next = NULL;
        sub_block->prev = NULL;
        // p->size = required_size;
        // freed_size = freed_size - required_size - sizeof(meta);
        //p->prev = NULL;
        //p->next = NULL;

        remove_block(p);
        // p->prev = NULL;
        // p->next = NULL;
        add_block(sub_block);
        p->size = required_size;
        //freed_size = freed_size - required_size - sizeof(meta);
        //printf("sub_block: %p, size = %lu\n", sub_block, sub_block->size);
        //remove_block(p);

        return (char *)p + sizeof(meta);
    }
    //freed_size = freed_size - p->size - sizeof(meta);
    remove_block(p);
    p->size = required_size;
    p->prev = NULL;
    p->next = NULL;
    return (char *)p + sizeof(meta);
}

void add_block(meta * p) {
    if (free_head == NULL) {
        p->prev = NULL;
        p->next = free_head;
        if (p->next != NULL) {
            p->next->prev = p;
        }
        free_head = p;
        //free_tail = p;
    }
    else if (p < free_head) {
        p->prev = NULL;
        p->next = free_head;
        if (p->next != NULL) {
            p->next->prev = p;
        }
        //p->next->prev = p;
        free_head = p;
    }
    else {
        meta * curr_block = free_head;
        while ((curr_block->next != NULL) && (curr_block->next < p)) {
            curr_block = curr_block->next;
            //printf("block not found, find next\n");
        }
        p->prev = curr_block;
        p->next = curr_block->next;
        if (p->next != NULL) {
            p->next->prev = p;
        }
        curr_block->next = p;
        //p->prev = curr_block;
    }
}

void remove_block(meta * p) {
    if (p == free_head) {
        free_head = p->next;
        if (free_head != NULL) {
            free_head->prev = NULL;
        }
        p->next = NULL;
        p->prev = NULL;
    }
    else {
        p->prev->next = p->next;
        if (p->next != NULL) {
            p->next->prev = p->prev;
        }
        p->next = NULL;
        p->prev = NULL;
    }
    //p->next = NULL;
}

void ff_free(void * p) {
    //printf("a");
    meta * freed_block = (meta *)((char *)p - sizeof(meta));
    //printf("b");
    freed_block->next = NULL;
    add_block(freed_block);
    //printf("freed_block: %p, size = %lu\n", freed_block, freed_block->size);
    //printf("c");
    //freed_size = freed_size + freed_block->size + sizeof(meta);
    merge_back(freed_block);
    //printf("d");
    merge_front(freed_block);
    //printf("e ");
}

void merge_back(meta * freed_block) {
    if (freed_block->next && ((meta *)((char *)freed_block + freed_block->size + sizeof(meta)) == freed_block->next)) {
        freed_block->size = freed_block->size + freed_block->next->size + sizeof(meta);
        remove_block(freed_block->next);
    }
    //printf("-1");
}

void merge_front(meta * freed_block) {
    if (freed_block == free_head) {
        return;
    }
    if ((freed_block->prev != NULL) && ((meta *)((char *)freed_block->prev + freed_block->prev->size + sizeof(meta)) == freed_block)) {
        freed_block->prev->size = freed_block->prev->size + freed_block->size + sizeof(meta);
        remove_block(freed_block);
    }
}

unsigned long get_data_segment_size() {
    return allocated_size;
}

unsigned long get_data_segment_free_space_size() {
    meta * curr = free_head;
    unsigned long ans = 0;
    while (curr) {
        ans += (sizeof(meta) + curr->size);
        curr = curr->next;
    }
    return ans;
}

// void print_free_list() {
//     meta * curr = free_head;
//     //printf("error");
//     if (!curr) {
//         return;
//     }
//     while (curr) {
//         printf("address: %p, size: %lu", curr, curr->size);
//         curr = curr->next;
//         //printf("not found, find next");
//     }
// }

void * bf_malloc(size_t required_size) {
    if (required_size < 0) {
        return NULL;
    }
    meta * ans;
    meta * bf_block = NULL;
    
    if (free_head != NULL) {
        meta * p = free_head;
        while (p) {
            if (p->size >= required_size) {
                if (!bf_block || p->size < bf_block->size) {
                    bf_block = p;
                    if (p->size == required_size) {
                        break;
                    }
                    //printf("new found block: %p, size = %lu\n", bf_block, bf_block->size);
                }
            }
            p = p->next;
        }
    }

    if (bf_block != NULL) {
        ans = split(bf_block, required_size);
    }
    else {
        allocated_size = allocated_size + required_size + sizeof(meta);
        meta * request_block = sbrk(required_size + sizeof(meta));
        request_block->size = required_size;
        request_block->prev = NULL;
        request_block->next = NULL;
        ans = (meta *)((char *)request_block + sizeof(meta));
        //printf("allocated_block: %p, size = %lu\n", request_block, request_block->size);
    }

    return ans;
}

void bf_free(void * p) {
    return ff_free(p);
}