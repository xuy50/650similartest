#ifndef MY_MALLOC_H
#define MY_MALLOC_H

#include <stdio.h>
#include <stdlib.h>

// Metadata Details
typedef struct metadata_t {
  size_t size;               // size of block not including metadata
  int isFree;                // 1 for free, 0 for not
  struct metadata_t * next;  // next free block
} metadata;
size_t METADATA_SIZE = sizeof(metadata);
metadata * ROOT_FREE = NULL;

// Utility Functions
metadata * get_prev_free(metadata * addr);
//    - return previous node in free linked list
void remove_free_block(metadata * addr);
//    - remove from free linked list
//    - update metadata and global variables
void split_block(metadata * addr, size_t size);
//    - create a new metadata at the end of the first block
//    - insert this new block into the free linked list
void allocate_used(metadata * addr, size_t size);
//    - make a new metadata for leftover space,
//    - update ROOT_FREE if necessary
metadata * new_data(size_t size);
//    - use sbrk to get extra space
//    - write metadata and return metadata address
metadata * get_next_meta_block(metadata * addr);
//    - find the end of the block based on size and METADATA_SIZE
//    - return the next block if it exists
int check_merge(metadata * left, metadata * right);
//    - return 1 if they are adjacent and ready to merge
//    - return 0 if they are not
void merge(metadata * left, metadata * right);
//    - merge adjacent memory regions
void insert_free_block(metadata * addr);
//    - place in linked list according to memory address
//    - merge adjacent free memory blocks
void allocate_free(metadata * addr);
//    - set isFree
//    - if isFree was already set, return
//    - otherwise, insert into free list

// First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);
metadata * ff_find(size_t size);
//    - search for free space using first fit
//    - return NULL if cannot find

// Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);
metadata * bf_find(size_t size);
//    - search for free space using best fit
//    - return NULL if cannot find

// Testing and Reporting Functions
unsigned long get_data_segment_size();             //in bytes
unsigned long get_data_segment_free_space_size();  //in byte
size_t DATA_SIZE = 0;
size_t FREE_SIZE = 0;

#endif
