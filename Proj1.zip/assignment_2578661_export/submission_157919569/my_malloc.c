#include "my_malloc.h"

//#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// GENERAL UTILITY
metadata * get_prev(metadata * addr) {
  //  assert(addr->isFree);
  metadata * cur = ROOT_FREE;
  if (cur == NULL || cur == addr) {
    return NULL;
  }
  // find the previous node
  while (cur->next != NULL) {
    if (cur->next == addr) {
      return cur;
    }
    cur = cur->next;
  }
  return NULL;
}

void remove_free_block(metadata * addr) {
  //  assert(addr->isFree);
  metadata * prev = get_prev(addr);
  if (prev) {
    //    assert(prev->next == addr);
    //    assert(addr->next != prev);
    prev->next = addr->next;
  }
  else {
    //    assert(ROOT_FREE == addr);
    ROOT_FREE = addr->next;
  }
  addr->next = NULL;
  addr->isFree = 0;
  FREE_SIZE -= addr->size + METADATA_SIZE;
}

void split_block(metadata * addr, size_t size) {
  size_t right_size = addr->size - size - METADATA_SIZE;
  addr->size = size;  // left size
  metadata * new_free_space = get_next_meta_block(addr);
  new_free_space->size = right_size;
  new_free_space->isFree = 1;
  new_free_space->next = addr->next;
  addr->next = new_free_space;
  remove_free_block(addr);
}

void allocate_used(metadata * addr, size_t size) {
  //  assert(addr->size >= size);
  //  assert(addr->isFree);
  metadata * prev = get_prev(addr);
  // if it fits
  if (addr->size <= (size + METADATA_SIZE)) {
    remove_free_block(addr);
  }
  // otherwise, split off a new free space
  else {
    split_block(addr, size);
  }
}

metadata * new_data(size_t size) {
  void * new_ptr = sbrk(size + METADATA_SIZE);
  //  assert(new_ptr != (void *)-1);
  metadata * new_meta = new_ptr;
  new_meta->size = size;
  new_meta->isFree = 0;
  new_meta->next = NULL;
  DATA_SIZE += size + METADATA_SIZE;
  return new_meta;
}

metadata * get_next_meta_block(metadata * addr) {
  metadata * end_of_heap = (metadata *)sbrk(0);
  metadata * next_block = (metadata *)((char *)(addr + 1) + addr->size);
  if (next_block != end_of_heap) {
    return next_block;
  }
  return NULL;
}

int check_merge(metadata * left, metadata * right) {
  return get_next_meta_block(left) == right;
}

void merge(metadata * left, metadata * right) {
  //  assert(left->isFree);
  //  assert(right->isFree);
  //  assert(get_next_meta_block(left) == right);
  //  assert(left->next == right);
  left->size += right->size + METADATA_SIZE;
  left->next = right->next;
}

void insert_free_block(metadata * addr) {
  //  assert(addr->isFree);
  //  assert(addr->next == NULL);
  FREE_SIZE += addr->size + METADATA_SIZE;
  // if first free block
  if (ROOT_FREE == NULL) {
    //    assert(FREE_SIZE == addr->size + METADATA_SIZE);
    ROOT_FREE = addr;
    return;
  }
  // otherwise, insert and merge
  //  assert(FREE_SIZE > 0);
  // start of the list
  if (addr < ROOT_FREE) {
    metadata * old_root = ROOT_FREE;
    ROOT_FREE = addr;
    addr->next = old_root;
    if (check_merge(addr, old_root)) {
      merge(addr, old_root);
    }
    return;
  }
  // iterate and insert
  metadata * cur = ROOT_FREE;
  while ((cur->next != NULL) && (cur->next < addr)) {
    cur = cur->next;
  }
  //  assert(cur < addr);
  // end of the list
  if (cur->next == NULL) {
    cur->next = addr;
    if (check_merge(cur, cur->next)) {
      merge(cur, cur->next);
    }
    return;
  }
  // middle of the list
  //  assert((cur->next > addr));
  addr->next = cur->next;
  cur->next = addr;
  if (check_merge(cur, cur->next)) {
    merge(cur, cur->next);
    if (check_merge(cur, cur->next)) {
      merge(cur, cur->next);
    }
  }
  else if (check_merge(addr, addr->next)) {
    merge(addr, addr->next);
  }
  return;
}

void allocate_free(metadata * addr) {
  if (addr == NULL || addr->isFree) {
    return;
  }
  addr->isFree = 1;
  insert_free_block(addr);
}

// FIRST FIT
// malloc will:
//    1) check the list for free space using first fit
//       if found:
//          1) allocate the data as used in the list
//          2) decrease free_size by size and metadata
//       if not:
//          1) use sbrk(size + metadata)
//          2) increase data_size by size and metadata
//    2) return the start address (after metadata)
void * ff_malloc(size_t size) {
  metadata * space = ff_find(size);
  if (space == NULL) {
    space = new_data(size);
  }
  else {
    allocate_used(space, size);
  }
  return (void *)(space + 1);
}

// free will:
//    1) allocate a segment as free including metadata in list
//    2) increase free_size accordingly
//    3) merge adjacent free memory blocks
void ff_free(void * ptr) {
  metadata * p = ptr;
  allocate_free(p - 1);
}

metadata * ff_find(size_t size) {
  if (ROOT_FREE == NULL) {
    return NULL;
  }
  metadata * cur = ROOT_FREE;
  // find the block larger or equal to size
  while (cur->size < size) {
    cur = cur->next;
    if (cur == NULL) {
      return NULL;
    }
  }
  return cur;
}

// BEST FIT
void * bf_malloc(size_t size) {
  metadata * space = bf_find(size);
  if (space == NULL) {
    space = new_data(size);
  }
  else {
    allocate_used(space, size);
  }
  return (space + 1);
}

void bf_free(void * ptr) {
  metadata * p = ptr;
  allocate_free(p - 1);
}

metadata * bf_find(size_t size) {
  if (ROOT_FREE == NULL) {
    return NULL;
  }
  metadata * cur = ROOT_FREE;
  metadata * best = NULL;
  while (cur != NULL) {
    if (cur->size == size) {
      return cur;
    }
    if (cur->size > size) {
      if (best == NULL) {
        best = cur;
      }
      if (best->size > cur->size) {
        best = cur;
      }
    }
    cur = cur->next;
  }
  return best;
}

// REPORTING
unsigned long get_data_segment_size() {
  return DATA_SIZE;
}
unsigned long get_data_segment_free_space_size() {
  return FREE_SIZE;
}
/*
int main() {
  size_t size = 8;

  // test ff_malloc
  void * start_val = sbrk(0);

  // my malloc
  //  void * addr = ff_malloc(size);
  //  void * md = (void *)((metadata *)addr - 1);

  // pure sbrk
  void * md = sbrk(size + METADATA_SIZE);
  void * addr = (void *)((char *)md + METADATA_SIZE);

  void * end_val = sbrk(0);
  void * next_blk = get_next_meta_block(md);
  printf("sbrk(0):\t%p\n", start_val);
  printf("metadata:\t%p\n", md);
  printf("addr:\t\t%p\n", addr);
  printf("sbrk(0):\t%p\n", end_val);
  printf("next_blk:\t%p\n", next_blk);

  // my malloc
  //  void * addr2 = ff_malloc(size);
  //  void * md2 = (void *)((metadata *)addr2 - 1);

  // pure sbrk
  void * md2 = sbrk(size + METADATA_SIZE);
  void * addr2 = (void *)((char *)md2 + METADATA_SIZE);

  //  void * next_blk1 = get_next_meta_block(md);
  //  void * next_blk2 = get_next_meta_block(md2);
  printf("metadata2:\t%p\n", md2);
  printf("addr2:\t\t%p\n", addr2);
  printf("sbrk(0):\t%p\n", sbrk(0));
  //  printf("next_blk1:\t%p\n", next_blk1);
  //  printf("next_blk2:\t%p\n", next_blk2);

  printf("Success!\n");
}
*/
