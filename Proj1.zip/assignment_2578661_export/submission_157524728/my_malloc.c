#include "my_malloc.h"

//create first block for linked list
metadata * first_block = NULL;
//size of the free list
unsigned long free_space_size = 0;
//size of the heap
unsigned long data_segment_size = 0;

void print_ll() {
  metadata * current_block = first_block;

  //  printf("size of metadata: %lu, ", sizeof(metadata));
  printf("   Printing linked list...\n");
  if (first_block == NULL) {
    printf("Linked List is empty.\n");
  }
  while (current_block != NULL) {
    printf("block->size: %lu, address: %p\n", current_block->size, current_block);
    current_block = current_block->next;
  }
}

void * ff_malloc(size_t size) {
  /*
    find the first block in the linked list that is available to take the user's request
       if there is no block to hold the user's request call sbrk()
       if there is a block with enough size...
          if the block is exactly equal to the user's request, remove block
          if the block is more than what they user requested, split the block
   */

  if (first_block == NULL) {
    metadata * first_all_block = sbrk(size + sizeof(metadata));
    first_all_block->size = size + sizeof(metadata);
    //adding to the data_segment_size
    data_segment_size += first_all_block->size;
    return (metadata *)((char *)first_all_block + sizeof(metadata));
  }

  metadata * current_block = first_block;
  while (current_block != NULL) {
    if (current_block->size >= size + sizeof(metadata)) {
      if (current_block->size <= size + 2 * sizeof(metadata)) {
        remove_block(current_block);
        return (metadata *)((char *)current_block + sizeof(metadata));
      }
      else {
        return split_block(current_block, size);
      }
    }
    current_block = current_block->next;
  }

  //there isn't any space in the free list to satisfy the user's request
  metadata * first_all_block = sbrk(size + sizeof(metadata));
  first_all_block->size = size + sizeof(metadata);
  //adding to the data_segment_size
  data_segment_size += first_all_block->size;
  return (metadata *)((char *)first_all_block + sizeof(metadata));
}

void ff_free(void * ptr) {
  /*
    create a metadata block and add it to the linked list
    update the size of the free list
    check if there is any memory to coalesce
       if so, coalesce 
   */
  metadata * free_block = (metadata *)((char *)ptr - sizeof(metadata));
  // free_space_size += free_block;
  add_block(free_block);

  //check if to the right and to the left should be coalesced
  //coalesce by adding the sizes, and making sure the pointers are correct
  metadata * temp = free_block->previous;
  metadata * temp2 = free_block->next;

  //block to the left
  if (temp != NULL && (char *)temp + temp->size == (char *)free_block) {
    temp->size += free_block->size;
    // temp->next = free_block->next;
    // free_block->previous = temp->previous;
    remove_block(free_block);
  }

  //block to the right
  if (temp2 != NULL && (char *)free_block + free_block->size == (char *)temp2) {
    free_block->size += temp2->size;
    //    free_block->next = temp2->next;
    // temp2->previous = free_block->previous;
    remove_block(temp2);
  }
}

void * bf_malloc(size_t size) {
  /*
    find the best block in the linked list that is available to take the user's request
       if there is no block to hold the user's request call sbrk()
       if there is a block with enough size...
          if the block is exactly equal to the user's request, remove block
          if the block is more than what they user requested, split the block
   */
  if (first_block == NULL) {
    metadata * first_all_block = sbrk(size + sizeof(metadata));
    first_all_block->size = size + sizeof(metadata);
    //adding to the data_segment_size
    data_segment_size += first_all_block->size;
    return (metadata *)((char *)first_all_block + sizeof(metadata));
  }

  metadata * current_block = first_block;
  //metadata block to be used to find the best of the list
  metadata * best_block = NULL;
  while (current_block != NULL) {
    if (current_block->size >= size + sizeof(metadata)) {
      //if it's exactly equal to what we need, this is the best fit
      if (current_block->size <= size + 2 * sizeof(metadata)) {
        remove_block(current_block);
        return (metadata *)((char *)current_block + sizeof(metadata));
      }
      else {
        //add some functionality here where it checks for the best fit
        if (best_block == NULL || current_block->size < best_block->size) {
          best_block = current_block;
        }
        // return split_block(current_block, size);
      }
    }
    current_block = current_block->next;
  }

  //enough space found to satisfy the user's request
  if (best_block != NULL) {
    return split_block(best_block, size);
  }

  //there isn't any space in the free list to satisfy the user's request
  metadata * first_all_block = sbrk(size + sizeof(metadata));
  first_all_block->size = size + sizeof(metadata);
  //adding to the data_segment_size
  data_segment_size += first_all_block->size;
  return (metadata *)((char *)first_all_block + sizeof(metadata));
}

void bf_free(void * ptr) {
  /*
    this function is exactly the same as ff_free
   */
  ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return data_segment_size;
}

unsigned long get_data_segment_free_space_size() {
  metadata * current_block = first_block;
  while (current_block != NULL) {
    free_space_size += current_block->size;
    current_block = current_block->next;
  }

  return free_space_size;
}

void add_block(metadata * data) {
  /*
    implementing free list as addressing ascending order
    1. check if the block being added, is the first on in the list
    2. else, find where in the list the newly freed block should be added
    3. once found, add it
   */

  if (first_block == NULL) {
    first_block = data;
    first_block->previous = NULL;
    first_block->next = NULL;
    return;
  }

  metadata * current_block = first_block;
  while (current_block != NULL) {
    if (current_block > data) {
      //adding at the front of the list
      if (current_block->previous == NULL) {
        data->previous = NULL;
        data->next = current_block;
        current_block->previous = data;
        first_block = data;
        return;
      }
      //adding in the middle of the list
      else {
        data->next = current_block;
        data->previous = current_block->previous;
        metadata * temp = current_block->previous;
        temp->next = data;
        current_block->previous = data;
        return;
      }
    }
    current_block = current_block->next;
  }

  //adding at the tail of the list
  metadata * current_block2 = first_block;
  while (current_block2->next != NULL) {
    current_block2 = current_block2->next;
  }

  current_block2->next = data;
  data->previous = current_block2;
  data->next = NULL;
  return;
}

void remove_block(metadata * data) {
  metadata * current_block = data;

  //if the data to be deleted is the first and only block in the free list
  if (current_block->previous == NULL && current_block->next == NULL) {
    first_block = NULL;
  }
  //if the data to be deleted is the first block in the free list
  else if (current_block == first_block) {
    first_block = first_block->next;
    first_block->previous = NULL;
  }
  //if the data to be deleted is at the end of the free list
  else if (current_block->next == NULL) {
    current_block = current_block->previous;
    current_block->next = NULL;
  }
  //if the data to be deleted is in the middle of the free list
  else {
    current_block->previous->next = current_block->next;
    current_block->next->previous = current_block->previous;
  }
}

void * split_block(metadata * data, size_t size) {
  /* 
     1. create new block 
     2. remove old block
     3. add new block
     4. make sure pointers are correct
   */

  metadata * new_block = (metadata *)((char *)data + sizeof(metadata) + size);
  new_block->size = data->size - sizeof(metadata) - size;

  remove_block(data);
  add_block(new_block);

  data->size = size + sizeof(metadata);
  data->next = NULL;
  data->previous = NULL;

  return (metadata *)((char *)data + sizeof(metadata));
}
