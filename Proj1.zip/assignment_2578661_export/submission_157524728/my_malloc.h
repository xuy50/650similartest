#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//struct to hold metadata for program
typedef struct metadata_tag {
  //how much is free (bytes)
  size_t size;
  //pointers to reference the previous and next metadata block
  struct metadata_tag * previous;
  struct metadata_tag * next;
} metadata;

//functions for first fit
void * ff_malloc(size_t size);
void ff_free(void * ptr);
//functions for best fit
void * bf_malloc(size_t size);
void bf_free(void * ptr);
//additional functions
unsigned long get_data_segment_size();
unsigned long get_data_free_segment_size();
void add_block(metadata * data);
void remove_block(metadata * data);
void * split_block(metadata * data, size_t user_request);
void print_ll();
