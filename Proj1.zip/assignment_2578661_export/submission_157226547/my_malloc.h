#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct freeNode_t {
  size_t size;
  struct freeNode_t * next;
  //int isfree;
};  //it's 1 if this Node is free, else 0 if Node is allocated
//void * address;
//};
typedef struct freeNode_t freeNode;

void initialNode(freeNode * temp, freeNode * next, size_t size);
void * ff_malloc(size_t size);
void * bf_malloc(size_t size);
void ff_free(void * ptr);
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
