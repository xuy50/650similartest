#include "my_malloc.h"
unsigned long data_segment = 0;
unsigned long free_space = 0;
void initialNode(freeNode * temp, freeNode * next, size_t size) {
  //void * address) {
  temp->size = size;  //not include metadata
  temp->next = next;
  //temp->isfree = isfree;
  //temp->address = address;
}
freeNode * head = NULL;
//when return, we should add the metadata
void * ff_malloc(size_t size) {
  /*if (head == NULL) {
    data_segment += (size + sizeof(freeNode));
    freeNode * temp = sbrk(size + sizeof(freeNode));
    initialNode(temp, NULL, size);
    return (void *)((char *)temp + sizeof(freeNode));
    }*/
  freeNode * cur = head;
  freeNode * prev = cur;
  /*  freeNode ** cur=&head;
    while(*cur!=NULL && ((*cur)->isfree==0 || (*cur)->size<size)){
    cur=&(*cur)->next;
  }*/
  while (cur != NULL) {
    //if the current node's size is qualified
    if (cur->size >= size) {
      //size_t all_size = cur->size;
      //cur->size = size;
      free_space -= (size + sizeof(freeNode));  //?????????????????
      if (cur->size > size + sizeof(freeNode)) {
        freeNode * temp = (freeNode *)((char *)cur + cur->size - size);
        initialNode(temp, NULL, size);
        cur->size = cur->size - size - sizeof(freeNode);
        return (void *)((char *)temp + sizeof(freeNode));
      }
      else {
        if (cur == head) {
          head = cur->next;
          cur->next = NULL;
        }
        else {
          prev->next = cur->next;
          cur->next = NULL;
        }
      }
      //cur = cur->next;
      //after entring the if/else, it must return
      return (void *)((char *)cur + sizeof(freeNode));
    }
    //used in later operations
    prev = cur;
    cur = cur->next;
  }
  //do not find enough space
  data_segment += (size + sizeof(freeNode));
  freeNode * temp = sbrk(size + sizeof(freeNode));
  initialNode(temp, NULL, size);
  //prev->next = temp;
  return (void *)((char *)temp + sizeof(freeNode));
  /*if (prev->isfree == 1) {
    size_t incre_space = size - prev->size;
    sbrk(incre_space);
    prev->size = size;
    prev->isfree = 0;
    return prev->address;
  }
  else {
    return sbrk(size);
  }*/
}
void * bf_malloc(size_t size) {
  freeNode * cur = head;
  freeNode * prev = cur;
  freeNode * res_prev = NULL;
  freeNode * res = NULL;
  while (cur != NULL) {
    if (cur->size == size) {
      res = cur;
      res_prev = prev;
      break;
    }
    if (cur->size > size) {
      if (res != NULL && res->size > cur->size) {
        res = cur;
        res_prev = prev;
      }
      else if (res == NULL) {
        res = cur;
        res_prev = prev;
      }
    }
    prev = cur;
    cur = cur->next;
  }
  if (res != NULL) {
    free_space -= (size + sizeof(freeNode));
    if (res->size > size + sizeof(freeNode)) {
      freeNode * temp = (freeNode *)((char *)res + res->size - size);
      initialNode(temp, NULL, size);
      res->size = res->size - size - sizeof(freeNode);
      return (void *)((char *)temp + sizeof(freeNode));
    }
    else {
      if (res == head) {
        head = res->next;
        res->next = NULL;
      }
      else {
        res_prev->next = res->next;
        res->next = NULL;
      }
    }
    return (void *)((char *)res + sizeof(freeNode));
  }
  data_segment += (size + sizeof(freeNode));
  freeNode * temp = sbrk(size + sizeof(freeNode));
  initialNode(temp, NULL, size);
  return (void *)((char *)temp + sizeof(freeNode));
}
void ff_free(void * ptr) {
  if (head == NULL) {
    head = (freeNode *)((char *)ptr - sizeof(freeNode));
    head->next = NULL;
    free_space += (head->size + sizeof(freeNode));  //can improve here
    return;
  }
  freeNode ** cur = &head;
  freeNode ** prev = NULL;
  //freeNode * prev=cur;
  freeNode * res = (freeNode *)((char *)ptr - sizeof(freeNode));
  free_space += (res->size + sizeof(freeNode));
  while (*cur != NULL && (char *)(*cur) < (char *)res) {
    prev = cur;
    cur = &(*cur)->next;
  }
  res->next = *cur;
  *cur = res;

  /*if (*cur == head) {
      
      if (head->next != NULL && head + head->size + sizeof(freeNode) == head->next) {
        head->size += (head->next->size + sizeof(freeNode));
        head->next = head->next->next;
      }
    }
    else {*/
  if ((*cur)->next != NULL &&
      ((char *)(*cur) + (*cur)->size + sizeof(freeNode) == (char *)((*cur)->next))) {
    (*cur)->size += ((*cur)->next->size + sizeof(freeNode));
    (*cur)->next = (*cur)->next->next;
  }
  if ((prev) != NULL &&
      ((char *)(*prev) + (*prev)->size + sizeof(freeNode) == (char *)((*prev)->next))) {
    (*prev)->size += ((*prev)->next->size + sizeof(freeNode));
    (*prev)->next = (*prev)->next->next;
  }
}

/*
  if (head == ptr - sizeof(freeNode)) {
    if (head->next != NULL && (head + head->size + sizeof(freeNode) == head->next)) {
      head->size += (head->next->size + sizeof(freeNode));
      head->next = head->next->next;
    }
    return;
  }
  freeNode * prev = head;
  freeNode * cur = head->next;
  while (cur != NULL) {
    if (cur == ptr - sizeof(freeNode)) {
      cur->isfree = 1;
      if (cur->next != NULL && cur->next->isfree == 1) {
        cur->size += cur->next->size;
        cur->next = cur->next->next;
      }
      //cannot change the order of next and prev
      if (prev->isfree == 1) {
        prev->size += cur->size;
        prev->next = cur->next;
        cur = prev;
      }
      return;
    }
    prev = cur;
    cur = cur->next;
    }*/
void bf_free(void * ptr) {
  ff_free(ptr);
}
unsigned long get_data_segment_size() {
  return data_segment;
}

unsigned long get_data_segment_free_space_size() {
  return free_space;
}
/*
int main() {
  void * a = bf_malloc(30);

  //void * b = ff_malloc(1);
  //printf("asdf");
  //ff_free(b);
  //printf("the first pointer is %p\n", a);
  void * b = bf_malloc(100);
  void * c = bf_malloc(55);
  bf_free(a);
  bf_free(c);
  //printf("the second pointer is %p\n", b);

  void * d = bf_malloc(30);
  void * e = bf_malloc(42);
  //printf("aaathe third pointer is %p\n", c);
  //ff_free(a);

  bf_free(d);

  bf_free(b);
  bf_free(e);
}
*/
