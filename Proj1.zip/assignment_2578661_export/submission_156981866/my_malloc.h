#include <stdio.h>
#include <stdlib.h>

struct metadata {
  size_t size;
  struct metadata * prev;
  struct metadata * next;
};
typedef struct metadata Metadata;

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);
//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);
unsigned long get_data_segment_size();             //in bytes
unsigned long get_data_segment_free_space_size();  //in byte
void divide_block(Metadata * curr, Metadata * remain_block, size_t size);
void * malloc_new_block(size_t size);
void * my_malloc(Metadata * curr, size_t size);
void mergeFront(Metadata * curr);
void mergeBack(Metadata * curr);
void insert_block(Metadata * curr);
void remove_block(Metadata * curr);
