#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

Metadata * head = NULL;  //head of the free LinkedList
Metadata * tail = NULL;  //tail of the free LinkedList
size_t data_size = 0;
size_t free_size = 0;

//print free Linkedlist
/*
void printFreeList() {
  Metadata * cur = head;
  while (cur != NULL) {
    printf("cur: %p, cur->size: %lu\n", cur, cur->size);
    cur = cur->next;
  }
  printf("\n");
  printf("-------------------------\n");
}
*/

//First Fit malloc/free
void * ff_malloc(size_t size) {
  Metadata * curr = head;
  if (curr == NULL) {
    return malloc_new_block(size);
  }
  else {
    while (curr != NULL) {
      if (curr->size >= size) {
        return my_malloc(curr, size);
      }
      curr = curr->next;
    }
  }
  return malloc_new_block(size);
}

void * bf_malloc(size_t size) {
  Metadata * curr = head;
  Metadata * min_block = NULL;
  if (head == NULL) {
    return malloc_new_block(size);
  }
  else {
    while (curr != NULL) {
      if (curr->size == size) {
        min_block = curr;
        break;
      }
      else if (curr->size > size && (min_block == NULL || curr->size < min_block->size)) {
        min_block = curr;
      }
      curr = curr->next;
    }
    if (min_block == NULL) {
      return malloc_new_block(size);
    }
    else {
      return my_malloc(min_block, size);
    }
  }
}

void * malloc_new_block(size_t size) {
  size_t block_size = size + sizeof(Metadata);
  data_size += block_size;
  Metadata * new_block = sbrk(block_size);
  new_block->size = size;  //////
  new_block->prev = NULL;
  new_block->next = NULL;
  return (char *)new_block + sizeof(Metadata);
}

void * my_malloc(Metadata * curr, size_t size) {
  size_t block_size = size + sizeof(Metadata);
  Metadata * remain_block = (Metadata *)((char *)curr + block_size);
  size_t remain_block_size = curr->size - size;
  if (remain_block_size <= sizeof(Metadata)) {
    remove_block(curr);
  }
  else {
    divide_block(curr, remain_block, size);
  }
  free_size -= block_size;
  return (char *)curr + sizeof(Metadata);
}

void remove_block(Metadata * curr) {
  if (curr == head && curr == tail) {
    head = NULL;
    tail = NULL;
  }
  else if (curr == head) {
    head = curr->next;
    curr->next->prev = NULL;
  }
  else if (curr == tail) {
    tail = curr->prev;
    curr->prev->next = NULL;
  }
  else {
    curr->next->prev = curr->prev;
    curr->prev->next = curr->next;
  }
  curr->prev = NULL;
  curr->next = NULL;
}

void divide_block(Metadata * curr, Metadata * remain_block, size_t size) {
  if (curr == head && curr == tail) {
    head = remain_block;
    tail = remain_block;
    remain_block->prev = NULL;
    remain_block->next = NULL;
  }
  else if (curr == head) {
    head = remain_block;
    curr->next->prev = remain_block;
    remain_block->prev = NULL;
    remain_block->next = curr->next;
  }
  else if (curr == tail) {
    curr->prev->next = remain_block;
    tail = remain_block;
    remain_block->prev = curr->prev;
    remain_block->next = NULL;
  }
  else {
    curr->prev->next = remain_block;
    remain_block->prev = curr->prev;
    curr->next->prev = remain_block;
    remain_block->next = curr->next;
  }
  remain_block->size = curr->size - size - sizeof(Metadata);
  curr->size = size;
  curr->prev = NULL;
  curr->next = NULL;
}

void ff_free(void * ptr) {
  Metadata * temp;
  temp = (Metadata *)((char *)ptr - sizeof(Metadata));
  size_t block_size = temp->size + sizeof(Metadata);

  insert_block(temp);
  free_size += block_size;
  mergeBack(temp);
  mergeFront(temp);
}

void bf_free(void * ptr) {
  return ff_free(ptr);
}

void insert_block(Metadata * curr) {
  Metadata * temp = head;
  if (head == NULL && tail == NULL) {
    head = curr;
    tail = curr;
    head->next = NULL;
    head->prev = NULL;
  }
  else if (curr < head) {
    head->prev = curr;
    curr->next = head;
    head = curr;
    head->prev = NULL;
  }
  else {
    while ((temp->next != NULL) && (temp->next < curr)) {
      temp = temp->next;
    }
    curr->next = temp->next;
    curr->prev = temp;

    if (temp->next == NULL) {
      temp->next = curr;
      tail = curr;
    }
    else {
      temp->next = curr;
      curr->next->prev = curr;
    }
  }
}

void mergeFront(Metadata * curr) {
  Metadata * temp = curr->prev;
  if (temp == NULL) {
    return;
  }
  Metadata * next_node = (Metadata *)((char *)temp + temp->size + sizeof(Metadata));
  if (next_node == curr)  //(next_node == curr && temp != NULL)
  {
    temp->size += curr->size + sizeof(Metadata);
    remove_block(curr);
  }
}

void mergeBack(Metadata * curr) {
  Metadata * temp = curr->next;
  if (temp == NULL) {
    return;
  }
  Metadata * right_node = (Metadata *)((char *)curr + curr->size + sizeof(Metadata));
  if (right_node == temp) {
    curr->size += temp->size + sizeof(Metadata);
    remove_block(temp);
  }
}

unsigned long get_data_segment_size() {
  return data_size;
}
unsigned long get_data_segment_free_space_size() {
  return free_size;
}
