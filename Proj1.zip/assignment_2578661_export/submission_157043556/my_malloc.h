//
// Created by Yj L on 2023/1/22.
//
//
#ifndef UNTITLED1_MY_MALLOC_H
#define UNTITLED1_MY_MALLOC_H

#endif //UNTITLED1_MY_MALLOC_H

 //Created by Yj L on 2023/1/19.

#include <stdio.h>
#include <stdlib.h>

typedef struct  LinkedListNode{
    size_t size;
    struct LinkedListNode * prev;
    struct LinkedListNode * next;
} Node;

// operation on linkedlist
void listSplit(Node * pre, Node * curr);
void  listMerge(Node * node);
void  listRemove(Node * node);
void listInsert(Node * node);

//malloc
void *ff_malloc(size_t size);
void *bf_malloc(size_t size);
void *reSetNode(Node * curr, size_t size);
void *buildNode(size_t size);

//free
void ff_free(void *ptr);
void bf_free(void *ptr);
void FREE(void *ptr);
void Merge(Node * node);


//performance
unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

