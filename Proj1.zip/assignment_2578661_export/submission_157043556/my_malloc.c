//
// Created by Yj L on 2023/1/22.
//
#include "my_malloc.h"
#include <unistd.h>

#define SIZE_MAX 65535
#define NODESIZE sizeof(Node)

//dummy head and tail
Node * head = NULL;
Node * tail = NULL;

unsigned  long  freeSize = 0;
unsigned long totalSize = 0;

//operation on linkedlist
void listSplit(Node * pre, Node * curr){
    if (pre->next == NULL)
        tail = curr;
    Node * temp = pre->next;
    pre->next = curr;
    curr->prev = pre;
    curr->next = temp;
    if (temp != NULL)
        temp->prev = curr;
}
//todo
void  listMerge(Node * node){
    node->size += NODESIZE + node->next->size;
    listRemove(node->next);
}

void  listRemove(Node * node){
    Node * nodeNext = node->next;
    Node * nodePrev = node->prev;
    if (nodeNext != NULL)
        nodeNext->prev = nodePrev;
    else
        tail = nodePrev;
    if (nodePrev != NULL)
        nodePrev->next = nodeNext;
    else
        head = nodeNext;
    node->prev = node->next = NULL;
}
void listInsert(Node * node){
    //0x562108a1bf00
    Node * curr = head;
    while (curr != NULL && curr < node){
        curr = curr->next;
    }
    if (curr == node)
        return;
    if (curr == NULL){
        // add to last and build a new list
        node->prev = tail;
        if (tail != NULL) {
            tail->next = node;
        }
        else {
            head = node;
        }
        tail = node;
    }
    else{
        //add to first and middle
        //add first
        if (curr == head){
            node->next = curr;
            curr->prev  =node;
            head = node;
        }
       else{
            Node * temp = curr->prev;
            curr->prev = node;
            node->next = curr;
            temp->next = node;
            node->prev = temp;
        }
    }
}




//malloc
//first fit
//todo
void *ff_malloc(size_t size){
    Node * curr = head;
    //printFreeList();
    while (curr != NULL){
        //when find a node haven't been used and have enough space
        if (curr->size >= size && size + NODESIZE >= curr->size) {
            listRemove(curr);
            return (void *) curr + NODESIZE;
        }
        //if we can split
        if (size + NODESIZE < curr->size)
            return reSetNode(curr, size);
        curr = curr->next;
    }
    return buildNode(size);
}
//todo
void *bf_malloc(size_t size){
    Node * minNode = NULL;
    Node * curr = head;
   while(curr != NULL){
        if (curr->size > size && minNode == NULL)
            minNode = curr;
        else if (curr->size == size ) {
            minNode = curr;
            break;
        }
        else if (curr->size >size && curr->size < minNode->size)
            minNode = curr;
            curr = curr->next;
    }
    //if not such node exist
    if (minNode == NULL)
        return buildNode(size);
    else if (minNode->size >= size && size + NODESIZE >= minNode->size){
        listRemove(minNode);
        return (void *) minNode + NODESIZE;
    }
    else
        return reSetNode(minNode, size);
}
//todo
void *reSetNode(Node * curr, size_t size){
    Node * newNode = (Node *)((void *) curr + size + NODESIZE);
    newNode->size = curr->size - NODESIZE - size;
    listSplit(curr, newNode);
    listRemove(curr);
    curr->size = size;

    return  (void *) curr + NODESIZE;
}
void *buildNode(size_t size){
    totalSize += size + NODESIZE;
    Node * newNode = sbrk(size + NODESIZE);
    newNode->size = size;
    newNode->prev = NULL;
    newNode->next = NULL;

    return (void*)  newNode + NODESIZE;
}



//free
void ff_free(void *ptr){
   FREE(ptr);
}
void bf_free(void *ptr){
    FREE(ptr);
}
void FREE(void *ptr) {
    Node *p;
    p = (Node *) ((void *)ptr - NODESIZE);
    listInsert(p);
    Merge(p);
}
//todo
void Merge(Node *node) {
    Node *preNode = node->prev;
    Node *nextNode = node->next;

    if (nextNode != NULL && (void *) node + NODESIZE + node->size == (void *) nextNode)
        listMerge(node);
    if (preNode != NULL && (void *) preNode + NODESIZE + preNode->size == (void *) node)
        listMerge(preNode);
}

//performance
unsigned long get_data_segment_size() {
    return totalSize;
}
unsigned long get_data_segment_free_space_size() {
    unsigned long ans = 0;
    Node * curr = head;
    while (curr != NULL){
        ans += (curr->size +NODESIZE);
        curr = curr->next;
    }
    return  ans;
}

