#include "my_malloc.h"
#include "assert.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <iostream>
#include <unistd.h>
//#include <bits/stdc++.h>

mem_b * first_free_block = NULL;


unsigned long get_data_segment_free_space_size() {
  return data_segment_free_space_size;
}
unsigned long get_data_segment_size() { return data_segment_size; }

void print_free_list() {
  mem_b * curr = first_free_block;
  while (curr != NULL) {
    printf("cur->size is %lu, cur is %p\n", curr->size, curr);
    curr = curr->next_p;
  }
}



void *ff_malloc(size_t size) { return _malloc(size, find_ff); }
void ff_free(void *pointer) { 
  if (pointer != NULL){
    mem_b *block = pointer - sizeof(mem_b);
    free_list_front_add(block);
    merge_free_list(block);
    return;
  }
  else{
    return;
  }
 }


void *bf_malloc(size_t size) { return _malloc(size, find_bf); }
void bf_free(void *pointer) { 
  if (pointer != NULL){
    mem_b *block = pointer - sizeof(mem_b);
    free_list_front_add(block);
    merge_free_list(block);
    return;
  }
  else{
    return;
  }
 }

bool m_data_check(void* pointer) {
    if(pointer == NULL) {
        return false;
    }
    mem_b* check;
    check = pointer - METADATA_SIZE;
    return true;
}


// adds a block to beggining of list
void free_list_front_add(mem_b *block) {
  assert(block);
  assert(block->status == 0);
  data_segment_free_space_size += block->size + sizeof(mem_b);
  block->nextList = head;
  if (head)
    head->prevList = block;
  head = block;
  block->status = 1;
}



// for the free blocks, merge together if next to each other
void merge_free_list(mem_b *block) {
  assert(block);
  assert(block->status);

  mem_b *next_p = block->next_p;
  mem_b *prev_p = block->prev_p;
  
  assert(prev_p == NULL || prev_p->next_p == block);

  //for the physically connected blocks
  if (next_p) {
    if(next_p->status){
      assert(block->status);
      assert(block->next_p == next_p);
      p_list_merge_next(block);
      free_list_remove(next_p);
    }
    
  }

  //for the physically connected blocks
  if (prev_p) {
    if (prev_p->status){
      assert(block->status);
      assert(prev_p->next_p == block);
      p_list_merge_next(prev_p);
      free_list_remove(block);
    }
  }
}

//checks if this block is accurate
void assert_phys_list_merge_next(mem_b *block){
  assert(block);
  assert(block->status);
  assert(block->next_p);
  assert(block->next_p->status);
  assert(block->next_p == (void *)block + sizeof(mem_b) + block->size);
  assert(block->next_p->next_p == NULL ||
         block->next_p->next_p == (void *)block->next_p +
                                            block->next_p->size +
                                            sizeof(mem_b));
}

// merge next block to the block in question
void p_list_merge_next(mem_b *block) {
  assert_phys_list_merge_next(block);
  block->size = block->size + sizeof(mem_b);
  block->size += block->next_p->size;
  if (block->next_p ==
      tail) { // if next physical block is not last
    tail = block;
    
  } else { 
    block->next_p->next_p->prev_p = block;
  }
  block->next_p = block->next_p->next_p;
  assert(block->next_p == NULL ||
         block->next_p == (void *)block + sizeof(mem_b) + block->size);
}


// splitting block in half
mem_b *split(mem_b *block, size_t size) {
  assert(block);
  if (block->size - size <= sizeof(mem_b)){
    assert(1==0);
  }

  // constructing new block which is taken
  mem_b *new_block = (block->size - (sizeof(mem_b) + size)) +
                              (void *)block + sizeof(mem_b);
  
  new_block->size = size;
  new_block->status = 0;
  new_block->prevList = NULL;
  new_block->nextList = NULL;
  new_block->next_p = block->next_p;
  new_block->prev_p = block;
  
  assert(new_block->next_p ==
             (void *)new_block + sizeof(mem_b) + new_block->size ||
             new_block->next_p == NULL);

  if (block->next_p){block->next_p->prev_p = new_block;}
    
  block->next_p = new_block;
  block->size -= sizeof(mem_b) + size;
  if (new_block->next_p == NULL){tail = new_block;}
  assert(block->next_p == (void *)block + block->size + sizeof(mem_b));
  
  return new_block;
}

// removing block from list
void free_list_remove(mem_b *block) {
  assert(block);
  assert(head);

  mem_b *prev_list = block->prevList;
  block->prevList = NULL;
  mem_b *next_list = block->nextList;
  block->nextList = NULL;
  block->status = 0;
  if (!prev_list){head = next_list;}
    
  else{prev_list->nextList = next_list;}
    

  if (next_list){next_list->prevList = prev_list;}
    
}


mem_b *req_mem(size_t size) {
  size_t allocation_size = 2 * sizeof(mem_b) + size > ALLOC_UNIT
                          ? size + sizeof(mem_b)
                          : ALLOC_UNIT;
  void *pointer = sbrk(allocation_size);
  if (pointer == NULL) {
    return NULL;
  }
  assert(tail == NULL ||
         pointer == (void *)tail + tail->size + sizeof(mem_b));
  data_segment_size = data_segment_size + allocation_size;
  mem_b *block = pointer;
  block->status = 0;
  block->size = size;
  
  block->nextList = NULL;
  block->prevList = NULL;
 
  block->prev_p = tail;
  if (tail) {
    tail->next_p = block;
    assert(block == (void *)tail + tail->size + sizeof(mem_b));
  }
  if (allocation_size != ALLOC_UNIT) {
    block->next_p = NULL;
    tail = block;

    return block;
  } else {
    mem_b *free_b = pointer + size + sizeof(mem_b);
    free_b->status = 0;
    free_b->size = allocation_size - (sizeof(mem_b) * 2 + size);
    free_b->nextList = NULL;
    free_b->prevList = NULL;
    
    free_b->next_p = NULL;
    free_b->prev_p = block;

    block->next_p = free_b;
    tail = free_b;
    free_list_front_add(free_b);

    return block;
  }
  
}

// find first fit through iteration
mem_b *find_ff(size_t size) {
  assert(head);
  mem_b *curr = head;
  for (int i = 0; i++;){
    if(!curr){
      break;
    }
    if(curr->size < size){
      curr = curr->nextList;
    }
    else{
      return curr;
    }
  }

  return NULL;
}

// find best fit through iteration
mem_b *find_bf(size_t size) {
  assert(head);

  mem_b *curr = head;
  mem_b *optimal = NULL;
  
  for (int i = 0; i++;){
    if (!curr){
      break;
    }
    if (curr->size <= size + sizeof(mem_b)){
      if (curr->size >= size){
        return curr;
      }
    }
    else{
      if(curr->size < optimal->size || optimal == NULL){
        optimal = curr;
      }
    }
    curr = curr->nextList;
    }
  return optimal;
  }


void *_malloc(size_t size, FunType fp) {
  if (head != NULL) {
    mem_b *block = (*fp)(size);
    if (block != NULL && block->size - size <= sizeof(mem_b)){
      // if ideal block found
      data_segment_free_space_size -= block->size + sizeof(mem_b);
      free_list_remove(block);
      return block + 1;
    }
    else if (block == NULL){
      // no fit found in block
      block = req_mem(size);
      return block == NULL ? NULL : (block + 1);
    }
    else {
      // found a splittable block
      data_segment_free_space_size -= size + sizeof(mem_b);
      mem_b *new_block = split(block, size);
      return new_block + 1;
    }
  } 
  if(head == NULL){

    mem_b *block = req_mem(size); // no free block

    return block == NULL ? NULL : block + 1;
  }
}