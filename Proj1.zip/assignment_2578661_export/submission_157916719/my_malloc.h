//#ifndef _MY_MALLOC_H
//#define _MY_MALLOC_H


#include <unistd.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <assert.h>

unsigned long data_segment_size = 0;
unsigned long data_segment_free_space_size = 0;


void *ff_malloc(size_t size);
void ff_free(void *ptr);


void *bf_malloc(size_t size);
void bf_free(void *ptr);

struct metadata {
  size_t size;//
  int isfree;//
  struct metadata * next;//
  struct metadata * prev;//
};
typedef struct metadata Metadata;


typedef struct mem_block {
  size_t size;//
  int status;//
  struct mem_block *next_p;//
  struct mem_block *prev_p;//
  struct mem_block *nextList;
  struct mem_block *prevList;
} mem_b;
typedef mem_b *(*FunType)(size_t);


void * block_reuse(size_t size, Metadata * p);//e3
void * block_allocate(size_t size);


#define METADATA_SIZE sizeof(384)  // design is 48bytes

void print_free_list();

bool m_data_check(void* ptr);

#define ALLOC_UNIT 3 * sysconf(_SC_PAGESIZE)

mem_b *head = NULL; 
mem_b *tail = NULL; 


void _free(void *ptr);//h2

// adding block to beggining of list
void free_list_front_add(mem_b *block);//a3

// removing block from list
void free_list_remove(mem_b *block);//b3

// merging nearby blocks
void merge_free_list(mem_b *block);//c2

// splitting block in half
mem_b *split(mem_b *block, size_t size);//e3

// sbrk used for mem allocation
mem_b *req_mem(size_t size);

void *_malloc(size_t size, FunType fp);

mem_b *find_ff(size_t size);//f2
mem_b *find_bf(size_t size);//g2

// merging next physical block into a bigger one
void p_list_merge_next(mem_b *block);



