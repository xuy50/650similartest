#include "my_malloc.h"
#include <stdio.h>
#include "unistd.h"

// using linked list to manage the free memory
typedef struct list_node_t
{
    size_t size; // size of the free memory
    struct list_node_t* next; // next node in the free memory list
    struct list_node_t* prev; // prev node
} LinkedNode;

// total alloced memory
size_t tota_alloced = 0;

// the head of the free memory list
LinkedNode* head = NULL;

// split the current free memory into two parts, the first one is remain free memory, the second one is distributed memory
LinkedNode* split(LinkedNode* target, size_t size)
{
    target->size -= sizeof(LinkedNode) + size;
    LinkedNode * tmp = (LinkedNode*)((char*)target+ sizeof(LinkedNode) + target->size);
    tmp->size = size;
    return tmp;
}

// alloced new space if there is no enough space
void* new_space(size_t size)
{
    LinkedNode* tmp = sbrk(sizeof(LinkedNode) + size);
    tota_alloced += size + sizeof(LinkedNode);
    tmp->size = size;
    return tmp;
 }

// find the first fit memory from the free memory list
LinkedNode *  ff_find(size_t size)
{
    LinkedNode* p = head;
    while (p)
    {
        if( p->size >= size)
        {
	        return p;
        }
        p = p->next;
    }
    return p;
}

// a general function for malloc memory from free list
void* general_malloc(LinkedNode* p, size_t size)
{
    LinkedNode* target;
    // with enough free momery
    if (p)
    {
        // enough to split
        if (p->size - size > sizeof(LinkedNode))
        {
            target = split(p, size);
        }
        // no need to split and just remove the target node from the free memory list
        else
        {
            // the only head node
            if (p->prev == NULL && p->next == NULL)
            {
                head = NULL;
                target = p;
            }
            // the head node, but has next node
            else if (p->prev == NULL)
            {
                head = p->next;
                p->next->prev = NULL;
                target = p;
            }
            // not the head node, but the last node
            else if (p->next == NULL)
            {
                p->prev->next = NULL;
                target = p;
            }
            // the middle node with prev and next
            else
            {
                p->prev->next = p->next;
                p->next->prev = p->prev;
                target = p;
            }
        }
    }
    // without enough  free memory
    else
    {
        // alloc new space
        target = new_space(size);
    }
    return (char*)target + sizeof(LinkedNode);
}

// my version of first fit malloc
void* ff_malloc(size_t size)
{
    if (head)
    {
        LinkedNode* p = ff_find(size);
        return general_malloc(p, size);
    }
    // the first time to alloced new space
    else
    {
        LinkedNode* target = new_space(size);
        return (char*)target + sizeof(LinkedNode);
    }
}

// merge the right free memory node
LinkedNode* merge(LinkedNode * p)
{
    p->size += sizeof(LinkedNode) + p->next->size;
    p->next = p->next->next;
    if (p->next)
    {
        p->next->prev = p;
    }
    return p;
}

// add free node to free memory list
void add_free_node(void* target)
{
    LinkedNode * node = (LinkedNode*)(target - sizeof(LinkedNode));
    // add node as head
    if(head == NULL)
    {
        head = node;
        node->next = NULL;
        node->prev = NULL;
    }
    // insert the node into free list according to its address
    else
    {
        // the node's address is lower than head, than replace the head
        if(node < head)
        {
	        node->next = head;
            node->prev = NULL;
            head = node;
        }
        // insert the node according to its address
        else 
        {
            LinkedNode* p = head;
            while (p->next && p->next<node)
            {
                p = p->next;
            }
            if (p->next)
            {
                node->next = p->next;
                node->prev = p;
                p->next = node;
                node->next->prev = node;
            }
            else
            {
		node->next = NULL;
                node->prev = p;
                p->next = node;
            }
        }
    }
}

// free a memory node
void general_free(void* target)
{
    LinkedNode* node = (LinkedNode*)((char*)(target)-sizeof(LinkedNode));
    add_free_node(target);
    // merge right
    if (node->next && ((char*)node + sizeof(LinkedNode) + node->size == (char*)node->next))
    {
        merge(node);
    }
    // merge left
    if (node->prev && ((char*)node - node->prev->size - sizeof(LinkedNode) == (char*)node->prev))
    {
        merge(node->prev);
    }
}

// my version of the first fit memory free
void ff_free(void* target)
{
    general_free(target);
}

// best fit find the appropriate free memory greater than or equal to requested memory size
LinkedNode* bf_find(size_t size)
{
    LinkedNode* p = head;
    LinkedNode* best = NULL;
    // loop all nodes and find the minimun memory size satisfy the request
    while (p)
    {
      if(p->size==size){
           return p;
       }
        if (p->size >= size && (best == NULL || p->size < best->size))
        {
            best = p;
        }
        p = p->next;
    }
    return best;
}

// best fit malloc
void *bf_malloc(size_t size)
{
    if (head)
    {
        LinkedNode* p = bf_find(size);
        return general_malloc(p, size);
    }
    // the first time to alloced new space
    else
    {
        LinkedNode* target = new_space(size);
        return (char*)target + sizeof(LinkedNode);
    }
}

// best fit free
void bf_free(void *target)
{
    general_free(target);
}

unsigned long get_data_segment_size()
{
    return tota_alloced;
}

unsigned long get_data_segment_free_space_size()
{
    size_t size = 0;
    LinkedNode* p = head;
    while (p)
    {
        size += sizeof(LinkedNode) + p->size;
        p = p->next;
    }
    return size;
}
