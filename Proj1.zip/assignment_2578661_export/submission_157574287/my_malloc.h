#ifndef _MY_MALLOC_H_
#define _MY_MALLOC_H_

#include <stdlib.h>

//First Fit malloc/free
void* ff_malloc(size_t size);
void ff_free(void* target);

//Best Fit malloc/free
void* bf_malloc(size_t size);
void bf_free(void* target);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in bytes

#endif // !_MY_MALLOC_H_



