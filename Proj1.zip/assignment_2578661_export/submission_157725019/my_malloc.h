#ifndef __MY_MALLOC__
#define __MY_MALLOC__
#include <stddef.h>

#define S_FREE 0
#define S_ALLOCD 1

void * ff_malloc(size_t size);
void ff_free(void * ptr);

void * bf_malloc(size_t size);
void bf_free(void * ptr);

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in bytes
#endif
