#include "my_malloc.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>

struct MemData {
  size_t size;  //(metadata size + data size)
  struct MemData * next;
  struct MemData * prev;
};

typedef struct MemData m_Node;

m_Node * global_list_head = NULL;
m_Node * global_list_tail = NULL;
size_t heap_size = 0;

/*
 * Creates a new memory block
 * param: size -> size of space to alloc
 */
m_Node * createMemNode(void * ptr) {
   m_Node * meta = (m_Node *) ((char *)ptr - sizeof(*meta));
   meta->size += sizeof(m_Node);
   meta->next = NULL;
   meta->prev = NULL;
   return meta;
}

/*
 * Adds the newly freed block to the correct location in the list to maintain a sorted list in ascending order
 * param: blk -> newly freed block 
 */
void add(m_Node * blk) {
  m_Node * curr = global_list_head;
  if (curr == NULL) {
    global_list_head = blk;
    global_list_tail = blk;
    return;
  }
  //Iterate until current blk is greater than input blk, insert input blk in front of current blk
  while (curr != NULL) { 
    if (curr < blk) {      
      curr = curr->next;
    } else if (curr > blk) {
      m_Node * temp = curr->prev;
      curr->prev = blk;
      blk->next = curr;
      blk->prev = temp;
      if (temp != NULL) {
        temp->next = blk;
      }
      //if curr is the head of the list, update the head to point to block
      if (curr == global_list_head) {
        global_list_head = blk;
      }
      return;
    }
  }
  m_Node * temp = global_list_tail;
  blk->next = temp->next;
  blk->prev = temp;
  temp->next = blk;
  global_list_tail = blk;
}

/*
 * Removes the newly allocated memory from the free list
 * param: mem -> newly allocated memory 
 */
void remove_allocdMem(m_Node * mem) {
  if (mem != global_list_head && mem != global_list_tail) {
    mem->prev->next = mem->next;
    mem->next->prev = mem->prev;
  } 
  else if (mem == global_list_head) {
    if (mem->next == NULL) {
      global_list_head = NULL;
      global_list_tail = NULL;
    } else {
      mem->next->prev = NULL;
      global_list_head = mem->next;
    }
  }
  else if (mem == global_list_tail) {
    mem->prev->next = NULL;
    global_list_tail = mem->prev;
  }
  mem->next = NULL;
  mem->prev = NULL;
}

/*
 * Splits a free block of memory by setting a new header at the end of the alloced memory
 * Removes the old mem block and adds the new split block, then return the top of the old mem block
 * param: mem -> the block of memory to split
 * param: size -> size of newly allocated memory
 */
void * splitBlock(m_Node * mem, size_t size) {
  m_Node * split_blk = (m_Node *) ((char *)mem + sizeof(*mem) + size);
  split_blk->size = (mem->size - sizeof(*mem)) - size;
  split_blk->next = NULL;
  split_blk->prev = NULL;
  m_Node * res = mem;
  remove_allocdMem(mem);
  add(split_blk);
  res->size = size;
  return (char *)res + sizeof(*res);
}

 /*
 * Splits a free block of memory by setting a new header at the end of the alloced memory
 * updates the pointers to keep the split block in order
 * param: mem -> the block of memory to split
 * param: size -> size of newly allocated memory
 */   	       
void * ff_malloc(size_t size) {
  m_Node * res = NULL;
  m_Node * curr = global_list_head;

  while (curr != NULL) {
    size_t actual_size = curr->size - sizeof(*curr); //actual size available for data
    if (actual_size >= size + sizeof(*curr)) {
      res = (m_Node *)((char *)curr + sizeof(*curr));
      if (actual_size > size) {
        size_t rem = actual_size - size;
        if (rem >= (size + 2 * sizeof(*curr))) {     //checks if the remaining block size is >= (size + 2 * sizeof(metadata)
          return splitBlock(curr, size);              
        } else {
          curr = curr->next;
          continue;
        }
      }
      remove_allocdMem(curr);
      return res;
    }
    curr = curr->next;
  }

  res = sbrk(size + sizeof(m_Node));
  res->size = size;
  heap_size += size + sizeof(*res);
  return (char *)res + sizeof(m_Node);
}

/*
 * Splits a free block of memory by setting a new header at the end of the alloced memory
 * updates the pointers to keep the split block in order
 * param: mem -> the block of memory to split
 * param: size -> size of newly allocated memory
 */
void ff_free(void * ptr) {
  m_Node * meta = createMemNode(ptr);
  add(meta);
  m_Node * nxt_blk = meta->next;
  m_Node * prev_blk = meta->prev;
  m_Node * right_adj = (m_Node *)((char *)meta + meta->size);
 
  if (nxt_blk != NULL && right_adj == nxt_blk) {
    meta->size = meta->size + nxt_blk->size;
    remove_allocdMem(nxt_blk);
  }
  
  if (prev_blk != NULL) {
    m_Node * left_adj = (m_Node *)((char *)meta - prev_blk->size);
    if (left_adj == prev_blk) {
      prev_blk->size = meta->size + prev_blk->size;
      remove_allocdMem(meta);
    }
  }
}

/*
 * Best-Fit Malloc
*/
void * bf_malloc(size_t size) {
  m_Node * curr = global_list_head;
  m_Node * best_blk = NULL;
  size_t best_sz = SIZE_MAX;

  while (curr!= NULL) {
    size_t actual_size = curr->size - sizeof(*curr); //actual size available for data
     if (actual_size > size && actual_size >= (size + 2 * sizeof(*curr))) {
      if (actual_size < best_sz) {
        best_blk = curr;
        best_sz = actual_size;
      }
    } else if (actual_size == size) {
      remove_allocdMem(curr);
      return (char *)curr + sizeof(*curr);
    }
    curr = curr->next;
  }
  if (best_blk != NULL) {
    return splitBlock(best_blk, size); 
  } 

  best_blk = sbrk(size + sizeof(m_Node));
  best_blk->size = size;
  heap_size += size + sizeof(*best_blk);
  return (char *)best_blk + sizeof(m_Node);
}


void bf_free(void * ptr) {
  ff_free(ptr);
}

unsigned long get_data_segment_free_space_size() {
  m_Node * curr = global_list_head;
  size_t size = 0;
  while (curr != NULL) {
    size += curr->size;
    curr = curr->next;
  }
  return size;
}

unsigned long get_data_segment_size() {
  return heap_size;
}
