#include "my_malloc.h"
/**
 * @author: Xiwen Shen xs105
 * @date: 1/26/2023
*/
struct metaData *head=NULL; //this is the head of the free memory link list
struct metaData *freeptr = NULL;// this is the free memory need to be added to the linked list
unsigned long segment_size =0;//this count the total segment size


/** this method will update the metaData information
 * @param ptr this is the address of the region we want to change
 * @param size this is the new size of the region
 * @param next this point to the next free region(if the region already be used it should be NULL)
 * @return ptr the address of the region we changed
*/
metaData * updateMetaData( struct metaData *ptr,size_t size,struct metaData * next){
        ptr->size=size;
        ptr->address=(void *)ptr+sizeof(metaData);
        ptr->next=next;
        return ptr;
}

/**
 * find the right free region for malloc
 * @param size: the size of the region
 * @param type:type = 0 :ff;ype = 1 :bf
 * @return curr: the segemnt address of the free region
*/

metaData * findRegion(size_t size, int type){
    struct metaData *curr = head;
    struct metaData *pre = NULL;
    //for the first fit to find a first empty region have the enough size
    if(type==0){
      while(curr!=NULL &&curr->size<size){
        pre=curr;
        curr=curr->next;
    }
    }else{
      /**for the best fit, find all large enough region
       * record the smallest large enough region
       * if the region size = the size we need return that region
      */
      struct metaData *ptr=NULL;
      struct metaData *preptr=NULL;

      size_t difference = INT_MAX;
      while(curr!=NULL){
        while (curr!=NULL &&curr->size<size){
        pre=curr;
        curr=curr->next;
        }
        if(curr!=NULL){
          if(curr->size-size<difference){
          difference=curr->size-size;
          preptr = pre;
          ptr = curr;
        }
        // find exact same size so break
        if(difference ==0){
          break;
        }
        pre=curr;
        curr=curr->next;
        }
    }
    pre=preptr;
    curr=ptr;
    }
    
    //if there do have enogh free region, move the top data segment to add more
    if(curr == NULL){
        void * p= sbrk(size + sizeof(metaData));
        segment_size=segment_size+size + sizeof(metaData);
        curr=p;
        curr=updateMetaData(curr,size,NULL);
    }else{
      //remove the finded region from the free linked list
      if(pre!=NULL){
         pre->next=curr->next;
        curr->next=NULL;
      }else{
        head=head->next;
        curr->next=NULL;

      }
     
    }
    return curr;
}
//insert the freed region to the right position in the free linked list
void insertToLL(){
  if(head ==NULL){
    head = freeptr;
    return;
  }
  metaData * ptr = head;
  metaData * pre = NULL;
  while(ptr!=NULL && ptr<freeptr){
    pre=ptr;
    ptr=ptr->next;
  }
  // if the menory region before it is also free, merge to together
 if(pre!=NULL&&pre->address+pre->size==freeptr){
        size_t newSize = pre->size+sizeof(metaData)+freeptr->size;
        pre=updateMetaData(pre,newSize,pre->next);
        freeptr=pre;
    }else{
      if(pre!=NULL){
        freeptr->next=pre->next;
        pre->next=freeptr;
      }
      //insert to the first of the free link list
      if(pre==NULL){
      freeptr->next=head;
      head=freeptr;
      }
    }
  // if the menory region after it is also free, merge to together

if(ptr!=NULL&&ptr==freeptr->address+freeptr->size){
  size_t newSize = ptr->size+sizeof(metaData)+freeptr->size;
        freeptr=updateMetaData(freeptr,newSize,ptr->next);
        ptr=freeptr;
    }else{
      if(ptr!=NULL)
        freeptr->next=ptr;
    }
   
}

void *ff_malloc(size_t size){
   struct metaData *curr = my_malloc(size,0);
   return curr->address;
}

void *bf_malloc(size_t size){
  struct metaData *curr = my_malloc(size,1);
  return curr->address;
}

/** this method do the malloc
 * it call findRegion() method to find the free region
 * then check the region, if the region is too big divided it to two
 * insert the second part into the free linked list
 * @param size: the size need to be malloc
 * @param type: type = 0 :ff;ype = 1 :bf used for find the region
*/
void *my_malloc(size_t size,int type){
    struct metaData *curr = findRegion(size,type);
    if(curr->size>size+sizeof(metaData)){
        struct metaData *ptr=curr->address+size;
        size_t newSize = curr->size-size-sizeof(metaData);
        ptr=updateMetaData(ptr,newSize,NULL);
        freeptr=ptr;
        curr->size=size;
        insertToLL();
    }
    return curr;
}

void bf_free(void *ptr){
  my_free(ptr);
}
void ff_free(void *ptr){
  my_free(ptr);

} 
/**
 * insert the freed region to the free link list
*/
void my_free(void *ptr){
\
  if(ptr==NULL)
    return;
  freeptr=ptr-sizeof(metaData);
  freeptr->next=NULL;
  insertToLL();

}
/*get the segment size*/
unsigned long get_data_segment_size(){
  return segment_size;
  
}
/*traverse the free linked list to calculate the free sqace size*/
unsigned long get_data_segment_free_space_size(){
  unsigned long size =0;
  struct metaData *curr=head;
  while(curr!=NULL){
      size=size+curr->size+sizeof(metaData);
    //  printf("%p\n",curr->next);
      curr=curr->next;
  }
  return size;
  
}

//used for test
void printLL(){
  metaData * ptr=head;
  int i=0;
  while(ptr!=NULL){
    i++;
    printf("this is %p\n",ptr);
    printf("this address %p\n",ptr->address);
    ptr=ptr->next;
  }
}