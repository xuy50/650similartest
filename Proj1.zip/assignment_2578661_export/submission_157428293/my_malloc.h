#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <limits.h>

/**
 * @author: Xiwen Shen xs105
 * @date: 1/26/2023
*/

/**
 * this struct stores the region information
 * size: the size of the region
 * address:the start position to store the actual data
 * next: only used for the free region, will point to the next free region, if the region is used it will point to NULL
*/
typedef struct metaData{
    size_t size;
    void *address;
    struct metaData * next;

}metaData;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//the help method for free and malloc 
void my_free(void *ptr);
void *my_malloc(size_t size,int type);
//to update the matedata information
metaData * updateMetaData( struct metaData *ptr,size_t size, struct metaData * next);
// to find the free region
metaData * findRegion(size_t size,int type);
//insert the free region to the right position of the free link list
void insertToLL();
//claculate the size
unsigned long get_data_segment_size(); 
unsigned long get_data_segment_free_space_size();
//print the free region link list used for debug
void printLL();
