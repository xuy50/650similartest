#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

// struct for blocks
typedef struct regionItem {
	size_t size;
	struct regionItem* prev;
	struct regionItem* next;
}Ritem;

typedef struct freeList {
	Ritem* first_free_item;//start
	Ritem* last_free_item;//end

}fList;



void* ff_malloc(size_t size);
void ff_free(void* ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void* allocate_my(size_t size);
void split_item(Ritem* target_block, size_t size);
void delete_item(Ritem* deleteItem);
void add_item(Ritem* target_block);
void merge_right(Ritem* mergeRitem);
void merge_left(Ritem* mergeLitem);
void bf_free(void* ptr);
void* bf_malloc(size_t size);
Ritem* bf(size_t size);