#include "my_malloc.h"

fList freeList = {
   .first_free_item = NULL,
   .last_free_item = NULL,
};

size_t allocated_size = 0;
size_t free_size = 0;
void* ff_malloc(size_t size) {
	Ritem* curr = freeList.first_free_item;
	if (freeList.first_free_item == NULL) {
		return allocate_my(size);
	}
	else
	{
		while (curr != NULL)
		{
			if (curr->size >= size) {
				if (curr->size <= sizeof(Ritem) + size)
				{

					free_size -= (curr->size + sizeof(Ritem));
					delete_item(curr);
					return sizeof(Ritem) + (char*)curr;
				}
				else
				{
					free_size -= (size + sizeof(Ritem));
					split_item(curr, size);
					return sizeof(Ritem) + (char*)curr;
				}
			}
			curr = curr->next;
		}
		return allocate_my(size);
	}
}
void ff_free(void* ptr) {
	if (ptr == NULL)
	{
		return;
	}
	Ritem* freedItem = (Ritem*)((char*)ptr - sizeof(Ritem));
	free_size += (freedItem->size + sizeof(Ritem));
	add_item(freedItem);
	if (freedItem == freeList.first_free_item) 
	{
		merge_right(freedItem);
	}
	else if (freedItem == freeList.last_free_item) 
	{
		merge_left(freedItem);
	}
	else 
	{
		merge_right(freedItem);
		merge_left(freedItem);
	}
}
void* allocate_my(size_t size) {
	size_t newTotalSize = size + sizeof(Ritem);
	void* sbrkItem = sbrk(newTotalSize);

	if (sbrkItem != (void*)-1)
	{
		Ritem* newRegionItem = (Ritem*)sbrkItem;
		newRegionItem->size = size;
		newRegionItem->prev = NULL;
		newRegionItem->next = NULL;
		allocated_size += size + sizeof(Ritem);
		return sizeof(Ritem) + (char*)newRegionItem;
	}
	else
	{
		return NULL;
	}
}
void split_item(Ritem* splitItem, size_t size) {
	//splittedItem means the remaining item
	Ritem* splittedItem = (Ritem*)((char*)splitItem + sizeof(Ritem) + size);
	size_t splittedSize = splitItem->size - size - sizeof(Ritem);
	splittedItem->size = splittedSize;
	splitItem->size = size;
	Ritem* olditem = splitItem->next;
	splittedItem->prev = splitItem;
	splitItem->next = splittedItem;
	if (splitItem == freeList.last_free_item)
	{
		splittedItem->next = NULL;
		freeList.last_free_item = splittedItem;
	}
	else
	{
		splittedItem->next = olditem;
		splittedItem->next->prev = splittedItem;
	}
	delete_item(splitItem);
}
void delete_item(Ritem* deleteItem) {
	//only one item in the list 
	if ((deleteItem == freeList.first_free_item) && (deleteItem == freeList.last_free_item))
	{
		freeList.first_free_item = NULL;
		freeList.last_free_item = NULL;
	}
	//delete the first item
	else if (deleteItem == freeList.first_free_item)
	{
		freeList.first_free_item = freeList.first_free_item->next;
		freeList.first_free_item->prev = NULL;
	}
	//delete the second item
	else if (deleteItem == freeList.last_free_item)
	{
		freeList.last_free_item = freeList.last_free_item->prev;
		freeList.last_free_item->next = NULL;
	}
	else
	{
		Ritem* predelete = deleteItem->prev;
		Ritem* nextdelete = deleteItem->next;
		predelete->next = deleteItem->next;
		nextdelete->prev = deleteItem->prev;
	}
	deleteItem->next = NULL;
	deleteItem->prev = NULL;
}
void add_item(Ritem* addItem) {
	if (freeList.first_free_item == NULL && freeList.last_free_item == NULL) 
	{
		freeList.first_free_item = addItem;
		freeList.last_free_item = addItem;
		addItem->next = NULL;
		addItem->prev = NULL;
		return;
	}
	Ritem* curr = freeList.first_free_item;
	while (curr != NULL) {
		if (curr >= addItem)
		{
			break;
		}
		curr = curr->next;
	}
	//add item before first item in the list
	if (curr == freeList.first_free_item)
	{
		freeList.first_free_item->prev = addItem;
		addItem->next = freeList.first_free_item;
		addItem->prev = NULL;
		freeList.first_free_item = addItem;
	}
	//add item after last item in the list
	else if (curr == NULL)
	{
		freeList.last_free_item->next = addItem;
		addItem->prev = freeList.last_free_item;
		addItem->next = NULL;
		freeList.last_free_item = addItem;
	}
	else
	{
		Ritem* oldItem = curr->prev;
		curr->prev = addItem;
		addItem->prev = oldItem;
		addItem->next = curr;
		oldItem->next = addItem;
	}
	return;
}
void merge_right(Ritem* mergeRitem)
{	
	Ritem* mergenext = mergeRitem->next;
	if ((char*)mergeRitem + sizeof(Ritem) + mergeRitem->size == (char*)mergenext)
	{		
		mergeRitem->size += mergenext->size + sizeof(Ritem);
		delete_item(mergenext);
	}
}
void merge_left(Ritem* mergeLitem)
{
	
	Ritem* mergeprev = mergeLitem->prev;
	if ((char*)mergeprev + sizeof(Ritem) + mergeLitem->prev->size == (char*)mergeLitem)
	{
			
		mergeprev->size += mergeLitem->size + sizeof(Ritem);
		delete_item(mergeLitem);
	}
	
}
unsigned long get_data_segment_size() {
	return allocated_size;
}
unsigned long get_data_segment_free_space_size() {
	return free_size;
}
void bf_free(void* ptr)
{
	ff_free(ptr);
}
void* bf_malloc(size_t size)
{
	Ritem* curr = freeList.first_free_item;

	if (freeList.first_free_item == NULL) {
		return allocate_my(size);
	}
	else
	{

		Ritem* bestItem = bf(size);
		if (bestItem == NULL)
		{
			return allocate_my(size);
		}
		else
		{
			if (bestItem->size >= size) {
				if (bestItem->size <= sizeof(Ritem) + size)
				{

					free_size -= (bestItem->size + sizeof(Ritem));
					delete_item(bestItem);
					return sizeof(Ritem) + (char*)bestItem;
				}
				else
				{
					free_size -= (size + sizeof(Ritem));
					split_item(bestItem, size);
					return sizeof(Ritem) + (char*)bestItem;
				}
			}
		}

	}


}
Ritem* bf(size_t size)
{
	Ritem* curr = freeList.first_free_item;
	Ritem* bestItem = NULL;
	while (curr != NULL)
	{
		if (curr->size == size)
		{
			return curr;
		}
		else if (curr->size > size)
		{
			if (bestItem == NULL)
			{
				bestItem = curr;
			}
			else
			{
				if (bestItem->size > curr->size)
				{
					bestItem = curr;
				}
			}
		}
		curr = curr->next;
	}
	return bestItem;
}