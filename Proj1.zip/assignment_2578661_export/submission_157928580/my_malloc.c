#include "my_malloc.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//First Fit malloc/free

node_t * head = NULL;
node_t * tail = NULL;
unsigned long freeSize = 0;
unsigned long usedSize = 0;

void configMem(node_t * curr, size_t fullSize, node_t * nextNode) {
  //if the there is only 1 block in the list

  if (curr->prev == NULL && curr->next == NULL) {
    head = nextNode;
    tail = nextNode;
    if (nextNode != NULL) {
      nextNode->next = curr->next;
      nextNode->prev = curr->prev;
    }
  }
  // if the free block is the first block in the list but there are free block after it

  else if (curr->prev == NULL && curr->next != NULL) {
    if (nextNode == NULL) {
      head = curr->next;
      curr->next->prev = NULL;
    }
    else {
      head = nextNode;
      curr->next->prev = nextNode;
    }
  }
  //if the free bock is the last one in the list
  else if (curr->prev != NULL && curr->next == NULL) {
    if (nextNode == NULL) {
      tail = curr->prev;
      curr->prev->next = nextNode;
    }
    else {
      tail = nextNode;
      curr->prev->next = nextNode;
    }
  }
  // in all other cases, empty block is in the midde of list
  else {
    if (nextNode == NULL) {
      curr->prev->next = curr->next;
      curr->next->prev = curr->prev;
    }
    else {
      curr->prev->next = nextNode;
      curr->next->prev = nextNode;
    }
  }
  if (nextNode != NULL) {
    nextNode->next = curr->next;
    nextNode->prev = curr->prev;
    nextNode->size = curr->size - fullSize;
    nextNode->flag = 0;
  }
  curr->next = NULL;
  curr->prev = NULL;
  curr->flag = 1;
  curr->size = fullSize - sizeof(node_t);
}
void * exactMem(node_t * curr, size_t fullSize) {
  configMem(curr, fullSize, NULL);
  freeSize -= fullSize;
  return (void *)curr + sizeof(node_t);
}
void * splitMem(node_t * curr, size_t fullSize) {
  node_t * free = (node_t *)((void *)curr + fullSize);
  free->size = curr->size - fullSize;
  configMem(curr, fullSize, free);
  freeSize -= fullSize;
  return (void *)curr + sizeof(node_t);
}

void * newMem(size_t size) {
  size_t fullSize = size + sizeof(node_t);
  node_t * headNode = sbrk(fullSize);
  headNode->prev = NULL;
  headNode->next = NULL;
  headNode->flag = 1;
  headNode->size = size;
  void * beginData = (void *)headNode + sizeof(node_t);
  usedSize += fullSize;
  return beginData;
}
void * ff_malloc(size_t size) {
  node_t * curr = head;
  size_t fullSize = size + sizeof(node_t);
  while (curr != NULL) {
    if (fullSize == curr->size) {
      return exactMem(curr, fullSize);
    }
    if (fullSize < (curr->size)) {
      return splitMem(curr, fullSize);
    }
    curr = curr->next;
  }

  return newMem(size);
}

void * bf_malloc(size_t size) {
  node_t * curr = head;
  size_t fullSize = size + sizeof(node_t);
  node_t * temp = NULL;
  while (curr != NULL) {
    if (curr->size == size) {
      temp = curr;
      return exactMem(curr, fullSize);
    }
    else if (curr->size > size + sizeof(node_t)) {
      if (temp == NULL || (temp && temp->size > curr->size)) {
        temp = curr;
      }
      curr = curr->next;
    }
    else
      curr = curr->next;
  }
  if (temp) {
    return splitMem(temp, fullSize);
  }
  else
    return newMem(size);
}
void addToList(node_t * currNode) {
  //if a node is before the head, add the to the beginning of the list
  if (currNode < head) {
    currNode->next = head;
    currNode->prev = NULL;
    head->prev = currNode;
    head = currNode;
    currNode->flag = 0;
    return;
  }
  else {
    // case where node is after head
    node_t * nextNode = head;
    while (nextNode != NULL && currNode > nextNode) {
      nextNode = nextNode->next;
    }
    if (nextNode != NULL) {
      currNode->prev = nextNode->prev;
      currNode->next = nextNode;
      nextNode->prev->next = currNode;
      nextNode->prev = currNode;
    }
    else {
      tail->next = currNode;
      currNode->next = NULL;
      currNode->prev = tail;
      tail = currNode;
      currNode->flag = 0;
    }
  }
}

void merge(node_t * curr) {
  if (curr->prev == NULL && curr->next == NULL) {
    head = NULL;
    tail = NULL;
  }
  // if the free block is the first block in the list but there are free block after it

  else if (curr->prev == NULL && curr->next != NULL) {
    head = curr->next;
    head->prev = NULL;
  }
  //if the free bock is the last one in the list
  else if (curr->prev != NULL && curr->next == NULL) {
    tail = curr->prev;
    tail->next = NULL;
  }
  // in all other cases, empty block is in the midde of list
  else {
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
  }
}

void ff_free(void * ptr) {
  node_t * currNode = ptr - sizeof(node_t);
  //start the list
  if (head == NULL) {
    currNode->flag = 0;
    currNode->prev = NULL;
    currNode->next = NULL;
    head = currNode;
    tail = currNode;
    freeSize = currNode->size + sizeof(node_t);
    return;
  }
  //one list is created, keep adding free blocks
  freeSize += currNode->size + sizeof(node_t);
  addToList(currNode);

  if ((currNode->next != NULL &&
       (void *)currNode + currNode->size + sizeof(node_t) == (void *)currNode->next)) {
    currNode->size += currNode->next->size;
    merge(currNode->next);
  }

  if ((currNode->prev != NULL &&
       (void *)currNode->prev + currNode->prev->size + sizeof(node_t) ==
           (void *)currNode)) {
    currNode->prev->size += currNode->size;
    merge(currNode);
  }
}

void bf_free(void * ptr) {
  ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return usedSize;
}
unsigned long get_data_segment_free_space_size() {
  return freeSize;
}
