// memory allocation project
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

struct node_tag {
  size_t size;
  int flag;
  struct node_tag * next;
  struct node_tag * prev;
};
typedef struct node_tag node_t;

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

// Best Fir malloc/free
void * bf_malloc(size_t sie);
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
void merge(node_t * curr);
void addToList(node_t * currNode);
void * newMem(size_t size);
void * splitMem(node_t * curr, size_t fullSize);
void * exactMem(node_t * curr, size_t fullSize);
void configMem(node_t * curr, size_t fullSize, node_t * nextNode);
