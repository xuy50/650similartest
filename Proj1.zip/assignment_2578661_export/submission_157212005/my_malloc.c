#include "my_malloc.h"

ListNode * listHead = NULL;
unsigned long fullHeapSize = 0;
unsigned long freeListSize = 0;

void * ff_malloc(size_t size) {
  ListNode * curr = listHead;
  //printf("malloc\n");
  while (curr != NULL) {
    if (curr->size >= size) {
      if (curr->size > size + sizeof(ListNode)) {
        //split(curr, size);

        size_t tempSize = curr->size;
        curr->size = curr->size - (sizeof(ListNode) + size);
        freeListSize = freeListSize - sizeof(ListNode) - size;
        ListNode * newNode = (ListNode *)((char *)curr + curr->size + sizeof(ListNode));
        newNode->next = NULL;
        newNode->size = size;
        return (void *)((char *)newNode + sizeof(ListNode));
      }
      else {
        RemoveFromFreeList(curr);
        freeListSize = freeListSize - sizeof(ListNode) - curr->size;
        return (void *)((char *)curr + sizeof(ListNode));
      }
    }
    curr = curr->next;
  }
  return newSpace(size);
}

void ff_free(void * ptr) {
  if (ptr == NULL) {
    return;
  }
  ListNode * node = (ListNode *)((char *)ptr - sizeof(ListNode));
  if (listHead == NULL) {
    node->next = listHead;
    listHead = node;
    freeListSize += sizeof(ListNode) + node->size;
  }
  else {
    AddToFreeList(node);
  }
}

void * bf_malloc(size_t size) {
  ListNode * curr = listHead;
  ListNode * best = NULL;
  while (curr != NULL) {
    if (curr->size > size && (best == NULL || curr->size < best->size)) {
      best = curr;
    }
    if (curr->size == size) {
      best = curr;
      break;
    }
    curr = curr->next;
  }
  if (best != NULL) {
    if (best->size > size + sizeof(ListNode)) {
      size_t tempSize = best->size;
      best->size = best->size - (sizeof(ListNode) + size);
      freeListSize = freeListSize - (sizeof(ListNode) + size);
      ListNode * newNode = (ListNode *)((char *)best + best->size + sizeof(ListNode));
      newNode->next = NULL;
      newNode->size = size;
      return (void *)((char *)newNode + sizeof(ListNode));
    }
    else {
      RemoveFromFreeList(best);
      freeListSize = freeListSize - (sizeof(ListNode) + best->size);
      return (void *)((char *)best + sizeof(ListNode));
    }
  }
  return newSpace(size);
}

void bf_free(void * ptr) {
  ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return fullHeapSize;
}

unsigned long get_data_segment_free_space_size() {
  return freeListSize;
}

void RemoveFromFreeList(ListNode * node) {
  ListNode * curr = listHead;
  ListNode * prev = curr;
  curr = curr->next;
  if (node->size == prev->size) {
    listHead = curr;
    return;
  }
  while (curr != NULL) {
    if (curr->size == node->size) {
      prev->next = curr->next;
      return;
    }
    curr = curr->next;
    prev = prev->next;
  }
}

void AddToFreeList(ListNode * node) {
  freeListSize += sizeof(ListNode) + node->size;
  ListNode * curr = listHead;
  ListNode * prev = curr;
  curr = curr->next;
  if ((ListNode *)((char *)node + sizeof(ListNode) + node->size) <= prev) {
    //printf("add to front list\n");
    node->next = prev;
    listHead = node;
    mergeF(listHead, listHead->next);
    return;
  }
  while (curr != NULL) {
    if (node < curr) {
      //printf("add to middle list\n");
      node->next = curr;
      prev->next = node;

      mergeF(node, node->next);
      mergeF(prev, prev->next);
      return;
    }
    prev = prev->next;
    curr = curr->next;
  }
  //printf("add to back list\n");
  prev->next = node;
  mergeF(prev, prev->next);
  node->next = NULL;
  return;
}

void mergeF(ListNode * front, ListNode * back) {
  if ((ListNode *)((char *)front + sizeof(ListNode) + front->size) == back) {
    //    printf("merginggggggggggggggggggggggggggggggggggggggg\n");
    front->next = back->next;
    front->size = front->size + sizeof(ListNode) + back->size;
  }
}

void * newSpace(size_t size) {
  //printf(" ");
  ListNode * node = sbrk(size + sizeof(ListNode));
  if (node == (void *)-1) {
    return NULL;  // sbrk failed.
  }
  node->next = NULL;
  node->size = size;
  fullHeapSize = fullHeapSize + size + sizeof(ListNode);
  //freeListSize += size + sizeof(ListNode);
  return (void *)((char *)node + sizeof(ListNode));
}

void printList() {
  ListNode * curr = listHead;
  printf(" \n");
  while (curr != NULL) {
    printf("list: %p size: %ld\n", curr, curr->size);
    curr = curr->next;
  }
  printf(" \n");
}

int main() {
  void * t1 = ff_malloc(50);
  ff_free(t1);
  printList();
  void * t2 = ff_malloc(10);
  printList();
  void * t3 = ff_malloc(50);
  void * t4 = ff_malloc(50);
  void * t5 = ff_malloc(50);

  ff_free(t2);
  printList();
  ff_free(t5);
  printList();
  ff_free(t4);
  printList();
  ff_free(t3);
  printList();
  return 0;
}
