#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct listnode {
  size_t size;
  struct listnode * next;
};

typedef struct listnode ListNode;

//first fit
void * ff_malloc(size_t size);
//free first fit
void ff_free(void * ptr);
//best fit
void * bf_malloc(size_t size);
//free best fit
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();

//helper functions
void split(ListNode * node, size_t size);
void RemoveFromFreeList(ListNode * node);
void AddToFreeList(ListNode * node);
void * newSpace(size_t size);
void mergeF(ListNode * front, ListNode * back);
void ff_free(void * ptr);
void bf_free(void * ptr);
