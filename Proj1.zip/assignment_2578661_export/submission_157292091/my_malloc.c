#include "my_malloc.h"
#include <assert.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
block *head = NULL;
block *tail = NULL;
unsigned long data_segment_size = 0;

block *find_free_block(block *current, size_t size) {
  if (current) {
    if (current->size >= size)
      return current;
    else {
      if (current->next) {
        return find_free_block(current->next, size);
      } else
        return NULL;
    }
  }
  return NULL;
}

block *request_space(size_t size) {
  block *new_block;
  new_block = sbrk(0);
  void *request = sbrk(BLOCK_SIZE + size);
  data_segment_size += BLOCK_SIZE + size;
  if (request == (void *)-1)
    return NULL;
  new_block->size = size;
  new_block->next = NULL;
  new_block->prev = NULL;
  return new_block;
}

void *split(block *curr, size_t size) {
  block *tmp = (block *)((char *)curr + size + BLOCK_SIZE);
  tmp->size = curr->size - size - BLOCK_SIZE;
  return tmp;
}

block *find_best_block(size_t size) {
  block * curr = head;
  block * res = NULL;
  while (curr) {
    if (curr->size == size) return curr;
    else if (curr->size > size) {
      if (!res || curr->size < res->size) res = curr;
    }
    curr = curr->next;
  }
  return res;
}

void *ff_malloc(size_t size) {
  block *new_block = NULL;
  if (size <= 0)
    return NULL;
  new_block = find_free_block(head, size);
  if (!new_block) {
    new_block = request_space(size);
  } else {
    if (size + BLOCK_SIZE >= new_block->size) {
      if (new_block == head) {
        head = new_block->next;
        if (head)
          head->prev = NULL;
      } else if (new_block == tail) {
        tail = new_block->prev;
        if (tail)
          tail->next = NULL;
      } else {
        new_block->prev->next = new_block->next;
        new_block->next->prev = new_block->prev;
        new_block->next = NULL;
        new_block->prev = NULL;
      }
    } else {
      block *tmp = split(new_block, size);
      new_block->size = size;
      if (new_block == head) {
        head = tmp;
        head->prev = NULL;
        tmp->next = new_block->next;
        if (tmp->next)
          tmp->next->prev = tmp;
      } else if (new_block == tail) {
        tail = tmp;
        tail->next = NULL;
        tmp->prev = new_block->prev;
        if (tmp->prev != NULL)
          tmp->prev->next = tmp;
      } else {
        tmp->prev = new_block->prev;
        tmp->next = new_block->next;
        tmp->prev->next = tmp;
        tmp->next->prev = tmp;
      }
    }
  }
  return new_block + 1;
}

void merge(block *block1, block *block2) {
  if (!block1 || !block2)
    return;
  if (((char *)block1 + block1->size + BLOCK_SIZE) == (char *)block2) {
    block1->size += (BLOCK_SIZE + block2->size);
    if (block2->next == NULL) {
      tail = block1;
      block1->next = NULL;
    } else {
      block2->next->prev = block1;
      block1->next = block2->next;
    }
    block2->next = NULL;
    block2->prev = NULL;
    block2 = NULL;
  }
}

void ff_free(void *ptr) {
  if (!ptr)
    return;
  block *block_ptr = (block *)ptr - 1;
  if (!head) {
    head = block_ptr;
    tail = block_ptr;
    block_ptr->next = NULL;
    block_ptr->prev = NULL;
  } else {
    block *curr = head;
    while (curr) {
      // add to tail
      // check if block_pointer is greater than list tail
      if (tail) {
        if ((char *)block_ptr >= (char *)tail + BLOCK_SIZE + tail->size) {
          tail->next = block_ptr;
          block_ptr->prev = tail;
          block_ptr->next = NULL;
          tail = block_ptr;
          break;
        }
      }
      // add to head
      // check if block_pointer is smaller than list head
      if (head) {
        if ((char *)block_ptr + BLOCK_SIZE + block_ptr->size <= (char *)head) {
          block *tmp_head = head;
          block_ptr->next = tmp_head;
          tmp_head->prev = block_ptr;
          head = block_ptr;
          break;
        }
      }
      // add to not head not tail
      if ((char *)curr > (char *)block_ptr + BLOCK_SIZE + curr->size) {
        block *prev = curr->prev;
        block *next = curr;
        prev->next = block_ptr;
        block_ptr->prev = prev;
        block_ptr->next = next;
        next->prev = block_ptr;
        break;
      } else {
        // printf("not found, see next \n");
        curr = curr->next;
      }
    }
    // printf("out of while loop \n");
  }
  // for merge
  //  merge(block_ptr, block_ptr->next, block_ptr->prev);
  if (head == block_ptr)
    merge(block_ptr, block_ptr->next);
  else if (tail == block_ptr)
    merge(block_ptr->prev, block_ptr);
  else {
    merge(block_ptr, block_ptr->next);
    merge(block_ptr->prev, block_ptr);
  }
  return;
}

void bf_free(void *ptr) {
  ff_free(ptr);
  return;
}

unsigned long get_data_segment_size() { return data_segment_size; }

unsigned long get_data_segment_free_space_size() {
  block *curr = head;
  unsigned long res = 0;
  while (curr) {
    res += curr->size;
    res += BLOCK_SIZE;
    curr = curr->next;
  }
  return res;
}

void show_list() {
  block *curr = head;
  int count = 0;
  while (curr) {
    printf("node address: %p, node size: %lu \n", curr, curr->size);
    curr = curr->next;
    count ++;
  }
  printf("meta size is: %lu \n", BLOCK_SIZE);
  printf("number of nodes is: %d \n", count);
}

void *bf_malloc(size_t size) {
  block *new_block = NULL;
  if (size <= 0)
    return NULL;
  new_block = find_best_block(size);
  if (!new_block) {
    new_block = request_space(size);
  } else {
    if (size + BLOCK_SIZE >= new_block->size) {
      if (new_block == head) {
        head = new_block->next;
        if (head)
          head->prev = NULL;
      } else if (new_block == tail) {
        tail = new_block->prev;
        if (tail)
          tail->next = NULL;
      } else {
        new_block->prev->next = new_block->next;
        new_block->next->prev = new_block->prev;
        new_block->next = NULL;
        new_block->prev = NULL;
      }
    } else {
      block *tmp = split(new_block, size);
      new_block->size = size;
      if (new_block == head) {
        head = tmp;
        head->prev = NULL;
        tmp->next = new_block->next;
        if (tmp->next)
          tmp->next->prev = tmp;
      } else if (new_block == tail) {
        tail = tmp;
        tail->next = NULL;
        tmp->prev = new_block->prev;
        if (tmp->prev != NULL)
          tmp->prev->next = tmp;
      } else {
        tmp->prev = new_block->prev;
        tmp->next = new_block->next;
        tmp->prev->next = tmp;
        tmp->next->prev = tmp;
      }
    }
  }
  return new_block + 1;
}

int main() {
  char *myChar = ff_malloc(sizeof myChar);
  ff_free(myChar);
  return EXIT_SUCCESS;
}
