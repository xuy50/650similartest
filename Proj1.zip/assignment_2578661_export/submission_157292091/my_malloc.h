#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>


//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);
void show_list();

unsigned long get_data_segment_size(); //in bytes
unsigned long get_data_segment_free_space_size(); //in byte

typedef struct block_t block;
struct block_t {
  size_t size;
  block *next;
  block *prev;
  // int free;
};

// block *find_free_block(block * current, size_t size, size_t visited);
// block *request_space(size_t size);

// #define IS_FREE 1
// #define NOT_FREE 0
#define BLOCK_SIZE sizeof(block)


