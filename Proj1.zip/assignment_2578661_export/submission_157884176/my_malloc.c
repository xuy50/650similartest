#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "my_malloc.h"

Metadata * head = NULL;
Metadata * tail = NULL;
unsigned long seg_size = 0;
unsigned long free_size = 0;

void remove_free(Metadata * curr) {
  if (head ==  NULL && tail == NULL){
    return;
  }

  else if (head == tail) {
    head = NULL;
    tail = NULL;
    curr -> next = NULL;
    curr -> prev = NULL;
  }

  else if (head == curr) {
    head = curr -> next;
    head -> prev = NULL;
    curr ->next = NULL;
  }

  else if (tail == curr){
    tail = curr -> prev;
    tail -> next = NULL;
    curr -> prev = NULL;
  }

  else { //curr is in middle
    curr->prev -> next = curr-> next;
    curr->next ->prev = curr->prev;
    curr->next = NULL;
    curr->prev = NULL;
  }
}


void insert_free(Metadata * free_after_split) {
  if (head == NULL && tail == NULL) {
    head = free_after_split;
    tail = free_after_split; //added
    free_after_split -> prev = NULL;
    free_after_split -> next = NULL;
    //printf("insert_first_if\n");
    //break;
  }
  else if (free_after_split <head) {
    free_after_split -> next = head;
    free_after_split -> prev = NULL;
    head -> prev = free_after_split;
    head = free_after_split;
  }

  else if (free_after_split > tail) {
    free_after_split -> next = NULL;
    free_after_split -> prev = tail;
    tail -> next = free_after_split;
    tail = free_after_split;
  }

  else {
    Metadata * temp = head;
    while (temp < free_after_split && temp !=  NULL) {
      temp = temp -> next;
    }
    free_after_split ->next = temp;
    free_after_split -> prev = temp ->prev;
    temp -> prev -> next = free_after_split;
    temp -> prev = free_after_split;
  }
  
}

void * ff_malloc(size_t size) {  
  Metadata * curr = head;
  while (curr) {
    if (curr->size > size + sizeof(Metadata)) { //splitting case
      Metadata * free_after_split = (Metadata*) ((void*)curr + sizeof(Metadata) + size);
      free_after_split -> size = curr->size - sizeof(Metadata) - size;
      remove_free(curr);
      curr->size = size;
      insert_free(free_after_split);
      return (void*) curr + sizeof(Metadata);
    }

    if (curr->size >= size && curr->size <size+sizeof(Metadata)) { //incapable of filling metadata
      remove_free(curr);
      return (void*) curr + sizeof(Metadata);
    }

    curr = curr -> next;
  }	
      
   
  //incapcable of filling data
  Metadata * new_block = sbrk(size+sizeof(Metadata));
  new_block ->size = size;
  new_block -> prev = NULL;
  new_block -> next = NULL;
  seg_size = seg_size + sizeof(Metadata) +size;
  return (void*)new_block + sizeof(Metadata);
      
} 




void merge_free(Metadata * meta_addr) {
  //next then prev
  if (meta_addr -> next != NULL && (void*)meta_addr + sizeof(Metadata) + meta_addr ->size == (void*) meta_addr->next) {
    meta_addr -> size = meta_addr -> size + sizeof(Metadata) + meta_addr->next->size;
    remove_free(meta_addr->next);
  }

  if (meta_addr -> prev != NULL && (void*)meta_addr -> prev + sizeof(Metadata) + meta_addr -> prev -> size == (void*) meta_addr) {
    meta_addr->prev->size = meta_addr->prev->size + sizeof(Metadata) + meta_addr ->size;
    remove_free(meta_addr);
  }
}

void ff_free(void * ptr) {
  Metadata * meta_addr = (Metadata *) ((void*)ptr - sizeof(Metadata)); //addr of metadata
  insert_free(meta_addr);

  merge_free(meta_addr);
} 


void * bf_malloc(size_t size) {
  if (head!=NULL){
    Metadata * curr = head;
    Metadata * smallest = NULL;
  
    while (curr) { //curr!=NULL
      if (smallest == NULL) {
	smallest = curr;
      }

      if (curr->size > size) {
	if (smallest -> size > curr -> size) {
	  smallest = curr;
	}
      }

      if (curr-> size == size) {
	smallest = curr;
	break;
      }

      curr = curr -> next;
    }
    
    //printf("should find smallest here\n");
    if (smallest->size > size + sizeof(Metadata)) { //splitting case
      Metadata * free_after_split = (Metadata*) ((void*)smallest + sizeof(Metadata) + size);
      free_after_split -> size = smallest->size - sizeof(Metadata) - size;
      remove_free(smallest);
      smallest->size = size;
      insert_free(free_after_split);
      //printf("split case\n");
      return (void*) smallest + sizeof(Metadata);
    }
    
    if (smallest->size >= size && smallest->size <size+sizeof(Metadata)) { //incapable of filling metadata
      remove_free(smallest);
      //printf("perfect fill in case\n");
    return (void*) smallest + sizeof(Metadata);
    }
  } 
  

  //incapcable of filling data
  Metadata * new_block = sbrk(size+sizeof(Metadata));
  new_block ->size = size;
  new_block -> prev = NULL;
  new_block -> next = NULL;
  seg_size = seg_size + sizeof(Metadata) +size;
  //printf("sbrk case\n");
  return (void*)new_block + sizeof(Metadata);
  
}


void bf_free(void *ptr) {
  return ff_free(ptr);
}

unsigned long get_data_segment_size() {
  return seg_size;
}

unsigned long get_data_segment_free_space_size() {
  Metadata * check = head;
  while (check) {
    free_size = free_size + sizeof(Metadata) + check->size;
    check = check -> next;
  }
  return free_size; 
}



