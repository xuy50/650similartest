#include <stdio.h>
#include <stdlib.h>

struct metadata {
  size_t size;
  struct metadata * next;
  struct metadata * prev;
};
typedef struct metadata Metadata;

void remove_free(Metadata * curr);
void insert_free(Metadata * free_after_split);
void merge_free(Metadata * meta_addr);
void * ff_malloc(size_t size);
void ff_free(void * ptr);
void * bf_malloc(size_t size);
void bf_free(void * ptr);
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
 
