# Proj1 Report - Malloc Allocation Memory    
**Jiajun Yu, jy261**    
**ECE650, Spring 2023, Duke University** 

## Introduction and Implementation
In this project, I implement the memory allocation functions in C library: `malloc()` and `free()`. There are two versions of them, one is first fit, the other one is best fit. The data structure I used is doubly linekd list to store the free blocks. Each block contains the metadata of the block and the block that used to store data. The metadata is defined by a struct with basic infomation: `size_t size, Metadata * prev, Metadata * next`. Note that the `size` only refers to the size of the block itself, exclusive of the size of metadata `sizeof(Metadata)`.

To implement the `malloc()` function, I use the method of increment development and abstraction. Basically, we need to check in our free linked list that if there is one block (node) can allocate the given data size. If there is, we need to proceed on checking whether the size of this block plus its metadata size is far larger then the given size. If it is, extra free place would be wasted. So, we need to split the block into two parts: one for user use, the other we put it back to the linked list. Here `remove` and `insert` subfunctions are created. If the size of the extra place is smaller than size of metadata (which is fixed), then no need to put it back into the linked list. We just give the whole block to user. If there is no block can allocate the user size, we call `sbrk()` function which allocates a new block defined with size we want. 

To implement the `free()` function, we just need to free the block that is required by the user with `*ptr`. To obtain the metadata address, use `(void*) ptr - sizeof (Metadata)`, then we know which block to free. I also check if next to/prev to the current block is free or not. If it is free, merge it with the current block. Note that checking the next block first, then the previous one.

Above I introduce the method of first fit. For best fit, I introduced a `Metadata * smallest` to keep track of the block with the smallest size that can fit user data. If found, return it. The bf `free()` function is the same with ff's.

## Results and Analysis
The execution time and fragmentation for ff test cases are:   
`small: 14.75s, 0.08    
 equal: 14.99s, 0.45   
 large: 54.86s, 0.09` 
 
 For bf:   
 `small: 4.99s, 0.02    
  equal: 15.12s, 0.45   
  large: 60.49s, 0.04`   
  
For equal test, the size of every block in the free list is fixed. Thus for ff and bf methods it takes the similar execution time to find proper block. Both fragmentation show 0.45, which is reasonable because it is calculated halfway. For small test, the execution time for bf shows it runs much faster than ff method. This is because ff method calls `sbrk()` more frequently than bf. And it is clearly shown in this case, the `sbrk()` function dominates more than iterating the free list and searching for the best-fit one. For large case, bf takes more time than ff. Opposite to the small case, here the iteration dominates more than `sbrk()`, because the size of each block is large, it takes more time to search than merely create a new block and allocate size. Therefore, for different scenarios there may vary diffrerent methods to achieve efficiency.


