#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
typedef struct _memory_block memory_block;
struct _memory_block
{
    size_t size;
    memory_block *prev;
    memory_block *next;
};
memory_block *head = NULL;
memory_block *tail = NULL;
const size_t block_size = sizeof(memory_block);
unsigned long data_segment_size = 0;
unsigned long data_segment_free_size = 0;
memory_block *merge(memory_block *p, memory_block *c);
void split(memory_block *c, size_t size);
void remove_block(memory_block *b);
memory_block *increase_segment(size_t size);
void *malloc_block(memory_block *b, size_t size);
void insert_block(memory_block *b);
memory_block *find_first_fit_block(size_t size);
memory_block *find_best_fit_block(size_t size);
int adjacent_block(memory_block *p, memory_block *c);
void free_block(void *ptr);
void *ff_malloc(size_t size);
void ff_free(void *ptr);
void *bf_malloc(size_t size);
void bf_free(void *ptr);
void printList();
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();