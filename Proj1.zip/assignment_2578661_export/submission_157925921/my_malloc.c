#include "my_malloc.h"
int malloc_times = 0;
int free_times = 0;
memory_block *merge(memory_block *p, memory_block *c)
{
    p->size += c->size + block_size;
    if (c == tail)
        tail = p;
    else
        c->next->prev = p;
    p->next = c->next;
    return p;
}
void split(memory_block *c, size_t size)
{
    // printf("block_size:%ld, malloc_size:%ld\n", c->size, size);
    memory_block *b;
    b = (memory_block *)((void *)c + block_size + size);
    b->size = c->size - block_size - size;
    b->prev = c;
    b->next = c->next;
    c->size = size;
    if (c == tail)
        tail = b;
    else
        c->next->prev = b;
    c->next = b;
}
void remove_block(memory_block *b)
{
    if (b == head)
        head = b->next;
    if (b == tail)
        tail = b->prev;
    if (b->prev != NULL)
        b->prev->next = b->next;
    if (b->next != NULL)
        b->next->prev = b->prev;
    b->prev = b->next = NULL;
}
memory_block *increase_segment(size_t size)
{
    memory_block *b = (memory_block *)sbrk(0);
    if (sbrk(block_size + size) == (void *)-1)
        return NULL;
    if (tail != NULL)
    {
        tail->next = b;
        b->prev = tail;
        b->next = NULL;
    }
    else
    {
        head = b;
        tail = b;
        b->prev = NULL;
        b->next = NULL;
    }
    b->size = size;
    data_segment_free_size += size + block_size;
    data_segment_size += size + block_size;
    return b;
}
void *malloc_block(memory_block *b, size_t size)
{
    if (b == NULL)
        b = increase_segment(size);
    if (b == NULL)
        return NULL;
    if (b->size - size > block_size)
    {
        split(b, size);
        data_segment_free_size -= (block_size + size);
    }
    else
        data_segment_free_size -= (block_size + b->size);
    remove_block(b);
    // printf("block_address:%p, block_size:%ld\n", b, b->size);
    return ((void *)b + block_size);
}
void insert_block(memory_block *b)
{
    if (head == NULL)
    {
        head = b;
        tail = b;
        b->prev = NULL;
        b->next = NULL;
        return;
    }
    memory_block *p = head;
    // printList();
    while (p != NULL && b > p)
        // printf("insert:%p, insert_size:%ld, list:%p, list_size:%ld, tail:%p, tail_size:%ld\n", b, b->size, p, p->size, tail, tail->size);
        p = p->next;
    b->next = p;
    if (p == NULL)
    {
        b->prev = tail;
        tail->next = b;
        tail = b;
    }
    else
    {
        if (p == head)
            head = b;
        else
            p->prev->next = b;
        b->prev = p->prev;
        p->prev = b;
    }
}
memory_block *find_first_fit_block(size_t size)
{
    memory_block *p = head;
    while (p != NULL)
    {
        // printf("list block:%p, block_size:%ld, need_size:%ld\n",p,p->size,size);
        if (p->size >= size)
            return p;
        p = p->next;
    }
    return NULL;
}
memory_block *find_best_fit_block(size_t size)
{
    memory_block *p = head;
    memory_block *b = NULL;
    while (p != NULL)
    {
        if (p->size >= size && (b == NULL || p->size < b->size))
            b = p;
        if (b != NULL && b->size == size)
            return b;
        p = p->next;
    }
    return b;
}
int adjacent_block(memory_block *p, memory_block *c)
{
    if (p == NULL || c == NULL)
        return 0;
    if (((void *)p + block_size + p->size) == (void *)c)
        return 1;
    else
        return 0;
}
void free_block(void *ptr)
{
    memory_block *b = (memory_block *)(ptr - block_size);
    // printf("block_size:%ld, prev:%p, next:%p\n",b->size,b->prev,b->next);
    insert_block(b);
    data_segment_free_size += b->size + block_size;
    if (adjacent_block(b->prev, b) == 1)
        b = merge(b->prev, b);
    if (adjacent_block(b, b->next) == 1)
        b = merge(b, b->next);
}
void *ff_malloc(size_t size)
{
    memory_block *p = find_first_fit_block(size);
    // if (p != NULL)
    //     printf("find block address:%p, block_size:%ld, need_size:%ld\n", p, p->size, size);
    void *m = malloc_block(p, size);
    // printf("malloc address:%p, size:%ld, time:%d, total_size:%ld\n", (memory_block *)m, size, ++malloc_times, data_segment_size);
    // printList();
    return m;
}
void ff_free(void *ptr)
{
    // printf("free address:%p, times:%d\n", ptr - block_size, ++free_times);
    free_block(ptr);
}
void *bf_malloc(size_t size)
{
    memory_block *p = find_best_fit_block(size);
    return malloc_block(p, size);
}
void bf_free(void *ptr)
{
    free_block(ptr);
}
unsigned long get_data_segment_size()
{
    return data_segment_size;
}
unsigned long get_data_segment_free_space_size()
{
    return data_segment_free_size;
}
void printList()
{
    memory_block *p = head;
    while (p != NULL)
    {
        printf("(%p,%ld),", p, p->size);
        p = p->next;
    }
    printf("%p\n", tail);
}