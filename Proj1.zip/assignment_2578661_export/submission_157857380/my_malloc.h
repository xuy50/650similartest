#include <stdio.h>



typedef struct block_h
{
      struct block_h *pre;
      struct block_h *next;
      size_t size;
} block;


// First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);

// Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();            
unsigned long get_data_segment_free_space_size(); 

void *splitBlock(block *cur, size_t size);

void *useSbrk(size_t size);

void insertIntoFreeList(block *cur);
void deleteFromFreeList(block *cur);

void mergeBack(block *cur);

