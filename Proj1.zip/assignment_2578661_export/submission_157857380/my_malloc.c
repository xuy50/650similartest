#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>

#include "my_malloc.h"

unsigned long totalFreeSize = 0;
unsigned long totalSize = 0;

// freelist
block *freeHead = NULL;
block *freeTail = NULL;

void *useSbrk(size_t size)
{
      void *ptr = sbrk(size + sizeof(block));
      if (ptr == (block *)-1)
      {
            return NULL;
      }

      block *newBlock = ptr;
      newBlock->pre = NULL;
      newBlock->next = NULL;
      newBlock->size = size;

      totalSize += size + sizeof(block);

      return (void *)newBlock + sizeof(block); 
}

void insertIntoFreeList(block *cur)
{
      if (!freeHead || !freeTail) // Empty List
      {
            freeHead = cur;
            freeTail = cur;
            return;
      }
      else
      {
            block *temp = freeHead;

            if (temp >= cur) 
            {
                  cur->next = temp;
                  temp->pre = cur;
                  freeHead = cur;
                  cur->pre = NULL;
            }

            else if (temp < cur && !temp->next)
            {
                  temp->next = cur;
                  cur->pre = temp;
                  cur->next = NULL;
                  freeTail = cur;
            }

            else // temp < cur && temp->next != null
            {

                  while (temp < cur && temp != freeTail) 
                  {
                        if (temp->next >= cur)
                        {
                              block *tempNext = temp->next;
                              cur->pre = temp;
                              temp->next = cur;
                              cur->next = tempNext;
                              tempNext->pre = cur;
                              return;
                        }
                        else if (temp->next == freeTail && freeTail < cur)
                        {
                              temp = freeTail;
                              temp->next = cur;
                              cur->pre = temp;
                              cur->next = NULL;
                              freeTail = cur;
                              return;
                        }
                        else
                        {
                              temp = temp->next;
                        }
                  }
            }
      }
}

void deleteFromFreeList(block *cur)
{
      block *curPre = cur->pre; 
      block *curNext = cur->next;
      if (cur->pre == NULL && cur->next == NULL)
      {
            freeHead = NULL;
      }

      else if (cur->pre == NULL)
      {
            freeHead = cur->next;
            freeHead->pre = NULL;
            cur->next = NULL;
      }
      else if (cur->next == NULL)
      {
            freeTail = cur->pre;
            freeTail->next = NULL;
            cur->pre = NULL;
      }
      else
      {
            curPre->next = cur->next;
            curNext->pre = cur->pre;
            cur->pre = NULL;
            cur->next = NULL;
      }
}


void mergeBack(block *cur)
{
      if (cur->next && (void *)cur + sizeof(block) + cur->size == (void *)cur->next) 
      {
            block *curNext = cur->next;

            cur->size = cur->size + sizeof(block) + curNext->size;
            if (curNext->next == NULL)
            {

                  cur->next = NULL;
                  freeTail = cur;
            }
            else
            {

                  block *curNextNext = curNext->next;
                  cur->next = curNext->next;
                  curNextNext->pre = cur;
            }
      }

      if (cur->pre && (void *)cur->pre + sizeof(block) + cur->pre->size == (void *)cur)
      {
            block *curNext = cur;
            cur = cur->pre;

            cur->size = cur->size + sizeof(block) + curNext->size;
            if (curNext->next == NULL)
            {
                  cur->next = NULL;
                  freeTail = cur;
            }
            else
            {
                  block *curNextNext = curNext->next;
                  cur->next = curNext->next;
                  curNextNext->pre = cur;
            }
      }
}

void *splitBlock(block *cur, size_t size)
{
      if (cur->size - size <= sizeof(block)) 
      {
            deleteFromFreeList(cur);
            totalFreeSize -= size + sizeof(block);
            return (void *)cur + sizeof(block);
      }
      else
      {
            block *newBlock = (void *)cur + sizeof(block) + size;

            newBlock->size = cur->size - size - sizeof(block); 
            newBlock->next = NULL;
            newBlock->pre = NULL;

            cur->size = size;

            deleteFromFreeList(cur);

            insertIntoFreeList(newBlock);

            totalFreeSize -= size + sizeof(block);

            return (void *)cur + sizeof(block); 
      }
}

// First Fit malloc/free
void *ff_malloc(size_t size)
{
      if (freeHead == NULL)
      {
            return useSbrk(size);
      }

      block *cur = freeHead;
      while (cur)
      {
            if (cur->size < size && cur->next != NULL)
            {
                  cur = cur->next;
            }
            else if (cur->size < size && cur->next == NULL)
            {
                  return useSbrk(size);
            }
            else if (cur->size >= size)
            {
                  break;
            }

      } // find first fit

      if (cur)
      {
            return splitBlock(cur, size);
      }
}

void ff_free(void *ptr)
{

      if (ptr == NULL)
      {
            return;
      }
      block *cur = (void *)ptr - sizeof(block);

      totalFreeSize += cur->size + sizeof(block);
      insertIntoFreeList(cur);
      mergeBack(cur);
}

// Best Fit malloc/free
void *bf_malloc(size_t size)
{
      if (!freeHead)
      {
            return useSbrk(size);
      }

      block *cur = freeHead;
      block *t = freeHead;

      while (cur)
      {
            if (cur->size < size && cur->next != NULL)
            {
                  cur = cur->next;
            }
            else if (cur->size < size && cur->next == NULL)
            {
                  return useSbrk(size);
            }
            else if (cur->size == size)
            {
                  t = cur;
                  break;
            }
            else if (cur->size > size && cur == freeHead)
            {
                  cur = cur->next;
            }
            else if (cur->size > size)
            {
                  if (cur->size - size < t->size - size)
                  {
                        t = cur;
                  }
                  cur = cur->next;
            }
      }

      if (t)
      {
            return splitBlock(t, size);
      }
      else
      {
            return useSbrk(size);
      }
}

void bf_free(void *ptr)
{

      ff_free(ptr);
}

unsigned long get_data_segment_size()
{
      return totalSize;
}
unsigned long get_data_segment_free_space_size()
{
      return totalFreeSize;
}
