#include "my_malloc.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

//define basic varable
//head is the head of free block lists
metaInfo * head=NULL;
metaInfo * firstFreeRegion=NULL;
metaInfo * bestFreeRegion=NULL;

size_t heapSize = 0;
size_t freeSize = 0;

//help function for malloc/free
/* 
The innate character of metaInfo is linkedlist of freed memory blocks
The add and remove are basic operators in linkedlist
add or rmv the block which contains metaInfo in linkedlist
 */


void addBlock(metaInfo * m){
    //we need to change the head
    //if add as the first block 
    if (head == NULL){
        head=m;
    }
    //if add before head
    else if(m<head){
        m->next=head;
        head->prev=m;
        head=m;
    }
    //we dont need to change the head
    //if add after head
    else{
        //find proper position in order
        metaInfo * curr=head;
        while(curr->next!=NULL){
            if (m <= curr->next){
                break;
            }else{
                curr = curr->next;
            }
        }
        m->prev=curr;
        m->next=curr->next;
        curr->next=m;
        if (m->next != NULL){
            m->next->prev=m;
        }
    }
    connectBlock(m);
}
//if two free regions connected
//in physical address
//need to check the next and prev
void connectBlock(metaInfo * m){
    //if the next block is adjacent
    if (m->next!=NULL){
        if ((char *)m->next==(char *)m+m->size+METAINFO_SIZE){
            m->size = m->size + METAINFO_SIZE + m->next->size;
            rmvBlock(m->next);
        }
    }
    //if the prev block is adjacent
    if (m->prev!=NULL){
        if ((char *)m==(char *)m->prev+m->prev->size+METAINFO_SIZE){
            m->prev->size = m->size + METAINFO_SIZE + m->prev->size;
            rmvBlock(m);
        }
    }
}
//if the block is used, then remove this block from the linkedlist
void rmvBlock(metaInfo * m){
    //if we remove the first one
    if (head==m){
        head=m->next;
        //if first is not the only one
        //next block exists
        if (head != NULL){
            head->prev=NULL;
            m->next=NULL;//
        }
        //else if the removed first region is only one
        //latter first region is NULL
    }
    //if the next of the block is NULL
    //means we'r removing the last one
    else if(m->next==NULL){
        m->prev->next=NULL;
        m->prev=NULL;//
    }
    //if we remove the middle one
    else{
        m->next->prev=m->prev;
        m->prev->next=m->next;
        m->prev=NULL;//
        m->next=NULL;//
    }
}

//free help function, set is_free as 1 and 
//add block to linkedlist and check connectivity
void myfree(void *ptr){
    metaInfo * m = (metaInfo *)((char *)ptr-METAINFO_SIZE);
    // freeSize += (m->size+METAINFO_SIZE);
    m->next=NULL;
    m->prev=NULL;
    addBlock(m);
}
//if cannot find a free region
//use sbrk to ask for more space
//return the real pointer
void * requestSpace(size_t size){
    // printf("requestingSpace\n");
    //ask for space and assign to firstFreeRegion
    heapSize += (size+METAINFO_SIZE);
    metaInfo * ans = sbrk(size+METAINFO_SIZE);
    ans->prev=NULL;
    ans->next=NULL;
    ans->size=size;
    return (char *)ans+METAINFO_SIZE;
}
void spltBlock(metaInfo * curr,size_t size){
    metaInfo * newBlk=(metaInfo *)((char *)curr+METAINFO_SIZE+size);
    newBlk->size=curr->size-size-METAINFO_SIZE;
    newBlk->next=NULL;
    newBlk->prev=NULL;
    // freeSize = freeSize - (size);
    curr->size=size;
    rmvBlock(curr);
    addBlock(newBlk);    
}

//use this free region
//return the ptr
void * useSpace(metaInfo * curr ,size_t size){
    // printf("usingSpace\n");
    //condition 1:splitting
    //change the size and start point of current block
    if (curr->size > size + METAINFO_SIZE){
        // printf("Enough space:%ld vs %ld:\n",curr->size,size);
        spltBlock(curr,size);
    } 
    //condition 2:no split
    //simply remove this part
    else {
        // freeSize = freeSize - (curr->size+METAINFO_SIZE);
        // printf("Less space:%ld vs %ld:\n",curr->size,size);
        curr->size=size;
        rmvBlock(curr);  
    }
    //done the ff-malloc, exit the function
    //return the pointer to malloc staff
    return (char *)curr+METAINFO_SIZE;
}

void find_ff(size_t size){
    metaInfo * curr=head;
    while (curr!=NULL){
        if (curr->size >= size){
            firstFreeRegion=curr;
            return;
        }else{
            curr=curr->next;
        }
    }
    firstFreeRegion=NULL;
    return;
}
void find_bf(size_t size){
    bestFreeRegion=NULL;
    size_t min_delta=INT_MAX;
    metaInfo * curr=head;
    while (curr!=NULL){
        if (curr->size > size){
            //compare it with the best free region
            if (min_delta>(curr->size-size)){
                bestFreeRegion=curr;
                min_delta=curr->size-size;
            }
        }else if(curr->size == size){
            bestFreeRegion=curr;
            return;
        }
        //go through all blocks
        curr=curr->next;
    }
}

//First Fit malloc/free
void *ff_malloc(size_t size){
    find_ff(size);
    if (firstFreeRegion==NULL){
        return requestSpace(size);
    }else{
        return useSpace(firstFreeRegion,size);
    }
}
void ff_free(void *ptr){
    myfree(ptr);
}
//Best Fit malloc/free
void *bf_malloc(size_t size){
    find_bf(size);
    if (bestFreeRegion==NULL){
        return requestSpace(size);
    }else{
        return useSpace(bestFreeRegion,size);
    }
}
void bf_free(void *ptr){
    myfree(ptr);
}

//entire heap memory-in byte
unsigned long get_data_segment_size(){
    return heapSize;
} 
//size of free list-in byte
unsigned long get_data_segment_free_space_size(){
    size_t freeSize=0;
    metaInfo * curr=head;
    while(curr!=NULL){
        freeSize+=curr->size+METAINFO_SIZE;
        curr=curr->next;
    }
    return freeSize;
} 

