#include <stdio.h>
#include <stdlib.h>
/* 
------end of block
0x1030
0x1020
-------data begin(up)
0x1010
-------metaInfo begin(up)
0x1000
*/
// void *sbrk(intptr_t increment);
// void *malloc(size_t size);
// void free(void *ptr);

//define a struct to store meta infomation
//This struct just like linkedlist
//company with add and remove operations
// is_free default value is 0, means not free
struct _metaInfo{
    size_t size;
    struct _metaInfo * prev;
    struct _metaInfo * next;
    //position need to be considered
};
typedef struct _metaInfo metaInfo;
#define METAINFO_SIZE sizeof(metaInfo)

//help function for malloc/free
void addBlock(metaInfo * m);
void rmvBlock(metaInfo * m);
void connectBlock(metaInfo * m);
void myfree(void *ptr);
void * requestSpace(size_t size);
void spltBlock(metaInfo * curr,size_t size);
void * useSpace(metaInfo * curr, size_t size);

void find_ff(size_t size);
void find_bf(size_t size);
//Malloc is implemented in two ways
//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);
//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

//additional
//in bytes
//entire heap memory-heapsize
unsigned long get_data_segment_size(); 
//size of free list-freesize
unsigned long get_data_segment_free_space_size(); 