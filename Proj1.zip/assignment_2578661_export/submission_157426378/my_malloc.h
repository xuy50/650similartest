#ifndef __MY_MALLOC__
#define __MY_MALLOC__

#include <stdlib.h>
#include <unistd.h>

// Metadata of each allocated/freed block
typedef struct MetaData_tag {
  size_t size;
  void * next;
} MetaData;

#define METADATA_SIZE sizeof(MetaData)

//global variables
MetaData * free_blk_list_head = NULL;  //head pointer to the freed blocks' list
size_t entire_heap_size = 0;           //entire heap memory (include metadata)

//First Fit malloc/free
void * ff_malloc(size_t size);
void ff_free(void * ptr);

//Best Fit malloc/free
void * bf_malloc(size_t size);
void bf_free(void * ptr);

unsigned long get_data_segment_size();             // in byte
unsigned long get_data_segment_free_space_size();  // in byte

#endif
