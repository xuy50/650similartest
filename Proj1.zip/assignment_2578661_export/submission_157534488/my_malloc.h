#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct meta_data_{
  size_t block_size;
  struct meta_data_ * next;
  struct meta_data_ * prev;
}meta_data;
//the size of meta_data is 24

meta_data * first_freed_block = NULL;
size_t data_size = 0;
size_t free_space_size = 0;

void * ff_malloc(size_t size);

void ff_free(void *ptr);

void * bf_malloc(size_t size);

void bf_free(void *ptr);

unsigned long get_data_segment_size();

unsigned long get_data_segment_free_space_size();

void * add_new_block(size_t size);

void * allocate_block(meta_data * current, size_t size);

void insert_block (meta_data * block);

void * remove_block(meta_data * current);

void free_block(void * ptr);

void print_block();