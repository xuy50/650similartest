#include <stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include "my_malloc.h"

void print_block(){
  printf("\n");
  meta_data * current = first_freed_block;
  int count = 0;
  while(current != NULL){
    printf("block num: %d, block address: %p, size: %lu, end address: %p.\n", count, current, current->block_size, (void*)current + sizeof(meta_data) + current->block_size);
    count++;
    current = current->next;
  }
  printf("current free block size: %lu, current data size: %lu\n", free_space_size, data_size);
}

void * ff_malloc(size_t size){
  if(size == 0){
    return NULL;
  }
  //test code
  //printf("add a block of size %lu\n", size);
  meta_data * current = first_freed_block;
  while(current != NULL){
    //Two available situations:
    //1. the size of the block to be allocated equals to the current block, just delete current (connect three allocated blocks)
    //2. the size of the block to be allocated + sizeof(metadata) can be put into the current block and can be tracked.
    //If they're equal, we cannot use free block to track the allocated block
    if(current->block_size == size){
      return remove_block(current);
    }
    else if(current->block_size > size + sizeof(meta_data)){
      return allocate_block(current, size);
    }
    current = current->next;
  }
  return add_new_block(size);
}

void ff_free(void * ptr){
  free_block(ptr); 
  //test code
  // printf("After freeing the block \n");
  // print_block();
}

void * bf_malloc(size_t size){
  if(size == 0){
    return NULL;
  }
  //test code
  //printf("add a block of size %lu\n", size);
  meta_data * current = first_freed_block;
  meta_data * best_match = NULL;
  while(current != NULL){
    //Two available situations:
    //1. the size of the block to be allocated equals to the current block, just delete current (connect three allocated blocks)
    //2. the size of the block to be allocated + sizeof(metadata) can be put into the current block and can be tracked.
    //If they're equal, we cannot use free block to track the allocated block
    if(current->block_size == size){
      return remove_block(current);
    }
    else if(current->block_size > size + sizeof(meta_data)){
      if(best_match == NULL || current->block_size < best_match->block_size){
        best_match = current;
      }
    }
    current = current->next;
  }
  if(best_match == NULL){
    return add_new_block(size);
  }
  else{
    return allocate_block(best_match, size);
  }
}

void bf_free(void *ptr){
  free_block(ptr);
}

void free_block(void * ptr){
  if(ptr == NULL){
    return;
  }
  meta_data * new_free_block = (meta_data *) (ptr - sizeof(meta_data));
  new_free_block->prev = NULL;
  new_free_block->next = NULL;
  if(first_freed_block == NULL){
    first_freed_block = new_free_block;
    free_space_size = free_space_size + first_freed_block->block_size + sizeof(meta_data);
    return;
  }
  meta_data * current = first_freed_block;
  while(current != NULL && current->next != NULL && current->next < new_free_block){
    current = current->next;
  }
  if(current->next == NULL){
    if(current < new_free_block){
      current->next = new_free_block;
      new_free_block->prev = current;
    }else{
      if(current != first_freed_block){
        perror("wrong situation.\n");
      }
      new_free_block->next = current;
      current->prev = new_free_block;
      first_freed_block = new_free_block;
    }
  }
  else{
    new_free_block->next = current->next;
    current->next->prev = new_free_block;
    current->next = new_free_block;
    new_free_block->prev = current;
  }
  insert_block(new_free_block);
}

void insert_block(meta_data * block){
  if(block == NULL){
    return;
  }
  //printf("the address of the inserted block %p, the size of the inserted block %lu\n", block, block->block_size);
  free_space_size = free_space_size + block->block_size + sizeof(meta_data);
  meta_data * next = block->next;
  if(next != NULL && (meta_data *)((void*)block + block->block_size + sizeof(meta_data)) == next){
    block->block_size = block->block_size + next->block_size + sizeof(meta_data);
    block->next = next->next;
    if(next->next != NULL){
      next->next->prev = block;
    }
  }
  meta_data * prev = block->prev;
  if(prev != NULL && (meta_data *)((void*)prev + prev->block_size + sizeof(meta_data)) == block){
    prev->block_size = prev->block_size + block->block_size + sizeof(meta_data);
    prev->next = block->next;
    if(block->next != NULL){
      block->next->prev = prev;
    }
  }
}

//When the size of current > size + sizeof(metadata)
void * allocate_block(meta_data * current, size_t size){
  meta_data * block_segment = (meta_data*)((void*)current + size + sizeof(meta_data));
  block_segment->block_size = current->block_size - sizeof(meta_data) - size;
  block_segment->prev = current->prev;
  block_segment->next = current->next;
  meta_data * original_current = current;
  original_current->block_size = size;
  if(block_segment->prev == NULL){
    first_freed_block = block_segment;
  }
  else{
    block_segment->prev->next = block_segment;
  }
  if(block_segment->next != NULL){
    block_segment->next->prev = block_segment;
  }
  free_space_size = free_space_size - size - sizeof(meta_data);
  //test code
  // printf("After adding the block \n");
  // print_block();
  return (void*)original_current + sizeof(meta_data);
}

//When the size of current == size
void * remove_block(meta_data * current){
  if(current->prev == NULL){
    first_freed_block = current->next;
  }
  else{
    current->prev->next = current->next;
  }
  if(current->next != NULL){
    current->next->prev = current->prev;
  }
  current->prev = NULL;
  current->next = NULL;
  free_space_size = free_space_size - current->block_size - sizeof(meta_data);
  //test code 
  // printf("After adding the block \n");
  // print_block();
  return (void*)current + sizeof(meta_data);
}

//When there are no valuable block
void * add_new_block(size_t size){
  size_t actual_size = size + sizeof(meta_data);
  meta_data * toAdd = sbrk(actual_size);
  toAdd->block_size = size;
  //printf("The address of the new block %p, the size of the new block %lu\n", toAdd, toAdd->block_size);
  toAdd->prev = NULL;
  toAdd->next = NULL;
  data_size = data_size + size + sizeof(meta_data);
  return (void *)toAdd + sizeof(meta_data);
}

unsigned long get_data_segment_size(){
  return data_size;
}

unsigned long get_data_segment_free_space_size(){
  return free_space_size;
}