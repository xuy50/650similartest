#include "my_malloc.h"


// #define PRINT 1

typedef struct nodeLoc nodeLoc;
struct nodeLoc {
   size_t size;
//    void* addr;
   nodeLoc* next;
};

// void* free_space_location[10240];
// size_t free_space_size[10240];

nodeLoc free_space[10240];
size_t free_space_arr_size = 0;


// size_t free_start=0xFFFFFFFFFFFF;
// size_t free_end=0;

nodeLoc* free_head = NULL;

// void* alloc_space_location[10240];
// size_t alloc_space_size[10240];
// size_t alloc_space_arr_size = 0;


unsigned long totalsize = 0;

void printFreeSpace(){
	printf("print free Array\n");
	nodeLoc* tmp = free_head;
	while(tmp!=NULL){
		printf("(%p,%ld)",tmp,tmp->size );
		tmp = tmp->next;
	}
	printf("\n");
}

void printAllocSpace(){
	// printf("print alloc Array %ld\n",alloc_space_arr_size);
	// for (size_t i=0;i<alloc_space_arr_size;i++){
	// 	printf("(%p,%ld)",alloc_space_location[i],(size_t)alloc_space_size[i]);
	// }
	// printf("\n");
}



void *ff_malloc(size_t size) {

	if(size<=0){
		return NULL;
	}

	#ifdef PRINT
	printf("start malloc %ld\n",size);

	#endif
	void* maxb = sbrk(0);
	size += sizeof(nodeLoc);
	nodeLoc* tmp = free_head;
	nodeLoc* previous = NULL;
	nodeLoc* preprevious = NULL;
	while(tmp!=NULL){
		if(tmp->size>=size && tmp->size<=size+sizeof(nodeLoc)){
			if (previous!=NULL){
				previous->next = tmp->next;
			}else{
				free_head = tmp->next;
			}
			tmp->next = NULL;
			#ifdef PRINT
			printf("return %p,%ld\n",(void*)tmp+sizeof(nodeLoc),tmp->size);
			printFreeSpace();
			#endif

			return (void*)tmp+sizeof(nodeLoc);
		}
		else if (tmp->size > size){
			tmp->size-=size;

			nodeLoc newNode;
			newNode.next=NULL;
			newNode.size = size;
			*(nodeLoc*)((void*)tmp+tmp->size) = newNode;
			#ifdef PRINT
			printf("return %p,%ld\n",(void*)tmp + tmp->size + sizeof(nodeLoc),newNode.size);
			printFreeSpace();
			#endif
			return (void*)tmp + tmp->size + sizeof(nodeLoc);
		}
		preprevious = previous;
		previous = tmp;
		tmp = tmp->next;
	}

	if (previous == NULL){
		void* sbrkres = sbrk(size);
		if (sbrkres==NULL){
			return NULL;
		}
		// printf("sbrk0 %ld\n",size);
		totalsize+=size;
		nodeLoc newNode;
		newNode.next = NULL;
		newNode.size = size;
		*(nodeLoc*)maxb = newNode;
		#ifdef PRINT
		printf("return %p,%ld\n",(void*)maxb+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		return (void*)maxb+sizeof(nodeLoc);
	}

	if((void *)previous+previous->size == maxb){
		void* sbrkres = sbrk(size -(maxb - (void *)previous-previous->size));
		if (sbrkres==NULL){
			return NULL;
		}
		// printf("sbrk1 %ld\n",size -(maxb - (void *)previous-previous->size));
		totalsize+=size -previous->size;
		// nodeLoc newNode;
		// newNode.next = NULL;
		// newNode.size = size;

		// *(nodeLoc*)previous = newNode;
		previous->size = size;
		if (preprevious!=NULL){
			preprevious->next = NULL;
		}else{
			free_head=NULL;
		}

		#ifdef PRINT
		printf("return %p,%ld\n",(void*)previous+previous->size+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		return (void*)previous+sizeof(nodeLoc);
	}else{
		void* sbrkres = sbrk(size);
		if (sbrkres==NULL){
			return NULL;
		}

		// printf("sbrk2 %ld\n",size);
		totalsize+=size;
		nodeLoc newNode;
		newNode.next = NULL;
		newNode.size = size;
		*(nodeLoc*)maxb = newNode;
		#ifdef PRINT
		printf("return %p,%ld\n",maxb+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		return maxb+sizeof(nodeLoc);
	}

}




void ff_free(void *ptr){
	#ifdef PRINT
	printf("start free %p\n",ptr);

	#endif
	ptr = ptr - sizeof(nodeLoc);
	nodeLoc* node = ptr;
	size_t size = node->size;
	nodeLoc* tmp = free_head;
	if(free_head == NULL){
		free_head = node;
		// printf("head: %p,%ld\n",(void* )node+sizeof(nodeLoc),node->size);
		return;
	}

	// printf("nodeInfo: (%p,%ld,%p)\n",node,node->size,node->next);

	nodeLoc* pre=NULL;
	nodeLoc* next = NULL;
	while(tmp!=NULL){

		if (tmp<node){
			pre = tmp;
			tmp = tmp->next;
			continue;
		}

		next = tmp->next;


		if(pre == NULL){
			free_head = node;
			free_head->next = tmp;
			if ((void*)free_head + free_head->size == (void*)free_head->next){
				free_head->size += free_head->next->size;
				free_head->next = free_head->next->next;
			}
			// printFreeSpace();
			return;
		// }else if (next == NULL){
		// 	tmp->next = node;
		// 	node->next=NULL;
		// 	if ((void*)tmp + tmp->size == (void*)tmp->next){
		// 		tmp->size += tmp->next->size;
		// 		tmp->next = tmp->next->next;
		// 	}
			// printFreeSpace();
		// 	return;
		}else{
			pre->next = node;
			node->next=tmp;
			if ((void*)pre + pre->size == (void*)pre->next){
				pre->size += pre->next->size;
				pre->next = pre->next->next;
				if ((void*)pre + pre->size == (void*)pre->next){
					pre->size += pre->next->size;
					pre->next = pre->next->next;
				}
			}

			else if((void*)node + node->size == (void*)node->next){
				node->size+=node->next->size;
				node->next = node->next->next;
			}
			// printFreeSpace();
			return;


		}

		pre = tmp;
		tmp = tmp->next;
	}

	pre->next = node;
	if ((void*)pre + pre->size == (void*)pre->next){
		pre->size += pre->next->size;
		pre->next = pre->next->next;
	}


	#ifdef PRINT
	printf("after free\n");
	printFreeSpace();
	printAllocSpace();
	#endif

}

void *bf_malloc(size_t size){
	#ifdef PRINT
	printf("start malloc %ld\n",size);

	#endif

	if(size<=0){
		return NULL;
	}
	void* maxb = sbrk(0);
	size += sizeof(nodeLoc);
	nodeLoc* tmp = free_head;
	nodeLoc* previous = NULL;
	nodeLoc* preprevious = NULL;
	size_t extra = SIZE_MAX;
	nodeLoc* best = NULL;
	nodeLoc* bestprev = NULL;
	nodeLoc* bestpreprev=NULL;
	while(tmp!=NULL){
		if(tmp->size >= size && tmp->size-size < extra ){
			extra =tmp->size-size;
			best = tmp;
			bestprev = previous;
			bestpreprev = preprevious;
		}
		if (extra == 0){
			break;
		}
		preprevious = previous;
		previous = tmp;	
		tmp = tmp->next;
	}
	if(best!=NULL){
		if(extra > sizeof(nodeLoc)){//split
			best->size-=size;
			nodeLoc newNode;
			newNode.next=NULL;
			newNode.size = size;
			*(nodeLoc*)((void*)best+best->size) = newNode;
			#ifdef PRINT
			printf("return %p,%ld\n",(void*)best + best->size + sizeof(nodeLoc),newNode.size);
			printFreeSpace();
			#endif
			return (void*)best + best->size + sizeof(nodeLoc);

		}else{//use all space
			if (bestprev!=NULL){
				bestprev->next = best->next;
			}else{
				free_head = best->next;
			}
			best->next = NULL;
			#ifdef PRINT
			printf("return %p,%ld\n",(void*)best+sizeof(nodeLoc),best->size);
			printFreeSpace();
			#endif
			return (void*)best+sizeof(nodeLoc);

		}
	}

	if (previous == NULL){
		void* sbrkres = sbrk(size);
		if (sbrkres==NULL){
			return NULL;
		}
		// printf("sbrk0 %ld\n",size);
		totalsize+=size;
		nodeLoc newNode;
		newNode.next = NULL;
		newNode.size = size;
		*(nodeLoc*)maxb = newNode;
		#ifdef PRINT
		printf("return %p,%ld\n",(void*)maxb+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		return (void*)maxb+sizeof(nodeLoc);
	}

	if((void *)previous+previous->size == maxb){
		void* sbrkres = sbrk(size -(maxb - (void *)previous-previous->size));
		if (sbrkres==NULL){
			return NULL;
		}
		// printf("sbrk1 %ld\n",size -(maxb - (void *)previous-previous->size));
		totalsize+=size -previous->size;
		// nodeLoc newNode;
		// newNode.next = NULL;
		// newNode.size = size;
		// *(nodeLoc*)((void*)previous+previous->size) = newNode;
		#ifdef PRINT
		printf("return %p,%ld\n",(void*)previous+previous->size+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		previous->size = size;
		if (preprevious!=NULL){
			preprevious->next = NULL;
		}else{
			free_head=NULL;
		}
		return (void*)previous+sizeof(nodeLoc);
	}else{

		void* sbrkres = sbrk(size);
		if (sbrkres==NULL){
			return NULL;
		}
		// printf("sbrk2 %ld\n",size);
		totalsize+=size;
		nodeLoc newNode;
		newNode.next = NULL;
		newNode.size = size;
		*(nodeLoc*)maxb = newNode;
		#ifdef PRINT
		printf("return %p,%ld\n",maxb+sizeof(nodeLoc),newNode.size);
		printFreeSpace();
		#endif
		return maxb+sizeof(nodeLoc);
	}
}
void bf_free(void *ptr){
	ff_free(ptr);
}


unsigned long get_data_segment_size(){
	return totalsize;
}
unsigned long get_data_segment_free_space_size(){
	unsigned long ans=0;
	nodeLoc* tmp = free_head;
	while(tmp!=NULL){
		ans+=tmp->size;
		tmp = tmp->next;
	}

	return ans;
}
