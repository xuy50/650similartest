#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <limits.h>

void *ff_malloc(size_t size);
void ff_free(void *ptr);

void *bf_malloc(size_t size);
void bf_free(void *ptr);


unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


void printFreeSpace();
void printAllocSpace();
