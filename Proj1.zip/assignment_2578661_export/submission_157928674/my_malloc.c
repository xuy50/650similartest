#include "my_malloc.h"

chunk_info * Head_chunk = NULL; // type used to be "void *" but gcc throws warnings? lol
chunk_info * Head_avlb_chunk = NULL;
chunk_info * Tail_avlb_chunk = NULL;

// for performance study
size_t data_segment_size = 0;
size_t data_segment_free_space_size = 0;

void * ff_malloc(size_t size){
  //printf("mallocing space: %zu---", size);
  short int isNeedMoreMem = 1;
  short int isNeedToSplit = 0;
  chunk_info * ptr_chunk = Head_avlb_chunk;
  while (ptr_chunk != NULL){
    if (ptr_chunk->chunkSize > size){
      // found the first fit region
      // but need to split
      isNeedMoreMem = 0;
      if (ptr_chunk->chunkSize > size + sizeof(chunk_info)){
	isNeedToSplit = 1;
      }
      else {
	isNeedToSplit = 0;
	//ptr_chunk->isAvlb = 0;
	data_segment_free_space_size -= ptr_chunk->chunkSize;
	uncheck_chunk(ptr_chunk);
	//data_segment_free_space_size -= ptr_chunk->chunkSize;
      }
      //printf("ptr_chunk->chunkSize is %zu while request size + chunk_info size is %zu", ptr_chunk->chunkSize, size+sizeof(chunk_info));
      //printf("\nso isNeedToSplit is %d\n", isNeedToSplit);
      break;
    }
    else if (ptr_chunk->chunkSize == size){
      // found the perfectly fit region
      isNeedMoreMem = 0;
      isNeedToSplit = 0;
      //ptr_chunk->isAvlb = 0;
      uncheck_chunk(ptr_chunk);
      data_segment_free_space_size -= size + sizeof(chunk_info);
      break;
    }
    else {
      // iterate to the next memory chunk
      ptr_chunk = ptr_chunk->nextChunk;
    }
  }
  if (isNeedMoreMem){
    // this would allocate the exact amount of memory
    // maybe upgrade to increment at least 4Kb at a time for performance
    ptr_chunk = requestMem(size);
    if (Head_chunk == NULL){
      // initializing
      Head_chunk = ptr_chunk;
    }
  }
  else if (isNeedToSplit){
    ptr_chunk = splitMem(ptr_chunk, size);
    data_segment_free_space_size -= size + sizeof(chunk_info);
  }
  //return (ptr_chunk + 1);
  //printf("ff_malloc() returned: (char *)ptr_chunk + sizeof(chunk_info) %p\n", (char *)ptr_chunk + sizeof(chunk_info));
  //printf("---------------------------\n");
  return (char *)ptr_chunk + sizeof(chunk_info);
}

chunk_info * requestMem(size_t size){
  //printf("requestMem called: size %zu---", size);
  chunk_info * ptr_newMem = sbrk(0);
  size_t actual_size = sizeof(chunk_info) + size;
  ptr_newMem = sbrk(actual_size);
  data_segment_size += actual_size;
  ptr_newMem -> chunkSize = size;
  //ptr_newMem -> isAvlb = 0;
  ptr_newMem -> nextChunk = NULL;
  ptr_newMem -> prevChunk = NULL;
  //printf("requestMem returned: ptr_newMem at %p\n", ptr_newMem);
  return ptr_newMem;
}

chunk_info * splitMem(chunk_info * ptr_chunk, size_t size){
  //printf("splitMem called: ptr_chunk %p size %zu---", ptr_chunk, size);
  size_t original_size = ptr_chunk -> chunkSize;
  size_t new_mem_size = original_size - size - sizeof(chunk_info);
  chunk_info * ptr_return = (chunk_info *)((char *)ptr_chunk + sizeof(chunk_info) + new_mem_size);
  ptr_chunk -> chunkSize = new_mem_size;
  ptr_return -> chunkSize = size;
  //ptr_return -> isAvlb = 0;
  ptr_return -> nextChunk = NULL;
  ptr_return -> prevChunk = NULL;
  //printf("spiltMem returned: ptr_return %p\n", ptr_return);
  return ptr_return;
}

void check_chunk(chunk_info * ptr_newMem){
  if (ptr_newMem == NULL){
    return;
  }
  //assert(ptr_newMem -> isAvlb);
  ptr_newMem -> nextChunk = NULL;
  ptr_newMem -> prevChunk = NULL;
  //printf("check_chunk() is called, ptr_newMem: %p---", ptr_newMem);
  //printf("Head_avlb_chunk %p, Tail_avlb_chunk %p\n", Head_avlb_chunk, Tail_avlb_chunk);
  if ((Head_avlb_chunk == NULL) || (ptr_newMem < Head_avlb_chunk)){
    // add_front situation
    //printf("add_front\n");
    ptr_newMem -> nextChunk = Head_avlb_chunk;
    ptr_newMem -> prevChunk = NULL;
    if (Tail_avlb_chunk == NULL){
      // initializing the avlb linkedlist
      Tail_avlb_chunk = ptr_newMem;
    }
    else{
      // just add front
      Head_avlb_chunk -> prevChunk = ptr_newMem;
    }
    Head_avlb_chunk = ptr_newMem;
  }
  else if (ptr_newMem > Tail_avlb_chunk){
    // there's already elements in the linkedlist
    // and add_back situation
    ptr_newMem -> nextChunk = NULL;
    ptr_newMem -> prevChunk = Tail_avlb_chunk;
    Tail_avlb_chunk ->nextChunk = ptr_newMem;
    Tail_avlb_chunk = ptr_newMem;
  }
  else {
    // add_in_descending order in the middle, like in 551
    chunk_info * current = Head_avlb_chunk;
    while ((current != NULL) && (current < ptr_newMem)){
      current = current -> nextChunk;
    }
    ptr_newMem -> nextChunk = current;
    ptr_newMem -> prevChunk = current -> prevChunk;
    current -> prevChunk -> nextChunk = ptr_newMem;
    current -> prevChunk = ptr_newMem;
  }
}

void uncheck_chunk(chunk_info * ptr_chunk){
  //assert(ptr_chunk -> isAvlb == 0);
  if ((ptr_chunk == Head_avlb_chunk) && (ptr_chunk == Tail_avlb_chunk)){
    // if the chunk that's being used is the only currently avlb one
    Head_avlb_chunk = NULL;
    Tail_avlb_chunk = NULL;
  }
  else if (ptr_chunk == Head_avlb_chunk){
    Head_avlb_chunk = ptr_chunk -> nextChunk;
    Head_avlb_chunk -> prevChunk = NULL;
  }
  else if (ptr_chunk == Tail_avlb_chunk){
    Tail_avlb_chunk = ptr_chunk -> prevChunk;
    Tail_avlb_chunk -> nextChunk = NULL;
  }
  else{
    // purely somewhere in the middle
    ptr_chunk -> prevChunk -> nextChunk = ptr_chunk -> nextChunk;
    ptr_chunk -> nextChunk -> prevChunk = ptr_chunk -> prevChunk;
  }
  ptr_chunk -> nextChunk = NULL;
  ptr_chunk -> prevChunk = NULL;
}

void ff_free(void * ptr){
  //printf("ff_free() called: ptr %p---", ptr);
  chunk_info * ptr_info = NULL;
  ptr_info = (chunk_info *)((char *)ptr - sizeof(chunk_info));
  //printf("ptr_info is %p---", ptr_info);
  size_t new_avlbSize = ptr_info -> chunkSize;
  //printf("chunkSize to be freed: %zu\n", new_avlbSize);
  //ptr_info -> isAvlb = 1;
  check_chunk(ptr_info);
  data_segment_free_space_size += new_avlbSize + sizeof(chunk_info);
  // now consider merging
  if ((ptr_info != Tail_avlb_chunk) &&
      (ptr_info -> nextChunk == (chunk_info *)((char *)ptr + new_avlbSize))){
    // merge it with the one after
    ptr_info -> chunkSize += sizeof(chunk_info) + ptr_info -> nextChunk -> chunkSize;
    uncheck_chunk(ptr_info -> nextChunk);
  }
  if ((ptr_info != Head_avlb_chunk) &&
      (ptr_info -> prevChunk == (chunk_info *)((char *)ptr_info - ptr_info->prevChunk->chunkSize - sizeof(chunk_info)))){
    // merge it with the one before
    new_avlbSize += ptr_info -> prevChunk -> chunkSize + sizeof(chunk_info);
    ptr_info -> prevChunk -> chunkSize = new_avlbSize;
    uncheck_chunk(ptr_info);
  }
  //printf("ff_free() done\n---------\n");
}

void * bf_malloc(size_t size){
  short int isNeedMoreMem = 1;
  short int isNeedToSplit = 0;
  short int isPerfectFit = 0;
  chunk_info * ptr_chunk = Head_avlb_chunk;
  chunk_info * ptr_best_chunk = NULL;
  while (ptr_chunk != NULL){
    if (ptr_chunk->chunkSize > size){
      // found the potentially best fit region
      isNeedMoreMem = 0;
      isNeedToSplit = 1;
      if (ptr_best_chunk == NULL){
	ptr_best_chunk = ptr_chunk;
      }
      if (ptr_chunk -> chunkSize < ptr_best_chunk -> chunkSize){
	// the smaller the better
	ptr_best_chunk = ptr_chunk;
      }
    }
    else if (ptr_chunk->chunkSize == size){
      // found the perfectly fit region
      isNeedMoreMem = 0;
      isNeedToSplit = 0;
      isPerfectFit = 1;
      //ptr_chunk->isAvlb = 0;
      uncheck_chunk(ptr_chunk);
      data_segment_free_space_size -= size + sizeof(chunk_info);
      break;
    }
   
      // iterate to the next memory chunk
      ptr_chunk = ptr_chunk->nextChunk;
   }
  if (isNeedMoreMem){
    // this would allocate the exact amount of memory
    // maybe upgrade to increment at least 4Kb at a time for performance
    ptr_chunk = requestMem(size);
    if (Head_chunk == NULL){
      // initializing
      Head_chunk = ptr_chunk;
    }
  }
  else if ((isNeedToSplit) && (!isPerfectFit)){
    ptr_chunk = ptr_best_chunk;
    if(ptr_chunk->chunkSize > size + sizeof(chunk_info)){
      ptr_chunk = splitMem(ptr_chunk, size);
      data_segment_free_space_size -= size + sizeof(chunk_info);
    }
    else {
      //ptr_chunk->isAvlb = 0;
      data_segment_free_space_size -= ptr_chunk->chunkSize;
      uncheck_chunk(ptr_chunk);
    }
  }
  //return (ptr_chunk + 1);
  return (char *)ptr_chunk + sizeof(chunk_info);
}

void bf_free(void * ptr){
  ff_free(ptr);
}

// for performance study
unsigned long get_data_segment_size(){
  // entire heap memory (includes chunk_info)
  return data_segment_size;
}

unsigned long get_data_segment_free_space_size(){
  // size of the actual available space (includes chunk_info)
  return data_segment_free_space_size;
}
