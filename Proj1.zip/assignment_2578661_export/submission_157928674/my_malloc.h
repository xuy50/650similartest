#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct _chunk_info{
  size_t chunkSize;
  //short int isAvlb; // Avlb is the abbreviation for "Available"
  struct _chunk_info * nextChunk;
  struct _chunk_info * prevChunk;
} chunk_info;

void * ff_malloc(size_t size);
chunk_info * requestMem(size_t size);
chunk_info * splitMem(chunk_info * ptr_chunk, size_t size);
void check_chunk(chunk_info * ptr_newMem); // add a chunk to the avlbChunk linked list
void uncheck_chunk(chunk_info * ptr_chunk);
void ff_free(void * ptr);

void * bf_malloc(size_t size);
void bf_free(void * ptr);

// for performance study
unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
