//
//  Header.h
//  ECE650 project1-1
//
//  Created by YUYANG KAO on 1/19/23.
//

//#ifndef Header_h
//#define Header_h
//#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>

struct _Linklist
{
    size_t size;
    struct _Linklist *next;
    struct _Linklist *prev;
}typedef Linklist;

void *split(Linklist *curr,size_t size);
Linklist *ff_check_list(size_t size);
void *ff_malloc(size_t size);
void insert_node(Linklist * currnode);
void merge_link(Linklist *freehead);
void ff_free(void *ptr);

Linklist *bf_check_list(size_t size);
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


//#endif /* Header_h */
