#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "my_malloc.h"
//#include <unistd.h>

size_t heaphead = 0;
size_t freespace = 0;
Linklist * freehead = NULL;

void *split(Linklist *curr,size_t size){
    //if currnode size = request size + metasize can use directly
    if (curr -> size > size + sizeof(Linklist)){
        curr->size = curr->size - (size + sizeof(Linklist));
    //record freespace
    freespace = freespace - (size + sizeof(Linklist));
        Linklist * currptr = (void *)curr + sizeof(Linklist)+curr->size;
        currptr->size = size;
        Linklist* returnptr = (void *)currptr + sizeof(Linklist);
    return returnptr;
    }
else{
    Linklist * prev = curr->prev;
    
    if(prev == NULL && curr->next==NULL){
        curr->next =NULL;
        curr->prev =NULL;
        freehead = NULL;
	freespace = 0;
    }
    //mid
    else if(prev!=NULL && curr->next!=NULL){
      freespace = freespace-(curr->size+sizeof(Linklist));
        prev->next = curr->next;
        curr->next->prev= prev;}
    //head
    else if(prev == NULL && curr->next!=NULL){
      freespace = freespace-(curr->size+sizeof(Linklist));
        curr->next->prev = NULL;
	freehead = curr->next;
        //last
    }else if(prev!=NULL && curr->next==NULL){
      freespace = freespace-(curr->size+sizeof(Linklist));
      prev->next = curr->next;
        curr->next = NULL;
        curr->prev=NULL;
    }
        return (void *)curr + sizeof(Linklist);
    }
}

Linklist *ff_check_list(size_t size){
    Linklist * curr = freehead;
    while(curr!=NULL){
        if (curr->size>=size){
            return curr;
        }else{
            curr = curr->next;
        }
    }
    return NULL;
}

void *ff_malloc(size_t size){
    Linklist *curr = ff_check_list(size);
    if (curr == NULL){
        heaphead = heaphead+size+sizeof(Linklist);
        //returnptr is malloc start
        Linklist *returnptr  = (void *)sbrk(size + sizeof(Linklist));
	if (returnptr ==(void *)-1){
	  return NULL;
	}
        returnptr->next = NULL;
        returnptr->prev = NULL;
        returnptr->size = size;
        
        //returnptr is malloc start + metadata
        returnptr =(void *) returnptr + sizeof(Linklist);
	return returnptr;
    }else{
        void *returnptr = split(curr,size);
	return returnptr;
    }
};

void insert_node(Linklist * currnode){
    if(freehead == NULL){
        freehead = currnode;//Segmentation fault (core dumped)
        currnode->next=NULL;
        currnode->prev=NULL;
	freespace = freespace + currnode->size + sizeof(Linklist);
	return;
    }
    
    Linklist *curr = freehead;
    //change curr!=NULL
    while(curr!=NULL&&curr < currnode){
        if(curr->next == NULL){
            curr->next = currnode;
            currnode->prev = curr;
            currnode->next=NULL;
	    freespace = freespace + currnode->size + sizeof(Linklist);
            merge_link(currnode);
            return;
        }
        curr = curr->next;
    }
    if (curr == freehead){
        curr->prev = currnode;
        currnode->next = curr;
        currnode->prev = NULL;
        freehead = currnode;
	freespace = freespace + currnode->size + sizeof(Linklist);
        merge_link(currnode);
        return;
    }
    Linklist *nodeprev = curr -> prev;
    if(curr!=NULL&&currnode<curr&&nodeprev<currnode){
      //    count ++;
      // printf("%d\n",count);
     currnode->next = curr;
    curr->prev=currnode;
    nodeprev->next = currnode;
    currnode->prev=nodeprev;
    freespace = freespace + currnode->size + sizeof(Linklist);
    merge_link(currnode);
    return;
    }
    return;
}

void merge_link(Linklist *ptr){
    if((void *)ptr+sizeof(Linklist)+(ptr->size)==ptr->next){
           ptr->size = ptr->size + sizeof(Linklist)+ptr->next->size;
            ptr->next = ptr->next->next;
            if(ptr->next!=NULL){
                ptr->next->prev = ptr;}
    }

    if(((void*)ptr->prev!=NULL)&&((void*)ptr->prev+sizeof(Linklist)+ptr->prev->size==ptr)){
        ptr = ptr->prev;
        ptr->size = ptr->size + sizeof(Linklist)+ptr->next->size;
            ptr->next = ptr->next->next;
            if(ptr->next!=NULL){
                ptr->next->prev = ptr;}
    }
    return;
}

void ff_free(void *ptr){
  if (ptr == NULL){
    return;
  }
    Linklist *currnode = currnode = (void *)(ptr - sizeof(Linklist));
    insert_node(currnode);
};

Linklist *bf_check_list(size_t size){
    Linklist * curr = freehead;
    unsigned long closesize = ULONG_MAX;
    Linklist * closeptr  = NULL;
    while(curr!=NULL){
        if (curr->size == size){
            return curr;
        }
        else if (curr->size>size){
            if (curr->size < closesize){
            closesize = curr->size;
            closeptr = curr;}
            curr = curr->next;
        }else{
            curr = curr->next;
        }
    }
    if (closeptr != NULL){
        return closeptr;
    }else{
    return NULL;}
}


void *bf_malloc(size_t size){
    Linklist *curr = bf_check_list(size);
    if (curr == NULL){
        heaphead = heaphead+size+sizeof(Linklist);
        //returnptr is malloc start
        Linklist *returnptr  = (void *)sbrk(size + sizeof(Linklist));
	if (returnptr ==(void *)-1){
	  return NULL;
	}
        returnptr->next = NULL;
        returnptr->prev = NULL;
        returnptr->size = size;
        
        //returnptr is malloc start + metadata
        returnptr =(void *) returnptr + sizeof(Linklist);
	return returnptr;
    }else{
        void *returnptr = split(curr,size);
	return returnptr;
    }
};

void bf_free(void *ptr){
      if (ptr == NULL){
    return;
  }
    Linklist *currnode = currnode = (void *)(ptr - sizeof(Linklist));
    insert_node(currnode);
};

unsigned long get_data_segment_size(){
return heaphead;
};
unsigned long get_data_segment_free_space_size(){
  return freespace;
};
