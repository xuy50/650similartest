#include "my_malloc.h"
#include "limits.h"

#define BLOCK_SIZE sizeof(LinkedList)

LinkedList* head = NULL;
LinkedList* tail = NULL;
unsigned long data_segment_size = 0;

void removeBlock(LinkedList* block){
  if(block->prev != NULL && block->next != NULL){
    block->prev->next = block->next;
    block->next->prev = block->prev;
  }else if(block->prev == NULL && block->next != NULL){
    block->next->prev = NULL;
    head = block->next;
  }else if(block->prev != NULL && block->next == NULL){
    block->prev->next = NULL;
    tail = block->prev;
  }else{
    head = NULL;
    tail = NULL;
  }
  block->prev = NULL;
  block->next = NULL;
}
void* splitBlock(LinkedList* block,size_t size){
  if(block->size == size){
    removeBlock(block);
  }else{
    //left: no free, right: free
    LinkedList* freeBlock = (LinkedList*)((void*)block + BLOCK_SIZE + size);
    freeBlock->size = block->size - size - BLOCK_SIZE;
    freeBlock->next = block->next;
    freeBlock->prev = block->prev;
    if(freeBlock->prev==NULL){
      head = freeBlock;
    }else{
      freeBlock->prev->next = freeBlock;
    }
    if(freeBlock->next==NULL){
      tail = freeBlock;
    }else{
      freeBlock->next->prev = freeBlock;
    }
    block->size = size;
    block->prev = NULL;
    block->next = NULL;
  }
  return (void*)block + BLOCK_SIZE;
}

void* generateBlock(size_t size){
  LinkedList* block = sbrk(0);
  if(sbrk(size + BLOCK_SIZE) == (void*)-1){
    fprintf(stderr, "no memory!\n");
    exit(EXIT_FAILURE);
  }
  data_segment_size = data_segment_size + size + BLOCK_SIZE;
  block->size = size;
  block->prev = NULL;
  block->next = NULL;  
  return (void*)block + BLOCK_SIZE;
}
LinkedList* findFirstBlock(size_t size){
  LinkedList* p = head;
  while(p != NULL){
    if(p->size == size || p->size > size + BLOCK_SIZE){
      return p;
    }
    p = p->next;
  }
  return NULL;
}
void* ff_malloc(size_t size){
  if(size <= 0){
    fprintf(stderr, "You cannot assign 0 or negative number");
    exit(EXIT_FAILURE);
  }
  LinkedList* find = findFirstBlock(size);
  if(find != NULL){
    return splitBlock(find, size);
  }
  void* ptr = generateBlock(size);

  return ptr;
}
LinkedList* findBestBlock(size_t size){
  LinkedList* p = head;
  LinkedList* ans = NULL;
  size_t diff = INT_MAX;
  while(p != NULL){
    if(p->size == size){
      return p;
    }else if(p->size > size + BLOCK_SIZE){
      if(diff > p->size - size){
        diff = p->size - size;
        ans = p;
      }
    }
    p = p->next;
  }
  return ans;
}
void* bf_malloc(size_t size){
  if(size <= 0){
    fprintf(stderr, "You cannot assign 0 or negative number");
    exit(EXIT_FAILURE);
  }
  LinkedList* find = findBestBlock(size); 
  if(find != NULL){
    return splitBlock(find, size);
  }
    
  void* ptr = generateBlock(size);
  return ptr;
}


void insertBlock(LinkedList* block, LinkedList* prev, LinkedList* next){
  if(block == NULL){
    exit(EXIT_FAILURE);
  }
  if(prev == NULL && next == NULL){
    head = block;
    next = block;
    block->next = NULL;
    block->prev = NULL;
  }else if(prev != NULL && next == NULL){
    tail->next = block;
    block->prev = tail;
    tail = tail->next;
  }else if(prev == NULL && next != NULL){
    head->prev = block;
    block->next = head;
    head = block;
  }else{
    prev->next = block;
    block->prev = prev;
    next->prev = block;
    block->next = next;
  }
}
LinkedList* merge(LinkedList* block, LinkedList* toMergedBlock){
  if((void*)block + block->size + BLOCK_SIZE == (void*)toMergedBlock){
    block->size = block->size + toMergedBlock->size + BLOCK_SIZE;
    block->next = toMergedBlock->next;
    if(toMergedBlock->next != NULL){
      block->next->prev = block;
    }else{
      tail = block;
    }
  }
  return block;
}
void mergeBlocks(LinkedList* block){
  LinkedList* prev = block->prev;
  LinkedList* next = block->next;
  LinkedList* p = NULL;
  if(prev == NULL && next == NULL){
    return;
  }else if(prev == NULL && next != NULL){
    merge(block, block->next);
  }else if(prev != NULL && next == NULL){
    merge(block->prev, block);
  }else{
    p = merge(prev, block);
    p = merge(p, next);
  }
}
void ff_free(void* ptr){
    if(ptr==NULL) return;
    LinkedList* block = (LinkedList*)(ptr - BLOCK_SIZE);    
    if(block == NULL){
      printf("This place has no memory!\n");
    }
    if(head==NULL && tail==NULL){
        head = block;
        tail = block;
    }else{
      LinkedList* p = head;
      //get near to block
        while(p!=NULL && p < block){
            p = p->next;
        }
        if(p == NULL){
          insertBlock(block, tail, NULL);
        }else if(p==head){
          insertBlock(block, NULL, head);
        }else{
          insertBlock(block, p->prev, p);
        }
    }
    mergeBlocks(block);
}

void bf_free(void* ptr){
  ff_free(ptr);
}

unsigned long get_data_segment_size(){
  return data_segment_size;
}
unsigned long get_data_segment_free_space_size(){
  LinkedList* p = head;
  unsigned long res =0;
  while(p!= NULL){
    res += BLOCK_SIZE + p->size;
    p = p->next;
  }
    return res;
}


