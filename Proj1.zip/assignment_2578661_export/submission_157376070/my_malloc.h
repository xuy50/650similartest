#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


struct LinkedList{
    size_t size;
    struct LinkedList *next;
    struct LinkedList *prev;
};
typedef struct LinkedList LinkedList;


unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();


void *ff_malloc(size_t size);
void ff_free(void *ptr);
void *bf_malloc(size_t size);
void bf_free(void *ptr); 

