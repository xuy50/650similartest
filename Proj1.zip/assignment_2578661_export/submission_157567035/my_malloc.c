#include "my_malloc.h"
#include <stdio.h>
#include <stdlib.h>
 #include <unistd.h>

#define FREE_BLK_SIZE sizeof(freeBLK)
void initialize() { // Initiate the circular doubly linked list
    heapHead = sbrk(FREE_BLK_SIZE);
    heapHead->next = heapHead;
    heapHead->prev = heapHead;
    heapHead->size = FREE_BLK_SIZE;
}

void splitBlock(freeBLK * curr, size_t s) { 
  if(s + FREE_BLK_SIZE < curr->size) { // Check whether the block needs to be splited
    freeBLK * addition = (void *)curr + s; // Create the new internal block
    curr->next->prev = addition;
    addition->next = curr->next;
    curr->next = addition;
    addition->prev = curr;
    addition->size = curr->size - s;
    curr->size = s;
  }
}

void coalBlock(freeBLK * curr) {
  if(curr->next == (void *)curr + curr->size) { //Check right adjecent block
    curr->size += curr->next->size;
    curr->next->size = 0;
    curr->next = curr->next->next;
    curr->next->prev = curr;
  }
  if(curr == (void *)curr->prev + curr->prev->size) { //Check left adjecent block
    curr->prev->size += curr->size;
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    curr->size = 0;
  }
}


//First Fit malloc/free
void *ff_malloc(size_t size) {
    size_t realSize = size + FREE_BLK_SIZE;
    if(heapHead == NULL) initialize();
    freeBLK * curr = heapHead->next;
    while(curr != heapHead && curr->size < realSize) {
        curr = curr->next;
    } 
    if(curr == heapHead) {
        curr = sbrk(realSize);
        curr->size = realSize;
    }
    else {
      splitBlock(curr, realSize);
      curr->prev->next = curr->next;
      curr->next->prev = curr->prev;
    }
    return (void *)curr + FREE_BLK_SIZE;
}

void ff_free(void *ptr) {
    freeBLK * b = ptr - FREE_BLK_SIZE;
    freeBLK * curr = heapHead->next;
    while(curr != heapHead && b > curr) { // Insert the block according to the order of address
        curr = curr->next;
    }
    curr->prev->next = b;
    b->prev = curr->prev;
    curr->prev->next->next = curr;
    curr->prev = b;
    coalBlock(b);
}

//Best Fit malloc/free
void *bf_malloc(size_t size) {
    size_t realSize = size + FREE_BLK_SIZE;
    if(heapHead == NULL)  initialize();
    freeBLK * curr = heapHead->next;
    freeBLK * comp = NULL; //Comp keeps the block with samllest size satifying request
    while(curr != heapHead) {
      if(curr->size > realSize) {
	if(comp == NULL || curr->size < comp->size) comp = curr;
      }else if (curr->size == realSize) { // Break if current size exactly matches requested size
	comp = curr;
	break;
      }
      curr = curr->next;
    }
    if(comp == NULL) {
        curr = sbrk(realSize);
        curr->size = realSize;
    }
    else {
      splitBlock(comp, realSize);
      comp->prev->next = comp->next;
      comp->next->prev = comp->prev;
      curr = comp;
    }
    return (void *)curr + FREE_BLK_SIZE;
}
    
void bf_free(void *ptr) {
    freeBLK * b = ptr - FREE_BLK_SIZE;
    freeBLK * curr = heapHead->next;
    while(curr != heapHead && b > curr) {
        curr = curr->next;
    }
    curr->prev->next = b;
    b->prev = curr->prev;
    curr->prev->next->next = curr;
    curr->prev = b;
    coalBlock(b);
}

unsigned long get_data_segment_size() { //in bytes
  return sbrk(0) - (void *)heapHead;
}
unsigned long get_data_segment_free_space_size() { //in byte
  freeBLK * curr = heapHead->next;
  unsigned long freeSize = FREE_BLK_SIZE;
  while(curr != heapHead) {
    freeSize += curr->size;
    curr = curr->next;
  }
  return freeSize;
}

