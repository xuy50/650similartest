#include <stdio.h>
#include <unistd.h>
#include <assert.h>

#define METADATA_SIZE sizeof(metadata)

typedef struct data {
    size_t size;
    struct data* prev;
    struct data* next;
} metadata;

//First Fit malloc/free
void *ff_malloc(size_t size);
void ff_free(void *ptr);


//Best Fit malloc/free
void *bf_malloc(size_t size);
void bf_free(void *ptr);

unsigned long get_data_segment_size(); // in bytes
unsigned long get_data_segment_free_space_size(); // in bytes

void update_LL(void* addr);
void *initialize_list(size_t size);
void insert(metadata* to_add);
void coalesce(metadata* node);
void *get_mem_addr(metadata* current, size_t total_size);
unsigned long calc_freelist_size();
void print_list();