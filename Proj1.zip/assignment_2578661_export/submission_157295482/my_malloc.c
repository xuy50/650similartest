#include "my_malloc.h"

static metadata* freelist = NULL;
unsigned long total_space_used = 0;

void *ff_malloc(size_t size) {
  assert(size > 0);
  size_t total_size = size + METADATA_SIZE;
  total_space_used += total_size * 8;
  if (freelist == NULL) { // if the freelist has no entries
    void* new_addr = sbrk(total_size);
    metadata* set_size = (metadata*) new_addr;
    set_size->next = NULL;
    set_size->prev = NULL;
    set_size->size = total_size;
    return new_addr + METADATA_SIZE;
  }

  // dealing with a populated freelist
  metadata* current = freelist;
  while (current->next != NULL && current->size < total_size) {
      current = current->next;
  } // if breaks out of here then either current is the last node in the list, 
    // or the size fits and there is a next node

  if (current->next == NULL) { // last node
    void* new_addr = sbrk(total_size);
    metadata* set_size = (metadata*) new_addr;
    set_size->next = NULL;
    set_size->prev = NULL;
    set_size->size = total_size;
    return new_addr + METADATA_SIZE;
  } else if (current->prev == NULL) { // first node, size fit
    if (current->size > total_size + METADATA_SIZE) { //need to split the memory
      metadata* next = current->next;
      size_t new_size = current->size - total_size;

      void* new_addr = (void*) current + total_size;
      metadata* new_node = (metadata*) (new_addr);
      new_node->next = next;
      new_node->prev = NULL;
      new_node->size = new_size;
      next->prev = new_node;
      freelist = new_node;
      current->next = NULL;
      current->prev = NULL;
      current->size = total_size;
      return (void*) current + METADATA_SIZE;
    } else {
      current->next->prev = NULL;
      freelist = current->next;
      current->next = NULL;
      return (void*) current + METADATA_SIZE;
    }
  } else { // anything else
    if (current->size > total_size + METADATA_SIZE) { //need to split the memory
      metadata* next = current->next;
      metadata* prev = current->prev;
      size_t new_size = current->size - total_size;
      void* new_addr = (void*) current + total_size;
      metadata* new_node = (metadata*) (new_addr);
      new_node->next = next;
      new_node->prev = prev;
      new_node->size = new_size;
      next->prev = new_node;
      prev->next = new_node;
      current->next = NULL;
      current->prev = NULL;
      current->size = total_size;
      return (void*) current + METADATA_SIZE;
    } else {
      metadata* next = current->next;
      metadata* prev = current->prev;
      prev->next = next;
      next->prev = prev;
      return (void*) current + METADATA_SIZE;
    }
  }
}

void ff_free(void *ptr) {
  metadata* new_node = (metadata*) (ptr - METADATA_SIZE); //minus goes up, plus goes down
  if (freelist == NULL) {
    new_node->next = NULL;
    freelist = new_node;
    return;
  }
  insert(new_node);
  coalesce(new_node);
}

void *bf_malloc(size_t size) {
  assert(size > 0);
  size_t total_size = size + METADATA_SIZE;
  // printf("mallocing size %lu\n", total_size);
  total_space_used += total_size * 8;
  if (freelist == NULL) { // if the freelist has no entries
    // printf("freelist was null, starting one\n");
    void* new_addr = sbrk(total_size);
    metadata* set_size = (metadata*) new_addr;
    set_size->next = NULL;
    set_size->prev = NULL;
    set_size->size = total_size;
    return new_addr + METADATA_SIZE;
  }

  metadata* current = freelist;
  metadata* best_fit = NULL;
  size_t closest = __INT32_MAX__;
  while (current != NULL) {
    if (current->size >= total_size) {
      if (current->size - total_size < closest) {
        best_fit = current;
        closest = current->size - total_size;
      }
      if (closest <= METADATA_SIZE) {
        break;
      }
    }
    current = current->next;
  }

  if (best_fit == NULL) {
    void* new_addr = sbrk(total_size);
    metadata* set_size = (metadata*) new_addr;
    set_size->next = NULL;
    set_size->prev = NULL;
    set_size->size = total_size;
    return new_addr + METADATA_SIZE;
  } else if (best_fit->prev == NULL) { // first node, size fit
    if (best_fit->size > total_size + METADATA_SIZE) { //need to split the memory
      metadata* next = best_fit->next;
      size_t new_size = best_fit->size - total_size;

      void* new_addr = (void*) best_fit + total_size;
      metadata* new_node = (metadata*) (new_addr);
      new_node->next = next;
      new_node->prev = NULL;
      new_node->size = new_size;
      if (next != NULL) next->prev = new_node;
      freelist = new_node;
      best_fit->next = NULL;
      best_fit->prev = NULL;
      best_fit->size = total_size;
      return (void*) best_fit + METADATA_SIZE;
    } else {
      if (best_fit->next != NULL) best_fit->next->prev = NULL;
      freelist = best_fit->next;
      best_fit->next = NULL;
      return (void*) best_fit + METADATA_SIZE;
    }
  } else if (best_fit->next == NULL) { // last node
    if (best_fit->size > total_size + METADATA_SIZE) {
      metadata* prev = best_fit->prev;
      size_t new_size = best_fit->size - total_size;
      void* new_addr = (void*) best_fit + total_size;
      metadata* new_node = (metadata*) (new_addr);
      new_node->next = NULL;
      new_node->prev = prev;
      new_node->size = new_size;
      if (prev != NULL) prev->next = new_node;
      best_fit->size = total_size;
      best_fit->next = NULL;
      best_fit->prev = NULL;
      return (void*) best_fit + METADATA_SIZE;
    } else {
      best_fit->prev->next = NULL;
      best_fit->prev = NULL;
      return (void*) best_fit + METADATA_SIZE;
    }
  } else { // anything else
    if (best_fit->size > total_size + METADATA_SIZE) { //need to split the memory
      metadata* next = best_fit->next;
      metadata* prev = best_fit->prev;
      size_t new_size = best_fit->size - total_size;
      void* new_addr = (void*) best_fit + total_size;
      metadata* new_node = (metadata*) (new_addr);
      new_node->next = next;
      new_node->prev = prev;
      new_node->size = new_size;
      next->prev = new_node;
      prev->next = new_node;
      best_fit->next = NULL;
      best_fit->prev = NULL;
      best_fit->size = total_size;
      return (void*) best_fit + METADATA_SIZE;
    } else {
      metadata* next = best_fit->next;
      metadata* prev = best_fit->prev;
      prev->next = next;
      next->prev = prev;
      return (void*) best_fit + METADATA_SIZE;
    }
  }
}

void bf_free(void *ptr) {
  metadata* new_node = (metadata*) (ptr - METADATA_SIZE); //minus goes up, plus goes down
  if (freelist == NULL) {
    new_node->next = NULL;
    freelist = new_node;
    return;
  }
  insert(new_node);
  coalesce(new_node);
}

unsigned long get_data_segment_size() {
  return total_space_used;
}

unsigned long get_data_segment_free_space_size() {
  return calc_freelist_size();
}

unsigned long calc_freelist_size() {
  unsigned long byte_size = 0;
  int i = 0;
  metadata* current = freelist;
  while (current != NULL) {
    i++;
    byte_size += current->size;
    // printf("node size: %lu\n", byte_size);
    current = current->next;
  }
  // printf("i: %d\n", i);
  return byte_size;
}

void insert(metadata* to_add) {
  metadata* current = freelist;
  while (current != NULL) {
    if (current->next == NULL) { // If this is the last node in the list, or the only node in the list
      if (to_add >= current) { // Only node case where it needs to be inserted after the node
        current->next = to_add;
        to_add->prev = current;
        to_add->next = NULL;
      } else if (current->prev == NULL) { // Implied that to_add < current address, only node case, insert before node
        to_add->next = current;
        current->prev = to_add;
        to_add->prev = NULL;
        freelist = to_add;
      } else { // Last node case, insert before last node
        to_add->prev = current->prev;
        current->prev->next = to_add;
        current->prev = to_add;
        to_add->next = current;
      }
      return;
    }
    if (to_add < current && current->prev == NULL) { // Insert at head case
      to_add->next = current;
      current->prev = to_add;
      to_add->prev = NULL;
      freelist = to_add;
      return;
    } else if (to_add < current) { // insert into the middle of the list somewhere
      to_add->prev = current->prev;
      current->prev->next = to_add;
      current->prev = to_add;
      to_add->next = current;
      return;
    }
    current = current->next;
  }
}

void coalesce(metadata* node) {
  while (node->prev != NULL && (((void*) node->prev) + node->prev->size == ((void*) node))) {
    metadata* current = node->prev;
    current->size = current->size + node->size;
    current->next = node->next;
    if (node->next != NULL) {
      node->next->prev = current;
    }
    node->size = 0;
    node->prev = NULL;
    node->next = NULL;
    node = current;
  }

  while (node->next != NULL && (((void*) node) + node->size == ((void*) node->next))) {
    metadata* next = node->next;
    node->size = node->size + next->size;
    node->next = next->next;
    if (next->next != NULL) {
      next->next->prev = node;
    }
    next->next = NULL;
    next->prev = NULL;
    next->size = 0;
  }
}

void print_list() {
  metadata* current = freelist;
  int i = 0;
  while (current != NULL) {
    printf("Node: %d, Size: %lu, Address: %p;\n", i, current->size, (void*) current);
    current = current->next;
    i++;
  }
}